(function() {
    'use strict';

    /**
     * CKEDITOR.tools class utility which adds additional methods to those of CKEditor.
     *
     * @class CKEDITOR.tools
     */

    /**
     * Debounce util function. If a function execution is expensive, it might be debounced. This means
     * that it will be executed after some amount of time after its last call. For example, if we attach a
     * a function on scroll event, it might be called hundreds times per second. In this case it may be
     * debounced with, let's say 100ms. The real execution of this function will happen 100ms after last
     * scroll event.
     *
     * @method debounce
     * @param {Function} callback The callback which has to be called after given timeout.
     * @param {Number} timeout Timeout in milliseconds after which the callback will be called.
     * @param {Object} context The context in which the callback will be called. This argument is optional.
     * @param {Array} args An array of arguments which the callback will receive.
     */
    CKEDITOR.tools.debounce = CKEDITOR.tools.debounce || function(callback, timeout, context, args) {
        var callFn,
            debounceHandle;

        callFn = function() {
            var callArgs,
                callContext,
                len,
                result = [],
                startIndex = 0;

            callContext = context || this;

            for (len = arguments.length; startIndex < len; ++startIndex) {
                result.push(arguments[startIndex]);
            }

            callArgs = result.concat(args || []);

            clearTimeout(debounceHandle);

            debounceHandle = setTimeout(function() {
                callback.apply(callContext, callArgs);
            }, timeout);
        };

        callFn.cancel = function() {
            clearTimeout(debounceHandle);
        };

        return callFn;
    };
}());
(function() {
    'use strict';

    /**
     * Link class utility. Provides methods for create, delete and update links.
     *
     * @class CKEDITOR.Link
     * @constructor
     * @param {Object} The CKEditor instance.
     */

    function Link(editor) {
        this._editor = editor;
    }

    Link.prototype = {
        constructor: Link,

        /**
         * Create a link with given URI as href.
         *
         * @method create
         * @param {String} URI The URI of the link.
         * @param {Object} attrs A config object with link attributes. These might be arbitrary DOM attributes.
         */
        create: function(URI, attrs) {
            var linkAttrs,
                range,
                selection,
                style,
                text;

            selection = this._editor.getSelection();

            range = selection.getRanges()[0];

            if (range.collapsed) {
                text = new CKEDITOR.dom.text(URI, this._editor.document);
                range.insertNode(text);
                range.selectNodeContents(text);
            }

            linkAttrs = CKEDITOR.tools.merge({
                'data-cke-saved-href': URI,
                href: URI
            }, attrs);

            style = new CKEDITOR.style({
                attributes: linkAttrs,
                element: 'a'
            });

            style.type = CKEDITOR.STYLE_INLINE;
            style.applyToRange(range, this._editor);
            range.select();
        },

        /**
         * Retrieves a link from the current selection.
         *
         * @method getFromSelection
         * @return {CKEDITOR.dom.element} The retrieved link or null if not found.
         */
        getFromSelection: function() {
            var range,
                selection,
                selectedElement;

            selection = this._editor.getSelection();

            selectedElement = selection.getSelectedElement();

            if (selectedElement && selectedElement.is('a')) {
                return selectedElement;
            }

            range = selection.getRanges()[0];

            if (range) {
                range.shrink(CKEDITOR.SHRINK_TEXT);

                return this._editor.elementPath(range.getCommonAncestor()).contains('a', 1);
            }

            return null;
        },

        /**
         * Removes a link from the editor.
         *
         * @param {CKEDITOR.dom.element} link The link element which link style should be removed.
         * @method remove
         */
        remove: function(link) {
            var style;

            if (link) {
                link.remove(this._editor);
            } else {
                style = link || new CKEDITOR.style({
                    alwaysRemoveElement: 1,
                    element: 'a',
                    type: CKEDITOR.STYLE_INLINE
                });

                this._editor.removeStyle(style);
            }
        },

        /**
         * Updates the href of an already existing link.
         *
         * @param {String} URI The new URI of the link.
         * @param {CKEDITOR.dom.element} link The link element which href should be removed.
         * @method update
         */
        update: function(URI, link) {
            var style;

            style = link || this.getFromSelection();

            style.setAttributes({
                'data-cke-saved-href': URI,
                href: URI
            });
        }
    };

    CKEDITOR.Link = CKEDITOR.Link || Link;
}());
(function() {
    'use strict';

    if (CKEDITOR.plugins.get('selectionregion')) {
        return;
    }

    CKEDITOR.SELECTION_TOP_TO_BOTTOM = 0;
    CKEDITOR.SELECTION_BOTTOM_TO_TOP = 1;
    CKEDITOR.SELECTION_LEFT_TO_RIGHT = 2;
    CKEDITOR.SELECTION_RIGHT_TO_LEFT = 3;

    /**
     * SelectionRegion utility class which provides metadata about the selection. The metadata may be the start and end
     * rectangles, caret region, etc. **This class is not intended to be used standalone. Its functions will
     * be merged into each editor instance, so the developer may use them directly via the editor, without making
     * an instance of this class**.
     *
     * @class CKEDITOR.plugins.selectionregion
     * @constructor
     */
    function SelectionRegion() {}

    SelectionRegion.prototype = {
        constructor: SelectionRegion,

        /**
         * Creates selection from two points in page coordinates.
         *
         * @method createSelectionFromPoint
         * @param {Number} x X point in page coordinates.
         * @param {Number} y Y point in page coordinates.
         */
        createSelectionFromPoint: function(x, y) {
            this.createSelectionFromRange(x, y, x, y);
        },

        /**
         * Creates selection from range. A range consists from two points in page coordinates.
         *
         * @method createSelectionFromRange
         * @param {Number} startX X coordinate of the first point.
         * @param {Number} startY Y coordinate of the first point.
         * @param {Number} endX X coordinate of the second point.
         * @param {Number} endY Y coordinate of the second point.
         */
        createSelectionFromRange: function(startX, startY, endX, endY) {
            var editor,
                end,
                endContainer,
                endOffset,
                endRange,
                range,
                selection,
                start,
                startContainer,
                startOffset;

            editor = this.editor;

            if (typeof document.caretPositionFromPoint == 'function') {
                start = document.caretPositionFromPoint(startX, startY);
                end = document.caretPositionFromPoint(endX, endY);

                startContainer = start.offsetNode;
                endContainer = end.offsetNode;

                startOffset = start.offset;
                endOffset = end.offset;

                range = this.createRange();
            } else if (typeof document.caretRangeFromPoint == 'function') {
                start = document.caretRangeFromPoint(startX, startY);
                end = document.caretRangeFromPoint(endX, endY);

                startContainer = start.startContainer;
                endContainer = end.startContainer;

                startOffset = start.startOffset;
                endOffset = end.startOffset;

                range = this.createRange();
            }

            if (range && document.getSelection) {
                range.setStart(new CKEDITOR.dom.node(startContainer), startOffset);
                range.setEnd(new CKEDITOR.dom.node(endContainer), endOffset);

                this.getSelection().selectRanges([range]);
            } else if (typeof document.body.createTextRange == 'function') {
                selection = this.getSelection();

                selection.unlock();

                range = document.body.createTextRange();
                range.moveToPoint(startX, startY);

                endRange = range.duplicate();
                endRange.moveToPoint(endX, endY);

                range.setEndPoint('EndToEnd', endRange);
                range.select();

                this.getSelection().lock();
            }
        },

        /**
         * Returns the region of the current position of the caret. The points are in page coordinates.
         *
         * @method getCaretRegion
         * @return {Object} Returns object with the following properties:
         * - bottom
         * - left
         * - right
         * - top
         */
        getCaretRegion: function() {
            var bookmarkNodeEl,
                bookmarks,
                region,
                selection,
                scrollPos;

            selection = this.getSelection();

            bookmarks = selection.createBookmarks();
            bookmarkNodeEl = bookmarks[0].startNode.$;

            bookmarkNodeEl.style.display = 'inline-block';

            region = new CKEDITOR.dom.element(bookmarkNodeEl).getClientRect();

            bookmarkNodeEl.parentNode.removeChild(bookmarkNodeEl);

            scrollPos = new CKEDITOR.dom.window(window).getScrollPosition();

            return {
                bottom: scrollPos.y + region.bottom,
                left: scrollPos.x + region.left,
                right: scrollPos.x + region.right,
                top: scrollPos.y + region.top
            };
        },

        /**
         * Returns data for the current selection.
         *
         * @method getSelectionData
         * @return {Object} Returns object with the following data:
         * - element - The currently selected element, if any
         * - text - The selected text
         * - region - The data, returned from {{#crossLink "CKEDITOR.plugins.selectionregion/getSelectionRegion:method"}}{{/crossLink}}
         */
        getSelectionData: function() {
            var result,
                selection;

            selection = this.getSelection();

            result = {
                element: selection.getSelectedElement(),
                text: selection.getSelectedText()
            };

            result.region = this.getSelectionRegion(selection);

            return result;
        },

        /**
         * Returns the region of the current selection.
         *
         * @method getSelectionRegion
         * @return {Object} Returns object which is being returned from
         * {{#crossLink "CKEDITOR.plugins.selectionregion/getClientRectsRegion:method"}}{{/crossLink}} with three more properties:
         * - direction - the direction of the selection. Can be one of these:
         *   1. CKEDITOR.SELECTION_TOP_TO_BOTTOM
         *   2. CKEDITOR.SELECTION_BOTTOM_TO_TOP
         * - height - The height of the selection region
         * - width - The width of the selection region
         */
        getSelectionRegion: function() {
            var direction,
                region;

            direction = CKEDITOR.SELECTION_TOP_TO_BOTTOM;

            region = this.getClientRectsRegion();

            region.direction = this._getSelectionDirection();

            region.height = region.bottom - region.top;
            region.width = region.right - region.left;

            return region;
        },

        /**
         * Returns true if the current selection is empty, false otherwise.
         *
         * @method isSelectionEmpty
         * @return {Boolean} Returns true if the current selection is empty, false otherwise.
         */
        isSelectionEmpty: function() {
            var ranges,
                selection = this.getSelection();

            return (selection.getType() === CKEDITOR.SELECTION_NONE) ||
                ((ranges = selection.getRanges()) && ranges.length === 1 && ranges[0].collapsed);
        },

        /**
         * Returns object with data about the [client rectangles](https://developer.mozilla.org/en-US/docs/Web/API/Element.getClientRects) of the selection,
         * normalized across browses. All offsets below are in page coordinates.
         *
         * @method getClientRectsRegion
         * @return {Object} Returns object with the following data:
         * - bottom - bottom offset of all client rectangles
         * - left - left offset of all client rectangles
         * - right - right offset of all client rectangles
         * - top - top offset of all client rectangles
         * - startRect - An Object, which contains the following information:
         *     + bottom - bottom offset
         *     + height - the height of the rectangle
         *     + left - left offset of the selection
         *     + right - right offset of the selection
         *     + top - top offset of the selection
         *     + width - the width of the rectangle
         * - endRect - An Object, which contains the following information:
         *     + bottom - bottom offset
         *     + height - the height of the rectangle
         *     + left - left offset of the selection
         *     + right - right offset of the selection
         *     + top - top offset of the selection
         *     + width - the width of the rectangle
         */
        getClientRectsRegion: function() {
            var bottom,
                clientRects,
                endRect,
                i,
                item,
                left,
                length,
                nativeSelection,
                range,
                rangeCount,
                region,
                right,
                selection,
                scrollPos,
                startRect,
                top;

            selection = this.getSelection();
            nativeSelection = selection.getNative();

            if (nativeSelection.createRange) {
                range = nativeSelection.createRange();
                clientRects = range.getClientRects();
            } else {
                rangeCount = nativeSelection.rangeCount;
                clientRects = (nativeSelection.rangeCount > 0) ? nativeSelection.getRangeAt(0).getClientRects() : [];
            }

            bottom = 0;
            left = Infinity;
            right = -Infinity;
            top = Infinity;

            if (clientRects.length === 0) {
                region = this.getCaretRegion();
            } else {
                for (i = 0, length = clientRects.length; i < length; i++) {
                    item = clientRects[i];

                    if (item.left < left) {
                        left = item.left;
                    }

                    if (item.right > right) {
                        right = item.right;
                    }

                    if (item.top < top) {
                        top = item.top;
                    }

                    if (item.bottom > bottom) {
                        bottom = item.bottom;
                    }
                }

                scrollPos = new CKEDITOR.dom.window(window).getScrollPosition();

                region = {
                    bottom: scrollPos.y + bottom,
                    left: scrollPos.x + left,
                    right: scrollPos.x + right,
                    top: scrollPos.y + top
                };

                if (clientRects.length) {
                    endRect = clientRects[clientRects.length - 1];
                    startRect = clientRects[0];

                    region.endRect = {
                        bottom: scrollPos.y + endRect.bottom,
                        height: endRect.height,
                        left: scrollPos.x + endRect.left,
                        right: scrollPos.x + endRect.right,
                        top: scrollPos.y + endRect.top,
                        width: endRect.width
                    };

                    region.startRect = {
                        bottom: scrollPos.y + startRect.bottom,
                        height: startRect.height,
                        left: scrollPos.x + startRect.left,
                        right: scrollPos.x + startRect.right,
                        top: scrollPos.y + startRect.top,
                        width: startRect.width
                    };
                }
            }

            return region;
        },

        /**
         * Retrieves the direction of the selection. The direction is from top to bottom or from bottom to top.
         * For IE < 9 it is not possible, so the direction for these browsers will be always CKEDITOR.SELECTION_TOP_TO_BOTTOM.
         *
         * @method _getSelectionDirection
         * @protected
         * @return {Number} Returns a number which represents selection direction. It might be one of these:
         * - CKEDITOR.SELECTION_TOP_TO_BOTTOM;
         * - CKEDITOR.SELECTION_BOTTOM_TO_TOP;
         */
        _getSelectionDirection: function() {
            var anchorNode,
                direction,
                nativeSelection,
                position,
                selection;

            selection = this.getSelection();
            nativeSelection = selection.getNative();

            direction = CKEDITOR.SELECTION_TOP_TO_BOTTOM;

            if ((anchorNode = nativeSelection.anchorNode) && anchorNode.compareDocumentPosition) {
                position = anchorNode.compareDocumentPosition(nativeSelection.focusNode);

                if (!position && nativeSelection.anchorOffset > nativeSelection.focusOffset || position === Node.DOCUMENT_POSITION_PRECEDING) {
                    direction = CKEDITOR.SELECTION_BOTTOM_TO_TOP;
                }
            }

            return direction;
        }
    };

    CKEDITOR.plugins.add(
        'selectionregion', {
            /**
             * Initializer lifecycle implementation for the SelectionRegion plugin.
             *
             * @method init
             * @protected
             * @param {Object} editor The current CKEditor instance.
             */
            init: function(editor) {
                var attr,
                    hasOwnProperty;

                hasOwnProperty = Object.prototype.hasOwnProperty;

                for (attr in SelectionRegion.prototype) {
                    if (hasOwnProperty.call(SelectionRegion.prototype, attr) && typeof editor[attr] == 'undefined') {
                        editor[attr] = SelectionRegion.prototype[attr];
                    }
                }
            }
        }
    );
}());
(function() {
    'use strict';

    /**
     * CKEDITOR.tools class utility which adds additional methods to those of CKEditor.
     *
     * @class CKEDITOR.tools
     */

    /**
     * Returns a new object containing all of the properties of all the supplied
     * objects. The properties from later objects will overwrite those in earlier
     * objects.
     *
     * Passing in a single object will create a shallow copy of it.
     *
     * @method merge
     * @param {Object} objects* One or more objects to merge.
     * @return {Object} A new merged object.
     */
    CKEDITOR.tools.merge = CKEDITOR.tools.merge || function() {
        var i = 0,
            key,
            len = arguments.length,
            obj,
            result = {};

        for (; i < len; ++i) {
            obj = arguments[i];

            for (key in obj) {
                if (hasOwnProperty.call(obj, key)) {
                    result[key] = obj[key];
                }
            }
        }

        return result;
    };
}());
(function() {
    'use strict';

    if (CKEDITOR.plugins.get('uicore')) {
        return;
    }

    /**
     * UICore class which will handle user interactions with the editor. These interactions
     * might be triggered via mouse, keyboard or touch devices. The class fill fire an event via
     * CKEditor's event system - "editorInteraction". The UI may listen to this event and
     * execute some actions - for example to show/hide toolbars.
     *
     * By default if user presses the Esc key, 'editorInteraction' event won't be fired. However, this behaviour can be changed
     * by setting {{#crossLink "CKEDITOR.plugins.uicore/allowEsc:attribute"}}{{/crossLink}} config property in editor's configuration to true.
     *
     * @class CKEDITOR.plugins.uicore
     */

    /**
     * Fired when user interacts somehow with the browser. This may be clicking with the mouse, pressing keyboard button,
     * or touching screen. This even will be not fired after each interaction. It will be debounced. By default the timeout
     * is 50ms. This value can be overwritten via {{#crossLink "CKEDITOR.plugins.uicore/timeout:attribute"}}{{/crossLink}}
     * property of editor's configuration, like: editor.config.uicore.timeout = 100
     *
     * @event editorInteraction
     * @param {Object} data An object which contains the following properties:
     * - nativeEvent - The event as received from CKEditor.
     * - selectionData - The data, returned from {{#crossLink "CKEDITOR.plugins.selectionregion/getSelectionData:method"}}{{/crossLink}}
     */

     /**
      * Fired by UI elements like Toolbars or Buttons when their state changes. The listener updates the live region with the provided data.
      *
      * @event ariaUpdate
      * @param {Object} data An object which contains the following properties:
      * - message - The provided message from the UI element.
      */

    /**
     * If set to true, the editor will still fire {{#crossLink "CKEDITOR.plugins.uicore/editorInteraction:event"}}{{/crossLink}} event,
     * if user presses Esc key.
     *
     * @attribute allowEsc
     * @default false
     * @type Boolean
     */

    /**
     * Specifies the default timeout after which the {{#crossLink "CKEDITOR.plugins.uicore/editorInteraction:event"}}{{/crossLink}} event
     * will be fired.
     *
     * @attribute timeout
     * @default 50 (ms)
     * @type Number
     */

    CKEDITOR.plugins.add(
        'uicore', {
            /**
             * Initializer lifecycle implementation for the UICore plugin.
             *
             * @method init
             * @protected
             * @param {Object} editor The current CKEditor instance.
             */
            init: function(editor) {
                var ariaElement,
                    ariaState = [],
                    handleAria,
                    handleUI,
                    uiTasksTimeout;

                ariaElement = this._createAriaElement(editor.id);

                uiTasksTimeout = editor.config.uicore ? editor.config.uicore.timeout : 50;

                handleAria = CKEDITOR.tools.debounce(
                    function(event) {
                        ariaElement.innerHTML = ariaState.join('. ');
                    },
                    uiTasksTimeout
                );

                handleUI = CKEDITOR.tools.debounce(
                    function(event) {
                        ariaState = [];

                        if (event.name !== 'keyup' || event.data.$.keyCode !== 27 || editor.config.allowEsc) {
                            editor.fire('editorInteraction', {
                                nativeEvent: event.data.$,
                                selectionData: editor.getSelectionData()
                            });
                        }
                    },
                    uiTasksTimeout
                );

                editor.on('ariaUpdate', function(event) {
                    // handleAria is debounced function, so if it is being called multiple times, it will
                    // be canceled until some time passes.
                    // For that reason here we explicitly append the current message to the list of messages
                    // and call handleAria. Since it is debounced, when some timeout passes,
                    // all the messages will be applied to the live region and not only the last one.

                    ariaState.push(event.data.message);

                    handleAria();
                });

                editor.on('contentDom', function() {
                    var editable = editor.editable();

                    editable.attachListener(editable, 'mouseup', handleUI);
                    editable.attachListener(editable, 'keyup', handleUI);
                });
            },

            /**
             * Creates and applies an HTML element to the body of the document which will contain ARIA messages.
             *
             * @method _createAriaElement
             * @protected
             * @param {String} id The provided id of the element. It will be used as prefix for the final element Id.
             * @return {HTMLElement} The created and applied to DOM element.
             */
            _createAriaElement: function(id) {
                var statusElement;

                statusElement = document.createElement('div');

                statusElement.className = 'sr-only';

                statusElement.setAttribute('aria-live', 'polite');
                statusElement.setAttribute('role', 'status');
                statusElement.setAttribute('id', id + 'LiveRegion');

                document.body.appendChild(statusElement);

                return statusElement;
            }
        }
    );
}());
CKEDITOR.disableAutoInline = true;

YUI.add('alloy-editor', function(Y) {
    'use strict';

    var Lang = Y.Lang,
        AlloyEditor,

        KEY_ESC = 27,
        KEY_F10 = 121,
        KEY_TAB = 9;

    /**
     * YUI3 Adapter for CKEditor. This class provides YUI3 like way of creating instances of
     * CKEditor and passing configuration paramters to it.
     *
     * @class AlloyEditor
     * @constructor
     */
    AlloyEditor = Y.Base.create('alloyEditor', Y.Base, [], {

        /**
         * Initializer lifecycle implementation for the AlloyEditor class. Creates a CKEditor
         * instace, passing it the provided configuration attributes.
         *
         * @method initializer
         * @protected
         * @param config {Object} Configuration object literal for the editor.
         */
        initializer: function(config) {
            var editor,
                eventsDelay,
                node;

            node = this.get('srcNode');

            editor = CKEDITOR.inline(node.getDOMNode());

            editor.config.allowedContent = this.get('allowedContent');

            editor.config.toolbars = this.get('toolbars');

            editor.config.removePlugins = this.get('removePlugins');
            editor.config.extraPlugins = this.get('extraPlugins');
            editor.config.placeholderClass = this.get('placeholderClass');

            Y.mix(editor.config, config);

            this._editor = editor;

            eventsDelay = this.get('eventsDelay');

            this._eventHandles = [
                Y.one(Y.config.doc).on(['click', 'keydown'],
                    CKEDITOR.tools.debounce(this._onDocInteract, eventsDelay, this)),
                node.on('keydown',
                    CKEDITOR.tools.debounce(this._onEditorKey, eventsDelay, this))
            ];

            // Custom events will be attached automatically, there is no need to put them in to the list
            // with event handles
            editor.on('toolbarKey', this._onToolbarKey, this);

            editor.on('toolbarActive', this._onToolbarActive, this);
        },

        /**
         * Destructor lifecycle implementation for the AlloyEdtor class. Destroys the CKEditor
         * instance and destroys all created toolbars.
         *
         * @method destructor
         * @protected
         */
        destructor: function() {
            var editorInstance;

            editorInstance = CKEDITOR.instances[this.get('srcNode').get('id')];

            if (editorInstance) {
                Y.Object.each(editorInstance.config.toolbars, function(value) {
                    value.destroy();
                });

                editorInstance.destroy();
            }

            (new Y.EventHandle(this._eventHandles)).detach();
        },

        /**
         * Searches among toolbars to find the next toolbar that should be focused.
         *
         * @method _focusNextToolbar
         * @protected
         */
        _focusNextToolbar: function() {
            var activeToolbar,
                currentToolbarIndex,
                lastPart,
                toolbars;

            activeToolbar = this._activeToolbar;

            toolbars = this._editor.config.toolbars;

            //We need to convert toolbars to an array so we can reorder them.
            toolbars = Y.Object.keys(toolbars).map(function(item) {
                return toolbars[item];
            });

            currentToolbarIndex = Y.Array.indexOf(toolbars, activeToolbar);

            lastPart = toolbars.splice(currentToolbarIndex);

            toolbars = lastPart.concat(toolbars);

            Y.Array.some(toolbars, function(toolbar) {
                if (toolbar !== activeToolbar && toolbar.focus()) {
                    this._activeToolbar = toolbar;

                    return true;
                }
            }, this);
        },

        /**
         * Focuses the first visible toolbar in editor or if there is not any, focuses the last of the other
         * toolbars which accept the request for focusing.
         *
         * @method _focusVisibleToolbar
         * @protected
         */
        _focusVisibleToolbar: function() {
            Y.Object.some(this._editor.config.toolbars, function(toolbar) {
                if (toolbar != this._activeToolbar && toolbar.focus()) {
                    this._activeToolbar = toolbar;

                    return toolbar.get('visible');
                }
            }, this);
        },

        /**
         * Retrieves the native CKEditor instance. Having this, the developer may use the API of CKEditor OOTB.
         *
         * @method _getNativeEditor
         * @protected
         * @return {Object} The current instance of CKEditor.
         */
        _getNativeEditor: function() {
            return this._editor;
        },

        /**
         * Hide all visible toolbars in editor
         *
         * @method _hideToolbars
         * @protected
         */
        _hideToolbars: function() {
            Y.Object.each(this._editor.config.toolbars, function(toolbar) {
                toolbar.hide();
            });
        },

        /**
         * Fires <code>toolbarsHide</code> event if none of the toolbars or their child nodes is the element user is
         * currently interacting.
         *
         * @method _onDocInteract
         * @protected
         * @param {EventFacade} event EventFacade object
         */
        _onDocInteract: function(event) {
            var editorInstance,
                result,
                srcNode;

            srcNode = this.get('srcNode');

            result = (srcNode === event.target) || (srcNode.contains(event.target));

            editorInstance = CKEDITOR.instances[srcNode.get('id')];

            result = result || Y.some(editorInstance.config.toolbars, function(toolbar) {
                return toolbar.ownsNode(event.target);
            });

            if (!result) {
                this._editor.fire('toolbarsHide');
            }
        },

        /**
         * Handles key events in the editor:
         *  - ALT + F10: focus the toolbar
         *  - ESC: hide visible toolbars
         *
         * @method _onEditorKey
         * @param {EventFacade} event Event that triggered when user pressed a key inside the editor.
         * @protected
         */
        _onEditorKey: function(event) {
            if (event.altKey && event.keyCode === KEY_F10) {
                this._focusVisibleToolbar();

            } else if (event.keyCode === KEY_ESC) {
                this._hideToolbars();
            }
        },

        /**
         * Handles activating a toolbar.
         *
         * @method _onToolbarActive
         * @protected
         */
        _onToolbarActive: function(event) {
            this._activeToolbar = event.data;
        },

        /**
         * Handles key events in the toolbar:
         *  - TAB: focus next toolbar
         *  - ESC: focus the editor
         *
         * @method _onToolbarKey
         * @param {Event} event keyboard event
         * @protected
         */
        _onToolbarKey: function(event) {
            if (event.data.keyCode === KEY_TAB) {
                event.data.preventDefault();
                this._focusNextToolbar();

            } else if (event.data.keyCode === KEY_ESC) {
                this._activeToolbar.blur();
                this._activeToolbar = null;

                this._hideToolbars();
            }
        },

        /**
         * Validates the allowed content attribute. Look
         * [here](http://docs.ckeditor.com/#!/api/CKEDITOR.config-cfg-allowedContent) for more information about the
         * supported values.
         *
         * @method _validateAllowedContent
         * @protected
         * @return {Boolean} True if the value was accepted, false otherwise.
         */
        _validateAllowedContent: function(value) {
            return Lang.isString(value) || Lang.isObject(value) || Lang.isBoolean(value);
        },

        /**
         * Validates toolbars attribute. May be empty string or null, which means the current instance of AlloyEdtor
         * shouldn't have any toolbars, or Object, which properties are the desired toolbars.
         *
         * @method _validateToolbars
         * @protected
         * @param {Any} value The value which should be validated.
         * @return {Boolean} True if the value was accepted, false otherwise.
         */
        _validateToolbars: function(value) {
            return (value === '' || Lang.isObject(value) || Lang.isNull(value));
        }
    }, {
        ATTRS: {
            /**
             * Configures the allowed content for the current instance of AlloyEditor.
             * Look on the [official CKEditor API](http://docs.ckeditor.com/#!/api/CKEDITOR.config-cfg-allowedContent)
             * for more information about the valid values.
             *
             * @attribute allowedContent
             * @default true
             * @writeOnce
             * @type {Boolean, String, Object}
             */
            allowedContent: {
                validator: '_validateAllowedContent',
                value: true,
                writeOnce: true
            },

            /**
             * The delay (timeout), in ms, after which events such like key or mouse events will be processed.
             *
             * @attribute eventsDelay
             * @type {Number}
             */
            eventsDelay: {
                validator: Lang.isNumber,
                value: 100
            },

            /**
             * Specifies the extra plugins which have to be loaded to the current CKEditor instance in order to
             * make AlloyEditor to work properly.
             *
             * @attribute extraPlugins
             * @default 'uicore,selectionregion,dropimages,placeholder,linktooltip,uiloader'
             * @writeOnce
             * @type {String}
             */
            extraPlugins: {
                validator: Lang.isString,
                value: 'uicore,selectionregion,dropimages,placeholder,linktooltip,uiloader',
                writeOnce: true
            },

            /**
             * Retrieves the native CKEditor instance. Having this, the developer may use the full API of CKEditor.
             *
             * @attribute nativeEditor
             * @readOnly
             * @type {Object}
             */
            nativeEditor: {
                getter: '_getNativeEditor',
                readOnly: true
            },

            /**
             * Specifies the class, which should be added by Placeholder plugin
             * {{#crossLink "CKEDITOR.plugins.placeholder}}{{/crossLink}}
             * when editor is not focused.
             *
             * @attribute placeholderClass
             * @default 'alloy-editor-placeholder'
             * @writeOnce
             * @type {String}
             */
            placeholderClass: {
                validator: Lang.isString,
                value: 'alloy-editor-placeholder',
                writeOnce: true
            },

            /**
             * Specifies the plugins, which come by default with CKEditor, but which are not needed by AlloyEditor.
             * These plugins add the default UI for CKeditor, which is no more needed. Please note that AlloyEdtor
             * comes with its own highly optimized copy of CKEditor (just customized via their official download page).
             * This version does not come with the unneeded plugins, so the value of this property won't be needed.
             * However, if you decide to go with the OOTB version of CKEditor, you will have to remove some of the
             * plugins if you decide to use AlloyEditor. Keep in mind that removing these plugins doesn't remove them
             * entirely from CKEditor. It just removes them from its current instance, in which you will use different
             * UI - those of AlloyEditor. You will be fully able to use both OOTB CKEditor and AlloyEditor on the same
             * page!
             *
             * @attribute removePlugins
             * @default 'contextmenu,toolbar,elementspath,resize,liststyle,tabletools,link'
             * @writeOnce
             * @type {String}
             */
            removePlugins: {
                validator: Lang.isString,
                value: 'contextmenu,toolbar,elementspath,resize,liststyle,tabletools,link',
                writeOnce: true
            },

            /**
             * The Node ID or HTMl node, which should be turned to an instance of AlloyEditor.
             *
             * @attribute srcNode
             * @type String | Node
             * @writeOnce
             */
            srcNode: {
                setter: Y.one,
                writeOnce: true
            },

            /**
             * Specifies the Toolbars of the current editor instance. The value should be an object
             * with one or more properties. Each of these will represent a toolbar. The value of these properties
             * can be string or Object. If String, the value of the string should represent the buttons. If object,
             * one of these properties should be 'buttons', which will represent the buttons of this Toolbar and
             * all the other properties will be different configuration parameters of the Toolbar. Example:
             * <pre><code>
             *     toolbars: {
             *         table: { // this would be a toolbar configuration, which specifies both Toolbar attributes and its buttons
             *             buttons: ['button1', button2],
             *             width: 25
             *         },
             *         add: ['image', 'code'], // here we specify only the buttons of this toolbar and leave the other options unmodified.
             *         image: ['left', 'right'],
             *         styles: ['strong', 'em', 'u', 'h1', 'h2', 'a', 'twitter']
             *     }
             * </pre></code>
             *
             * @default
             *     toolbars {
             *         add: ['image'],
             *         image: ['left', 'right'],
             *         styles: ['strong', 'em', 'u', 'h1', 'h2', 'a', 'twitter']
             *     }
             * @attribute toolbars
             * @type Object
             */
            toolbars: {
                validator: '_validateToolbars',
                value: {
                    add: ['image'],
                    image: ['left', 'right'],
                    styles: ['strong', 'em', 'u', 'h1', 'h2', 'a', 'twitter']
                }
            }
        }
    });

    Y.AlloyEditor = AlloyEditor;
}, '', {
    requires: ['base-build', 'node-base']
});
(function() {
    'use strict';

    var isIE = CKEDITOR.env.ie;

    if (CKEDITOR.plugins.get('dropimages')) {
        return;
    }

    /**
     * CKEditor plugin which allows Drag&Drop of images directly into the edit area. The image will be encoded
     * as Data URI.
     *
     * @class CKEDITOR.plugins.dropimages
     */
    CKEDITOR.plugins.add(
        'dropimages', {
            /**
             * Initialization of the plugin, part of CKEditor plugin lifecycle.
             * The function registers a 'dragenter', 'dragover' and 'drop' events on the editing area.
             *
             * @method init
             * @param {Object} editor The current editor instance
             */
            init: function(editor) {
                var editable;

                editable = new CKEDITOR.editable(editor, editor.element.$);

                editable.attachListener(editable, 'dragenter', this._onDragEnter, this, {
                    editor: editor
                });

                editable.attachListener(editable, 'dragover', this._onDragOver, this, {
                    editor: editor
                });

                editable.attachListener(editable, 'drop', this._onDragDrop, this, {
                    editor: editor
                });
            },

            /**
             * Accepts an array of dropped files to the editor. Then, it filters the images and sends them for further
             * processing to {{#crossLink "CKEDITOR.plugins.dropimages/_processFile:method"}}{{/crossLink}}
             *
             * @method _handleFiles
             * @protected
             * @param {Array} files Array of dropped files. Only the images from this list will be processed.
             * @param {Object} editor The current editor instance
             */
            _handleFiles: function(files, editor) {
                var i,
                    imageType,
                    file;

                for (i = 0; i < files.length; i++) {
                    file = files[i];
                    imageType = /image.*/;

                    if (file.type.match(imageType)) {
                        this._processFile(file, editor);
                    }
                }

                return false;
            },

            /**
             * Handles drag enter event. In case of IE, this function will prevent the event.
             *
             * @method _onDragEnter
             * @protected
             * @param {DOM event} event dragenter event, as received natively from CKEditor
             */
            _onDragEnter: function(event) {
                if (isIE) {
                    this._preventEvent(event);
                }
            },

            /**
             * Handles drag over event. In case of IE, this function will prevent the event.
             *
             * @method _onDragOver
             * @protected
             * @param {DOM event} event dragover event, as received natively from CKEditor
             */
            _onDragOver: function(event) {
                if (isIE) {
                    this._preventEvent(event);
                }
            },

            /**
             * Handles drag drop event. The function will create selection from the current points and
             * will send a list of files to be processed to
             * {{#crossLink "CKEDITOR.plugins.dropimages/_handleFiles:method"}}{{/crossLink}}
             *
             * @method _onDragDrop
             * @protected
             * @param {CKEDITOR.dom.event} event dragdrop event, as received natively from CKEditor
             */
            _onDragDrop: function(event) {
                var editor,
                    nativeEvent;

                nativeEvent = event.data.$;

                new CKEDITOR.dom.event(nativeEvent).preventDefault();

                editor = event.listenerData.editor;

                event.listenerData.editor.createSelectionFromPoint(nativeEvent.clientX, nativeEvent.clientY);

                this._handleFiles(nativeEvent.dataTransfer.files, editor);
            },

            /**
             * Prevents a native event.
             *
             * @method _preventEvent
             * @protected
             * @param {DOM event} event The event to be prevented.
             */
            _preventEvent: function(event) {
                event = new CKEDITOR.dom.event(event.data.$);

                event.preventDefault();
                event.stopPropagation();
            },

            /**
             * Processes an image file. The function creates an element and sets a source
             * a Data URI, then fires an event 'imagedrop' via CKEditor event system.
             *
             * @method _preventEvent
             * @protected
             * @param {DOM event} event The event to be prevented.
             */
            _processFile: function(file, editor) {
                var reader = new FileReader();

                reader.addEventListener('loadend', function() {
                    var bin,
                        el;

                    bin = reader.result;

                    el = CKEDITOR.dom.element.createFromHtml('<img src="' + bin + '">');

                    editor.insertElement(el);

                    editor.fire('imagedrop', el);
                });

                reader.readAsDataURL(file);
            }

            /**
             * Fired when an image is being added to the editor successfully.
             *
             * @event imagedrop
             * @param {CKEDITOR.dom.element} el The created image with src, created as Data URI
             */
        }
    );
}());
(function() {
    'use strict';

    if (CKEDITOR.plugins.get('placeholder')) {
        return;
    }

    /**
     * CKEditor plugin which allows adding a placeholder to the editor. In this case, if there
     * is no content to the editor, there will be hint to the user.
     *
     * @class CKEDITOR.plugins.placeholder
     */

    /**
     * Specifies the placeholder class which have to be aded to editor when editor is not focuced.
     *
     * @attribute placeholderClass
     * @default alloy-editor-placeholder
     * @type String
     */

    CKEDITOR.plugins.add(
        'placeholder', {

            /**
             * Initialization of the plugin, part of CKEditor plugin lifecycle.
             * The function registers a 'blur' listener to CKEditor's blur event.
             *
             * @method init
             * @param {Object} editor The current editor instance
             */
            init: function(editor) {
                editor.on('blur', this._onBlur, this);
            },

            /**
             * Handles the fired blur event. The function removes any data from CKEditor, because an
             * empty paragraph may still exist despite for the user the editor looks empty and
             * adds a class, specified via "placeholderClass" config attribute.
             *
             * @method init
             * @protected
             * @param {CKEDITOR.dom.event} editor Blur event, fired from CKEditor
             */
            _onBlur: function(event) {
                var editor,
                    editorNode;

                editor = event.editor;

                if (editor.getData() === '') {
                    editorNode = new CKEDITOR.dom.element(editor.element.$);

                    // Despite getData() returns empty string, the content still may have
                    // content - an empty paragrapgh. This prevents :empty selector in
                    // placeholder's CSS and placeholder does not appear.
                    // For that reason we will intentionally remove any content from editorNode.
                    editorNode.setHtml('');

                    editorNode.addClass(editor.config.placeholderClass);
                }
            }
        }
    );
}());
;(function() {
    'use strict';

    var modules = {
    'alloy-editor': {
        path: 'adapter/yui.js',
        requires: ['base-build', 'node-base']
    },

    'button-base': {
        group: 'AlloyEditor',
        path: 'buttons/button-base.js',
        requires: ['base-build', 'plugin', 'button']
    },

    'button-strong': {
        group: 'AlloyEditor',
        path: 'buttons/button-strong.js',
        requires: ['button-base']
    },

    'button-em': {
        group: 'AlloyEditor',
        path: 'buttons/button-em.js',
        requires: ['button-base']
    },

    'button-a': {
        group: 'AlloyEditor',
        path: 'buttons/button-a.js',
        requires: ['button-base', 'event-valuechange', 'node-focusmanager']
    },

    'button-h1': {
        group: 'AlloyEditor',
        path: 'buttons/button-h1.js',
        requires: ['button-base']
    },

    'button-h2': {
        group: 'AlloyEditor',
        path: 'buttons/button-h2.js',
        requires: ['button-base']
    },

    'button-u': {
        group: 'AlloyEditor',
        path: 'buttons/button-underline.js',
        requires: ['button-base']
    },

    'button-twitterquote': {
        group: 'AlloyEditor',
        path: 'buttons/button-twitterquote.js',
        requires: ['button-base']
    },

    'button-hline': {
        group: 'AlloyEditor',
        path: 'buttons/button-hline.js',
        requires: ['button-base']
    },

    'button-image': {
        group: 'AlloyEditor',
        path: 'buttons/button-image.js',
        requires: ['button-base', 'node-event-simulate']
    },

    'button-media': {
        group: 'AlloyEditor',
        path: 'buttons/button-media.js',
        requires: ['button-base']
    },

    'button-quote': {
        group: 'AlloyEditor',
        path: 'buttons/button-quote.js',
        requires: ['button-base']
    },

    'button-code': {
        group: 'AlloyEditor',
        path: 'buttons/button-code.js',
        requires: ['button-base']
    },

    'button-twitter': {
        group: 'AlloyEditor',
        path: 'buttons/button-twitter.js',
        requires: ['button-base']
    },

    'button-left': {
        group: 'AlloyEditor',
        path: 'buttons/button-left.js',
        requires: ['button-base']
    },

    'button-right': {
        group: 'AlloyEditor',
        path: 'buttons/button-right.js',
        requires: ['button-base']
    },

    'button-rotate': {
        group: 'AlloyEditor',
        path: 'buttons/button-rotate.js',
        requires: ['button-base']
    },

    'button-filter': {
        group: 'AlloyEditor',
        path: 'buttons/button-filter.js',
        requires: ['button-base']
    },

    'toolbar-base': {
        group: 'AlloyEditor',
        path: 'toolbars/toolbar-base.js',
        requires: ['plugin', 'node-base', 'transition']
    },

    'toolbar-position': {
        group: 'AlloyEditor',
        path: 'toolbars/toolbar-position.js',
        requires: ['node-base']
    },

    'toolbar-add': {
        group: 'AlloyEditor',
        path: 'toolbars/toolbar-add.js',
        requires: ['widget-base', 'widget-position', 'widget-position-constrain', 'widget-position-align', 'toolbar-base']
    },

    'toolbar-styles': {
        group: 'AlloyEditor',
        path: 'toolbars/toolbar-styles.js',
        requires: ['toolbar-base', 'widget-base', 'widget-position', 'widget-position-constrain']
    },

    'toolbar-image': {
        group: 'AlloyEditor',
        path: 'toolbars/toolbar-image.js',
        requires: ['dom-screen', 'widget-base', 'widget-position', 'widget-position-constrain', 'toolbar-base']
    },

    'selector-patch': {
        condition: {
            trigger: 'selector-native'
        },
        group: 'AlloyEditor',
        path: 'plugins/selector-patch.js'
    }
};

    function applyConfigGroup() {
        YUI.applyConfig({
            groups: {
                AlloyEditor: {
                    base: 'alloy-editor/',
                    combine: false,
                    comboBase: '',
                    modules: modules,
                    root: '/alloy-editor/'
                }
            }
        });
    }

    function applyConfigModules() {
        YUI.applyConfig({
            modules: modules
        });
    }

    if (YUI && YUI.GlobalConfig) {
        var groups = YUI.GlobalConfig.groups;

        if (groups && groups.AlloyEditor) {
            applyConfigModules();
        }
        else {
            applyConfigGroup();
        }
    }
    else {
        applyConfigGroup();
    }
}());
(function() {
    'use strict';

    if (CKEDITOR.plugins.get('linktooltip')) {
        return;
    }

    YUI.add('linktooltip', function(Y) {
        var Lang = Y.Lang,

            /**
             * The LinkTooltip class provides functionality for showing tooltip over link elements in editor.
             * The class will be also registered as CKEDITOR plugin -
             * {{#crossLink "CKEDITOR.plugins.linktooltip"}}{{/crossLink}}
             *
             * @class LinkTooltip
             */
            LinkTooltip = Y.Base.create('linktooltip', Y.Widget, [Y.WidgetPosition, Y.WidgetPositionConstrain,
                Y.WidgetAutohide], {
                /**
                 * Initializer lifecycle implementation for the LinkTooltip class.
                 *
                 * @method initializer
                 * @protected
                 * @param config {Object} Configuration object literal for the editor
                 */
                initializer: function() {
                    this._eventHandles = [];
                },

                /**
                 * Destructor lifecycle implementation for the LinkTooltip class. Destroys the iattached event
                 * listeners.
                 *
                 * @method destructor
                 * @protected
                 */
                destructor: function() {
                    (new Y.EventHandle(this._eventHandles)).detach();
                },

                /**
                 * Renders the link tooltip node on contentBox.
                 *
                 * @method renderUI
                 * @protected
                 */
                renderUI: function() {
                    var content;

                    content = Y.Node.create(this.TPL_CONTENT);

                    this.get('contentBox').appendChild(content);

                    this._linkPreview = content.one('.link-preview');
                },

                /**
                 * Attaches event listeners such as mouseenter on link elements. Links, which have
                 * "data-cke-default-link" attribute will be ignored. These links are considered as
                 * internal; they are being created by automatically when user triggers link creation.
                 * See {{#crossLink "ButtonA/_onClick:method"}}{{/crossLink}} for more information.
                 *
                 * @method bindUI
                 * @protected
                 */
                bindUI: function() {
                    var editor;

                    this._bindBBMouseEnter();

                    editor = this.get('editor');

                    this._eventHandles.push(
                        Y.one(editor.element.$).delegate('mouseenter', this._onLinkMouseEnter,
                            'a[href]:not([data-cke-default-link])', this, editor)
                    );

                    this.get('boundingBox').on('clickoutside', this._onClickOutside, this);
                },

                /**
                 * Adds mouseleave listener to the boundingBox.
                 *
                 * @method _bindBBMouseLeave
                 * @protected
                 */
                _bindBBMouseLeave: function() {
                    var boundingBox;

                    boundingBox = this.get('boundingBox');

                    this._bbMouseLeaveHandle = boundingBox.once('mouseleave', this._onBBMouseLeave, this);
                },

                /**
                 * Adds mouseenter listener to the boundingBox.
                 *
                 * @method _bindBBMouseEnter
                 * @protected
                 */
                _bindBBMouseEnter: function() {
                    var boundingBox;

                    boundingBox = this.get('boundingBox');

                    this._bbMouseEnterHandle = boundingBox.on('mouseenter', this._onBBMouseEnter, this);
                },

                /**
                 * Hides the linktooltip container after some timeout, specified by
                 * {{#crossLink "LinkTooltip/hideTimeout:attribute"}}{{/crossLink}} attribute.
                 *
                 * @method _attachHiddenHandle
                 * @protected
                 */
                _attachHiddenHandle: function() {
                    var instance = this;

                    this._hideHandle = setTimeout(
                        function() {
                            instance.hide();
                        },
                        this.get('hideTimeout')
                    );
                },

                /**
                 * Calculates and returns the most appropriate position where link tooltip should appear.
                 * The position depends on the specified {{#crossLink "LinkTooltip/gutter:attribute"}}{{/crossLink}},
                 * and on the fact if the link occupies more than one line in the editor.
                 *
                 * @method _getXY
                 * @protected
                 * @param {Number} x Point X in page coordinates.
                 * @param {Number} y Point Y in page coordinates.
                 * @param {Node} y The link over which the tooltip should be shown.
                 * returns {Array} An Array with the most appropriate x and y points in page coordinates.
                 */
                _getXY: function(x, y, link) {
                    var gutter,
                        i,
                        line,
                        lineHeight,
                        lines,
                        region;

                    lineHeight = parseInt(link.getComputedStyle('lineHeight'), 10);

                    gutter = this.get('gutter');

                    region = link.get('region');

                    gutter = gutter.top;

                    if (Lang.isNumber(lineHeight)) {
                        line = 1;

                        lines = Math.ceil((region.bottom - region.top) / lineHeight);

                        for (i = 1; i <= lines; i++) {
                            if (y < region.top + lineHeight * i) {
                                break;
                            }

                            ++line;
                        }

                        y = region.top + line * lineHeight + gutter;
                    } else {
                        y = region.bottom + gutter;
                    }

                    return [x, y];
                },

                /**
                 * Handles mouse enter event on the boundingBox.
                 * Clears any already started hide handle and attaches mouse leave listener to the boundingBox.
                 *
                 * @method _onBBMouseEnter
                 * @protected
                 */
                _onBBMouseEnter: function() {
                    clearTimeout(this._hideHandle);

                    this._bindBBMouseLeave();
                },

                /**
                 * Handles mouse leave event on the boundingBox.
                 * Clears any already started hide handle and attaches it again.
                 *
                 * @method _onBBMouseEnter
                 * @protected
                 */
                _onBBMouseLeave: function() {
                    clearTimeout(this._hideHandle);

                    this._attachHiddenHandle();
                },

                /**
                 * Hides the tooltip on clicking outside of the boundingBox.
                 *
                 * @method _onClickOutside
                 * @protected
                 */
                _onClickOutside: function() {
                    this.hide();
                },

                /**
                 * Reads the link href, updates tooltip content with the read value,
                 * shows the tooltip and attaches mouse leave listener on the boundingBox.
                 *
                 * @method _onLinkMouseEnter
                 * @protected
                 * @param {EventFacade} event Event that triggered when user positioned the mouse over the link.
                 */
                _onLinkMouseEnter: function(event) {
                    var instance = this,
                        link,
                        linkText,
                        xy;

                    if (this._editMode) {
                        return;
                    }

                    clearTimeout(instance._hideHandle);

                    link = event.currentTarget;

                    linkText = link.getAttribute('href');

                    this._linkPreview.setAttribute('href', linkText);

                    this._linkPreview.set('innerHTML', Y.Escape.html(linkText));

                    instance.show();

                    xy = instance._getXY(event.pageX, event.pageY, link);

                    instance.set('xy', xy);

                    link.once('mouseleave', function() {
                        clearTimeout(instance._hideHandle);

                        instance._attachHiddenHandle();
                    });
                },

                BOUNDING_TEMPLATE: '<div class="alloy-editor-tooltip-link"></div>',

                TPL_CONTENT: '<div class="link-container">' +
                    '<span class="icon-link-container">' +
                    '<i class="alloy-editor-icon-link"></i>' +
                    '</span>' +
                    '<a class="link-preview" target="_blank"></a>' +
                    '</div>'
            }, {
                ATTRS: {
                    /**
                     * Specifies whether the toolbar show be constrained to some node or to the viewport.
                     *
                     * @attribute constrain
                     * @default true (will be constrained to the viewport)
                     * @type Boolean
                     */
                    constrain: {
                        validator: Lang.isBoolean,
                        value: true
                    },

                    /**
                     * Contains the native editor implementation.
                     *
                     * @attribute editor
                     * @default true
                     * @type Object
                     */
                    editor: {
                        validator: Y.Lang.isObject
                    },

                    /**
                     * Specifies the gutter of the tooltip. The gutter object contains the top and left
                     * offsets from the point, where the tooltip is supposed to appear.
                     *
                     * @attribute gutter
                     * @default {
                     *   left: 0,
                     *   top: 0
                     * }
                     * @type Object
                     */
                    gutter: {
                        validator: Lang.isObject,
                        value: {
                            left: 0,
                            top: 0
                        }
                    },

                    /**
                     * Specifies the timeout after which the link tooltip will be hidden.
                     *
                     * @attribute hideTimeout
                     * @default 2000 (sec)
                     * @type Number
                     */
                    hideTimeout: {
                        validator: Lang.isNumber,
                        value: 2000
                    }
                }
            });

        Y.LinkTooltip = LinkTooltip;

    }, '', {
        requires: ['dom-screen', 'escape', 'event-outside', 'node-event-delegate', 'event-mouseenter', 'widget-base',
            'widget-position', 'widget-position-constrain', 'widget-autohide']
    });

    /**
     * CKEDITOR plugin which allows displaying tooltip over links in the editor.
     * Internally it uses {{#crossLink "LinkTooltip"}}{{/crossLink}}. You may specify all
     * properties which {{#crossLink "LinkTooltip"}}{{/crossLink}} accepts via editor.config.linktooltip property.
     *
     * @class CKEDITOR.plugins.linktooltip
     */
    CKEDITOR.plugins.add(
        'linktooltip', {
            init: function(editor) {
                YUI().use('linktooltip', function(Y) {
                    var config,
                        tooltip;

                    config = Y.merge({
                        editor: editor,
                        visible: false
                    }, editor.config.linktooltip);

                    tooltip = new Y.LinkTooltip(config).render();

                    editor.on('destroy', function() {
                        tooltip.destroy();
                    });
                });
            }
        }
    );
}());
(function() {
    'use strict';

    var hasOwnProperty = Object.prototype.hasOwnProperty;

    if (CKEDITOR.plugins.get('uiloader')) {
        return;
    }

    /**
     * The CKEDITOR.plugins.uiloader plugin loads the editor UI on demand, depending on the
     * configuration of the Toolbars and Buttons.
     *
     * @class CKEDITOR.plugins.uiloader
     */
    CKEDITOR.plugins.add(
        'uiloader', {
            /**
             * Initializer lifecycle implementation for the UILoader plugin.
             *
             * @method init
             * @protected
             */
            init: function(editor) {
                var instance = this,
                    modules;

                modules = ['node-base'].concat(this._getModules(editor));

                YUI().use(
                    modules,
                    function(Y) {
                        instance._createToolbars(Y, editor);

                        editor.fire('toolbarsReady', {
                            toolbars: editor.config.toolbars
                        });
                    }
                );
            },

            /**
             * Creates instances of toolbars as specified by the editor configuration.
             * A simple editor toolbar configuration may look like this:
             * <pre><code>
             *   toolbars: {
             *       add: ['image', 'code']
             *   }
             * </code></pre>
             * In this case we have very simple configuration - the editor will have
             * only one toolbar, with two buttons - for adding images and code into the
             * editor. These buttons will also not have any specific configuration.
             * In order to pass configuration attributes to the toolbars, the configuration
             * may be specified like this:
             * <pre><code>
             *   toolbars: {
             *      add: {
             *           buttons: ['image', 'code'],
             *           zIndex: 1024
             *       }
             *   }
             * </code></pre>
             * In this case, toolbar "add" receives two attributes - the first one is the
             * list of buttons (each button also can be specified via an configuration object)
             * and another attribute, which specifies its zIndex.
             *
             * @method _createToolbars
             * @protected
             */
            _createToolbars: function(Y, editor) {
                var defaultConfig,
                    i,
                    toolbarsConfig;

                defaultConfig = {
                    editor: editor,
                    render: true,
                    visible: false
                };

                toolbarsConfig = editor.config.toolbars;

                for (i in toolbarsConfig) {
                    if (hasOwnProperty.call(toolbarsConfig, i)) {
                        if (CKEDITOR.tools.isArray(toolbarsConfig[i])) {
                            editor.config.toolbars[i] = new Y[this._getToolbarName(i)](
                                Y.merge(defaultConfig, {
                                    buttons: toolbarsConfig[i]
                                })
                            );
                        } else if (toolbarsConfig[i]) {
                            editor.config.toolbars[i] = new Y[this._getToolbarName(i)](
                                Y.merge(defaultConfig, toolbarsConfig[i])
                            );
                        }
                    }
                }
            },

            /**
             * Resolves the name of a button module passed through configuration.
             *
             * @method  _getButtonName
             * @protected
             * @param  {String|Object} button A string representing the button or an object
             * with a name attribute.
             * @return {String} The name of the button.
             */
            _getButtonName: function(button) {
                var buttonName = button;

                if (typeof button !== 'string') {
                    buttonName = button.name;
                }

                return buttonName
            },

            /**
             * Retrieves a list of modules for all registered buttons and toolbars in the current
             * editor configuration.
             * The module will be automatically discovered if it follows this specification:
             * - if this is a Toolbar, the module should start with the word "module", followed by "-"
             * and then the name of the toolbar. Example: 'toolbar-add'.
             * - if the module is an button, then the module should start with the word "button",
             * followed by "-" and then the name of the button. Example: "button-image".
             * - In order to be instantiated successfully, the toolbar should expose itself as an object,
             * attached to the current YUI/AlloyUI instance. The name should start with the name Toolbar,
             * followed by the name of the toolbar, as specified in the configuration. Example: Y.ToolbarAdd.
             * - In order to be instantiated successfully, the button should expose itself as an object,
             * attached to the current YUI/AlloyUI instance. The name should start with the name Button,
             * followed by the name of the button, as specified in the configuration. Example: Y.ButtonImage.
             *
             * @method _getModules
             * @protected
             * @return {Array} An array of all discovered modules of toolbars and buttons, as specified by
             * the current editor configuration.
             */
            _getModules: function(editor) {
                var i,
                    j,
                    modules,
                    toolbarsConfig;

                modules = [];

                toolbarsConfig = editor.config.toolbars;

                for (i in toolbarsConfig) {
                    if (hasOwnProperty.call(toolbarsConfig, i)) {
                        modules.push('toolbar-' + i); // put toolbar module

                        if (CKEDITOR.tools.isArray(toolbarsConfig[i])) {
                            for (j = toolbarsConfig[i].length - 1; j >= 0; j--) { // put button modules
                                modules.push('button-' + this._getButtonName(toolbarsConfig[i][j]));
                            }
                        } else if (toolbarsConfig[i]) {
                            for (j = toolbarsConfig[i].buttons.length - 1; j >= 0; j--) { // put button modules
                                modules.push('button-' + this._getButtonName(toolbarsConfig[i].buttons[j]));
                            }
                        }
                    }
                }

                return modules;
            },

            /**
             * Resolves the name of the Toolbar from the current editor configuration.
             * See {{#crossLink "CKEDITOR.plugins.uiloader/_getModules:method"}}{{/crossLink}}
             * for more information about the rules for constructing toolbar names.
             *
             * @method _getToolbarName
             * @protected
             * @return {String} The constructed name of the Toolbar.
             */
            _getToolbarName: function(name) {
                return 'Toolbar' + name.substring(0, 1).toUpperCase() + name.substring(1);
            }
        }
    );
}());
YUI.add('selector-patch', function(Y) {
    'use strict';

    Y.mix(Y.Selector, {
        test: function(node, selector, root) {
            var defaultId,
                ret = false,
                useFrag = false,
                groups,
                parent,
                item,
                items,
                frag,
                id,
                i, j, group;

            if (node && node.tagName) { // only test HTMLElements

                if (typeof selector == 'function') { // test with function
                    ret = selector.call(node, node);
                } else { // test with query
                    // we need a root if off-doc
                    groups = selector.split(',');
                    if (!root && !Y.DOM.inDoc(node)) {
                        parent = node.parentNode;
                        if (parent) {
                            root = parent;
                        } else { // only use frag when no parent to query
                            frag = node.ownerDocument.createDocumentFragment();
                            frag.appendChild(node);
                            root = frag;
                            useFrag = true;
                        }
                    }
                    root = root || node.ownerDocument;

                    id = Y.Selector._escapeId(Y.DOM.getId(node));
                    if (!id) {
                        defaultId = true;
                        id = Y.guid();
                        Y.DOM.setId(node, id);
                    }

                    for (i = 0; (group = groups[i++]);) { // TODO: off-dom test
                        group += '[id="' + id + '"]';
                        items = Y.Selector.query(group, root);

                        for (j = 0; (item = items[j++]);) {
                            if (item === node) {
                                ret = true;
                                break;
                            }
                        }
                        if (ret) {
                            break;
                        }
                    }

                    if (useFrag) { // cleanup
                        frag.removeChild(node);
                    }

                    if (defaultId) { // cleanup, remove auto added ID
                        node.removeAttribute('id');
                    }
                }
            }

            return ret;
        }
    }, true);
}, '', {
    requires: ['selector-native']
});