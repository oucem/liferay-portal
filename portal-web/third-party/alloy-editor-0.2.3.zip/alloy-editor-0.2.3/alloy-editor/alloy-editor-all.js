/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
(function(){if(window.CKEDITOR&&window.CKEDITOR.dom)return;window.CKEDITOR||(window.CKEDITOR=function(){var a={timestamp:"E5OD",version:"4.4.2",revision:"1567b48",rnd:Math.floor(900*Math.random())+100,_:{pending:[]},status:"unloaded",basePath:function(){var a=window.CKEDITOR_BASEPATH||"";if(!a)for(var d=document.getElementsByTagName("script"),e=0;e<d.length;e++){var b=d[e].src.match(/(^|.*[\\\/])ckeditor(?:_basic)?(?:_source)?.js(?:\?.*)?$/i);if(b){a=b[1];break}}-1==a.indexOf(":/")&&"//"!=a.slice(0,2)&&(a=0===a.indexOf("/")?location.href.match(/^.*?:\/\/[^\/]*/)[0]+
a:location.href.match(/^[^\?]*\/(?:)/)[0]+a);if(!a)throw'The CKEditor installation path could not be automatically detected. Please set the global variable "CKEDITOR_BASEPATH" before creating editor instances.';return a}(),getUrl:function(a){-1==a.indexOf(":/")&&0!==a.indexOf("/")&&(a=this.basePath+a);this.timestamp&&("/"!=a.charAt(a.length-1)&&!/[&?]t=/.test(a))&&(a+=(0<=a.indexOf("?")?"&":"?")+"t="+this.timestamp);return a},domReady:function(){function a(){try{document.addEventListener?(document.removeEventListener("DOMContentLoaded",
a,!1),d()):document.attachEvent&&"complete"===document.readyState&&(document.detachEvent("onreadystatechange",a),d())}catch(e){}}function d(){for(var a;a=e.shift();)a()}var e=[];return function(d){e.push(d);"complete"===document.readyState&&setTimeout(a,1);if(1==e.length)if(document.addEventListener)document.addEventListener("DOMContentLoaded",a,!1),window.addEventListener("load",a,!1);else if(document.attachEvent){document.attachEvent("onreadystatechange",a);window.attachEvent("onload",a);d=!1;try{d=
!window.frameElement}catch(b){}if(document.documentElement.doScroll&&d){var c=function(){try{document.documentElement.doScroll("left")}catch(d){setTimeout(c,1);return}a()};c()}}}}()},c=window.CKEDITOR_GETURL;if(c){var b=a.getUrl;a.getUrl=function(f){return c.call(a,f)||b.call(a,f)}}return a}());
CKEDITOR.event||(CKEDITOR.event=function(){},CKEDITOR.event.implementOn=function(a){var c=CKEDITOR.event.prototype,b;for(b in c)a[b]==void 0&&(a[b]=c[b])},CKEDITOR.event.prototype=function(){function a(a){var d=c(this);return d[a]||(d[a]=new b(a))}var c=function(a){a=a.getPrivate&&a.getPrivate()||a._||(a._={});return a.events||(a.events={})},b=function(a){this.name=a;this.listeners=[]};b.prototype={getListenerIndex:function(a){for(var d=0,e=this.listeners;d<e.length;d++)if(e[d].fn==a)return d;return-1}};
return{define:function(b,d){var e=a.call(this,b);CKEDITOR.tools.extend(e,d,true)},on:function(b,d,e,c,n){function h(a,m,o,p){a={name:b,sender:this,editor:a,data:m,listenerData:c,stop:o,cancel:p,removeListener:i};return d.call(e,a)===false?false:a.data}function i(){p.removeListener(b,d)}var m=a.call(this,b);if(m.getListenerIndex(d)<0){m=m.listeners;e||(e=this);isNaN(n)&&(n=10);var p=this;h.fn=d;h.priority=n;for(var s=m.length-1;s>=0;s--)if(m[s].priority<=n){m.splice(s+1,0,h);return{removeListener:i}}m.unshift(h)}return{removeListener:i}},
once:function(){var a=arguments[1];arguments[1]=function(d){d.removeListener();return a.apply(this,arguments)};return this.on.apply(this,arguments)},capture:function(){CKEDITOR.event.useCapture=1;var a=this.on.apply(this,arguments);CKEDITOR.event.useCapture=0;return a},fire:function(){var a=0,d=function(){a=1},e=0,b=function(){e=1};return function(n,h,i){var m=c(this)[n],n=a,p=e;a=e=0;if(m){var s=m.listeners;if(s.length)for(var s=s.slice(0),x,q=0;q<s.length;q++){if(m.errorProof)try{x=s[q].call(this,
i,h,d,b)}catch(o){}else x=s[q].call(this,i,h,d,b);x===false?e=1:typeof x!="undefined"&&(h=x);if(a||e)break}}h=e?false:typeof h=="undefined"?true:h;a=n;e=p;return h}}(),fireOnce:function(a,d,e){d=this.fire(a,d,e);delete c(this)[a];return d},removeListener:function(a,d){var e=c(this)[a];if(e){var b=e.getListenerIndex(d);b>=0&&e.listeners.splice(b,1)}},removeAllListeners:function(){var a=c(this),d;for(d in a)delete a[d]},hasListeners:function(a){return(a=c(this)[a])&&a.listeners.length>0}}}());
CKEDITOR.editor||(CKEDITOR.editor=function(){CKEDITOR._.pending.push([this,arguments]);CKEDITOR.event.call(this)},CKEDITOR.editor.prototype.fire=function(a,c){a in{instanceReady:1,loaded:1}&&(this[a]=true);return CKEDITOR.event.prototype.fire.call(this,a,c,this)},CKEDITOR.editor.prototype.fireOnce=function(a,c){a in{instanceReady:1,loaded:1}&&(this[a]=true);return CKEDITOR.event.prototype.fireOnce.call(this,a,c,this)},CKEDITOR.event.implementOn(CKEDITOR.editor.prototype));
CKEDITOR.env||(CKEDITOR.env=function(){var a=navigator.userAgent.toLowerCase(),c={ie:a.indexOf("trident/")>-1,webkit:a.indexOf(" applewebkit/")>-1,air:a.indexOf(" adobeair/")>-1,mac:a.indexOf("macintosh")>-1,quirks:document.compatMode=="BackCompat"&&(!document.documentMode||document.documentMode<10),mobile:a.indexOf("mobile")>-1,iOS:/(ipad|iphone|ipod)/.test(a),isCustomDomain:function(){if(!this.ie)return false;var a=document.domain,e=window.location.hostname;return a!=e&&a!="["+e+"]"},secure:location.protocol==
"https:"};c.gecko=navigator.product=="Gecko"&&!c.webkit&&!c.ie;if(c.webkit)a.indexOf("chrome")>-1?c.chrome=true:c.safari=true;var b=0;if(c.ie){b=c.quirks||!document.documentMode?parseFloat(a.match(/msie (\d+)/)[1]):document.documentMode;c.ie9Compat=b==9;c.ie8Compat=b==8;c.ie7Compat=b==7;c.ie6Compat=b<7||c.quirks}if(c.gecko){var f=a.match(/rv:([\d\.]+)/);if(f){f=f[1].split(".");b=f[0]*1E4+(f[1]||0)*100+(f[2]||0)*1}}c.air&&(b=parseFloat(a.match(/ adobeair\/(\d+)/)[1]));c.webkit&&(b=parseFloat(a.match(/ applewebkit\/(\d+)/)[1]));
c.version=b;c.isCompatible=c.iOS&&b>=534||!c.mobile&&(c.ie&&b>6||c.gecko&&b>=2E4||c.air&&b>=1||c.webkit&&b>=522||false);c.hidpi=window.devicePixelRatio>=2;c.needsBrFiller=c.gecko||c.webkit||c.ie&&b>10;c.needsNbspFiller=c.ie&&b<11;c.cssClass="cke_browser_"+(c.ie?"ie":c.gecko?"gecko":c.webkit?"webkit":"unknown");if(c.quirks)c.cssClass=c.cssClass+" cke_browser_quirks";if(c.ie)c.cssClass=c.cssClass+(" cke_browser_ie"+(c.quirks?"6 cke_browser_iequirks":c.version));if(c.air)c.cssClass=c.cssClass+" cke_browser_air";
if(c.iOS)c.cssClass=c.cssClass+" cke_browser_ios";if(c.hidpi)c.cssClass=c.cssClass+" cke_hidpi";return c}());
"unloaded"==CKEDITOR.status&&function(){CKEDITOR.event.implementOn(CKEDITOR);CKEDITOR.loadFullCore=function(){if(CKEDITOR.status!="basic_ready")CKEDITOR.loadFullCore._load=1;else{delete CKEDITOR.loadFullCore;var a=document.createElement("script");a.type="text/javascript";a.src=CKEDITOR.basePath+"ckeditor.js";document.getElementsByTagName("head")[0].appendChild(a)}};CKEDITOR.loadFullCoreTimeout=0;CKEDITOR.add=function(a){(this._.pending||(this._.pending=[])).push(a)};(function(){CKEDITOR.domReady(function(){var a=
CKEDITOR.loadFullCore,c=CKEDITOR.loadFullCoreTimeout;if(a){CKEDITOR.status="basic_ready";a&&a._load?a():c&&setTimeout(function(){CKEDITOR.loadFullCore&&CKEDITOR.loadFullCore()},c*1E3)}})})();CKEDITOR.status="basic_loaded"}();CKEDITOR.dom={};
(function(){var a=[],c=CKEDITOR.env.gecko?"-moz-":CKEDITOR.env.webkit?"-webkit-":CKEDITOR.env.ie?"-ms-":"",b=/&/g,f=/>/g,d=/</g,e=/"/g,g=/&amp;/g,n=/&gt;/g,h=/&lt;/g,i=/&quot;/g;CKEDITOR.on("reset",function(){a=[]});CKEDITOR.tools={arrayCompare:function(a,d){if(!a&&!d)return true;if(!a||!d||a.length!=d.length)return false;for(var e=0;e<a.length;e++)if(a[e]!=d[e])return false;return true},clone:function(a){var d;if(a&&a instanceof Array){d=[];for(var e=0;e<a.length;e++)d[e]=CKEDITOR.tools.clone(a[e]);
return d}if(a===null||typeof a!="object"||a instanceof String||a instanceof Number||a instanceof Boolean||a instanceof Date||a instanceof RegExp||a.nodeType||a.window===a)return a;d=new a.constructor;for(e in a)d[e]=CKEDITOR.tools.clone(a[e]);return d},capitalize:function(a,d){return a.charAt(0).toUpperCase()+(d?a.slice(1):a.slice(1).toLowerCase())},extend:function(a){var d=arguments.length,e,b;if(typeof(e=arguments[d-1])=="boolean")d--;else if(typeof(e=arguments[d-2])=="boolean"){b=arguments[d-1];
d=d-2}for(var c=1;c<d;c++){var o=arguments[c],f;for(f in o)if(e===true||a[f]==void 0)if(!b||f in b)a[f]=o[f]}return a},prototypedCopy:function(a){var d=function(){};d.prototype=a;return new d},copy:function(a){var d={},e;for(e in a)d[e]=a[e];return d},isArray:function(a){return Object.prototype.toString.call(a)=="[object Array]"},isEmpty:function(a){for(var d in a)if(a.hasOwnProperty(d))return false;return true},cssVendorPrefix:function(a,d,e){if(e)return c+a+":"+d+";"+a+":"+d;e={};e[a]=d;e[c+a]=
d;return e},cssStyleToDomStyle:function(){var a=document.createElement("div").style,d=typeof a.cssFloat!="undefined"?"cssFloat":typeof a.styleFloat!="undefined"?"styleFloat":"float";return function(a){return a=="float"?d:a.replace(/-./g,function(a){return a.substr(1).toUpperCase()})}}(),buildStyleHtml:function(a){for(var a=[].concat(a),d,e=[],b=0;b<a.length;b++)if(d=a[b])/@import|[{}]/.test(d)?e.push("<style>"+d+"</style>"):e.push('<link type="text/css" rel=stylesheet href="'+d+'">');return e.join("")},
htmlEncode:function(a){return(""+a).replace(b,"&amp;").replace(f,"&gt;").replace(d,"&lt;")},htmlDecode:function(a){return a.replace(g,"&").replace(n,">").replace(h,"<")},htmlEncodeAttr:function(a){return a.replace(e,"&quot;").replace(d,"&lt;").replace(f,"&gt;")},htmlDecodeAttr:function(a){return a.replace(i,'"').replace(h,"<").replace(n,">")},getNextNumber:function(){var a=0;return function(){return++a}}(),getNextId:function(){return"cke_"+this.getNextNumber()},override:function(a,d){var e=d(a);e.prototype=
a.prototype;return e},setTimeout:function(a,d,e,b,c){c||(c=window);e||(e=c);return c.setTimeout(function(){b?a.apply(e,[].concat(b)):a.apply(e)},d||0)},trim:function(){var a=/(?:^[ \t\n\r]+)|(?:[ \t\n\r]+$)/g;return function(d){return d.replace(a,"")}}(),ltrim:function(){var a=/^[ \t\n\r]+/g;return function(d){return d.replace(a,"")}}(),rtrim:function(){var a=/[ \t\n\r]+$/g;return function(d){return d.replace(a,"")}}(),indexOf:function(a,d){if(typeof d=="function")for(var e=0,b=a.length;e<b;e++){if(d(a[e]))return e}else{if(a.indexOf)return a.indexOf(d);
e=0;for(b=a.length;e<b;e++)if(a[e]===d)return e}return-1},search:function(a,d){var e=CKEDITOR.tools.indexOf(a,d);return e>=0?a[e]:null},bind:function(a,d){return function(){return a.apply(d,arguments)}},createClass:function(a){var d=a.$,e=a.base,b=a.privates||a._,c=a.proto,a=a.statics;!d&&(d=function(){e&&this.base.apply(this,arguments)});if(b)var o=d,d=function(){var a=this._||(this._={}),d;for(d in b){var e=b[d];a[d]=typeof e=="function"?CKEDITOR.tools.bind(e,this):e}o.apply(this,arguments)};if(e){d.prototype=
this.prototypedCopy(e.prototype);d.prototype.constructor=d;d.base=e;d.baseProto=e.prototype;d.prototype.base=function(){this.base=e.prototype.base;e.apply(this,arguments);this.base=arguments.callee}}c&&this.extend(d.prototype,c,true);a&&this.extend(d,a,true);return d},addFunction:function(d,e){return a.push(function(){return d.apply(e||this,arguments)})-1},removeFunction:function(d){a[d]=null},callFunction:function(d){var e=a[d];return e&&e.apply(window,Array.prototype.slice.call(arguments,1))},cssLength:function(){var a=
/^-?\d+\.?\d*px$/,d;return function(e){d=CKEDITOR.tools.trim(e+"")+"px";return a.test(d)?d:e||""}}(),convertToPx:function(){var a;return function(d){if(!a){a=CKEDITOR.dom.element.createFromHtml('<div style="position:absolute;left:-9999px;top:-9999px;margin:0px;padding:0px;border:0px;"></div>',CKEDITOR.document);CKEDITOR.document.getBody().append(a)}if(!/%$/.test(d)){a.setStyle("width",d);return a.$.clientWidth}return d}}(),repeat:function(a,d){return Array(d+1).join(a)},tryThese:function(){for(var a,
d=0,e=arguments.length;d<e;d++){var b=arguments[d];try{a=b();break}catch(c){}}return a},genKey:function(){return Array.prototype.slice.call(arguments).join("-")},defer:function(a){return function(){var d=arguments,e=this;window.setTimeout(function(){a.apply(e,d)},0)}},normalizeCssText:function(a,d){var e=[],b,c=CKEDITOR.tools.parseCssText(a,true,d);for(b in c)e.push(b+":"+c[b]);e.sort();return e.length?e.join(";")+";":""},convertRgbToHex:function(a){return a.replace(/(?:rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\))/gi,
function(a,d,e,b){a=[d,e,b];for(d=0;d<3;d++)a[d]=("0"+parseInt(a[d],10).toString(16)).slice(-2);return"#"+a.join("")})},parseCssText:function(a,d,e){var b={};if(e){e=new CKEDITOR.dom.element("span");e.setAttribute("style",a);a=CKEDITOR.tools.convertRgbToHex(e.getAttribute("style")||"")}if(!a||a==";")return b;a.replace(/&quot;/g,'"').replace(/\s*([^:;\s]+)\s*:\s*([^;]+)\s*(?=;|$)/g,function(a,e,m){if(d){e=e.toLowerCase();e=="font-family"&&(m=m.toLowerCase().replace(/["']/g,"").replace(/\s*,\s*/g,","));
m=CKEDITOR.tools.trim(m)}b[e]=m});return b},writeCssText:function(a,d){var e,b=[];for(e in a)b.push(e+":"+a[e]);d&&b.sort();return b.join("; ")},objectCompare:function(a,d,e){var b;if(!a&&!d)return true;if(!a||!d)return false;for(b in a)if(a[b]!=d[b])return false;if(!e)for(b in d)if(a[b]!=d[b])return false;return true},objectKeys:function(a){var d=[],e;for(e in a)d.push(e);return d},convertArrayToObject:function(a,d){var e={};arguments.length==1&&(d=true);for(var b=0,c=a.length;b<c;++b)e[a[b]]=d;
return e},fixDomain:function(){for(var a;;)try{a=window.parent.document.domain;break}catch(d){a=a?a.replace(/.+?(?:\.|$)/,""):document.domain;if(!a)break;document.domain=a}return!!a},eventsBuffer:function(a,d){function e(){c=(new Date).getTime();b=false;d()}var b,c=0;return{input:function(){if(!b){var d=(new Date).getTime()-c;d<a?b=setTimeout(e,a-d):e()}},reset:function(){b&&clearTimeout(b);b=c=0}}},enableHtml5Elements:function(a,d){for(var e=["abbr","article","aside","audio","bdi","canvas","data",
"datalist","details","figcaption","figure","footer","header","hgroup","mark","meter","nav","output","progress","section","summary","time","video"],b=e.length,c;b--;){c=a.createElement(e[b]);d&&a.appendChild(c)}},checkIfAnyArrayItemMatches:function(a,d){for(var e=0,b=a.length;e<b;++e)if(a[e].match(d))return true;return false},checkIfAnyObjectPropertyMatches:function(a,d){for(var e in a)if(e.match(d))return true;return false},transparentImageData:"data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw=="}})();
CKEDITOR.dtd=function(){var a=CKEDITOR.tools.extend,c=function(a,d){for(var e=CKEDITOR.tools.clone(a),b=1;b<arguments.length;b++){var d=arguments[b],c;for(c in d)delete e[c]}return e},b={},f={},d={address:1,article:1,aside:1,blockquote:1,details:1,div:1,dl:1,fieldset:1,figure:1,footer:1,form:1,h1:1,h2:1,h3:1,h4:1,h5:1,h6:1,header:1,hgroup:1,hr:1,menu:1,nav:1,ol:1,p:1,pre:1,section:1,table:1,ul:1},e={command:1,link:1,meta:1,noscript:1,script:1,style:1},g={},n={"#":1},h={center:1,dir:1,noframes:1};
a(b,{a:1,abbr:1,area:1,audio:1,b:1,bdi:1,bdo:1,br:1,button:1,canvas:1,cite:1,code:1,command:1,datalist:1,del:1,dfn:1,em:1,embed:1,i:1,iframe:1,img:1,input:1,ins:1,kbd:1,keygen:1,label:1,map:1,mark:1,meter:1,noscript:1,object:1,output:1,progress:1,q:1,ruby:1,s:1,samp:1,script:1,select:1,small:1,span:1,strong:1,sub:1,sup:1,textarea:1,time:1,u:1,"var":1,video:1,wbr:1},n,{acronym:1,applet:1,basefont:1,big:1,font:1,isindex:1,strike:1,style:1,tt:1});a(f,d,b,h);c={a:c(b,{a:1,button:1}),abbr:b,address:f,
area:g,article:a({style:1},f),aside:a({style:1},f),audio:a({source:1,track:1},f),b:b,base:g,bdi:b,bdo:b,blockquote:f,body:f,br:g,button:c(b,{a:1,button:1}),canvas:b,caption:f,cite:b,code:b,col:g,colgroup:{col:1},command:g,datalist:a({option:1},b),dd:f,del:b,details:a({summary:1},f),dfn:b,div:a({style:1},f),dl:{dt:1,dd:1},dt:f,em:b,embed:g,fieldset:a({legend:1},f),figcaption:f,figure:a({figcaption:1},f),footer:f,form:f,h1:b,h2:b,h3:b,h4:b,h5:b,h6:b,head:a({title:1,base:1},e),header:f,hgroup:{h1:1,
h2:1,h3:1,h4:1,h5:1,h6:1},hr:g,html:a({head:1,body:1},f,e),i:b,iframe:n,img:g,input:g,ins:b,kbd:b,keygen:g,label:b,legend:b,li:f,link:g,map:f,mark:b,menu:a({li:1},f),meta:g,meter:c(b,{meter:1}),nav:f,noscript:a({link:1,meta:1,style:1},b),object:a({param:1},b),ol:{li:1},optgroup:{option:1},option:n,output:b,p:b,param:g,pre:b,progress:c(b,{progress:1}),q:b,rp:b,rt:b,ruby:a({rp:1,rt:1},b),s:b,samp:b,script:n,section:a({style:1},f),select:{optgroup:1,option:1},small:b,source:g,span:b,strong:b,style:n,
sub:b,summary:b,sup:b,table:{caption:1,colgroup:1,thead:1,tfoot:1,tbody:1,tr:1},tbody:{tr:1},td:f,textarea:n,tfoot:{tr:1},th:f,thead:{tr:1},time:c(b,{time:1}),title:n,tr:{th:1,td:1},track:g,u:b,ul:{li:1},"var":b,video:a({source:1,track:1},f),wbr:g,acronym:b,applet:a({param:1},f),basefont:g,big:b,center:f,dialog:g,dir:{li:1},font:b,isindex:g,noframes:f,strike:b,tt:b};a(c,{$block:a({audio:1,dd:1,dt:1,figcaption:1,li:1,video:1},d,h),$blockLimit:{article:1,aside:1,audio:1,body:1,caption:1,details:1,dir:1,
div:1,dl:1,fieldset:1,figcaption:1,figure:1,footer:1,form:1,header:1,hgroup:1,menu:1,nav:1,ol:1,section:1,table:1,td:1,th:1,tr:1,ul:1,video:1},$cdata:{script:1,style:1},$editable:{address:1,article:1,aside:1,blockquote:1,body:1,details:1,div:1,fieldset:1,figcaption:1,footer:1,form:1,h1:1,h2:1,h3:1,h4:1,h5:1,h6:1,header:1,hgroup:1,nav:1,p:1,pre:1,section:1},$empty:{area:1,base:1,basefont:1,br:1,col:1,command:1,dialog:1,embed:1,hr:1,img:1,input:1,isindex:1,keygen:1,link:1,meta:1,param:1,source:1,track:1,
wbr:1},$inline:b,$list:{dl:1,ol:1,ul:1},$listItem:{dd:1,dt:1,li:1},$nonBodyContent:a({body:1,head:1,html:1},c.head),$nonEditable:{applet:1,audio:1,button:1,embed:1,iframe:1,map:1,object:1,option:1,param:1,script:1,textarea:1,video:1},$object:{applet:1,audio:1,button:1,hr:1,iframe:1,img:1,input:1,object:1,select:1,table:1,textarea:1,video:1},$removeEmpty:{abbr:1,acronym:1,b:1,bdi:1,bdo:1,big:1,cite:1,code:1,del:1,dfn:1,em:1,font:1,i:1,ins:1,label:1,kbd:1,mark:1,meter:1,output:1,q:1,ruby:1,s:1,samp:1,
small:1,span:1,strike:1,strong:1,sub:1,sup:1,time:1,tt:1,u:1,"var":1},$tabIndex:{a:1,area:1,button:1,input:1,object:1,select:1,textarea:1},$tableContent:{caption:1,col:1,colgroup:1,tbody:1,td:1,tfoot:1,th:1,thead:1,tr:1},$transparent:{a:1,audio:1,canvas:1,del:1,ins:1,map:1,noscript:1,object:1,video:1},$intermediate:{caption:1,colgroup:1,dd:1,dt:1,figcaption:1,legend:1,li:1,optgroup:1,option:1,rp:1,rt:1,summary:1,tbody:1,td:1,tfoot:1,th:1,thead:1,tr:1}});return c}();
CKEDITOR.dom.event=function(a){this.$=a};
CKEDITOR.dom.event.prototype={getKey:function(){return this.$.keyCode||this.$.which},getKeystroke:function(){var a=this.getKey();if(this.$.ctrlKey||this.$.metaKey)a=a+CKEDITOR.CTRL;this.$.shiftKey&&(a=a+CKEDITOR.SHIFT);this.$.altKey&&(a=a+CKEDITOR.ALT);return a},preventDefault:function(a){var c=this.$;c.preventDefault?c.preventDefault():c.returnValue=false;a&&this.stopPropagation()},stopPropagation:function(){var a=this.$;a.stopPropagation?a.stopPropagation():a.cancelBubble=true},getTarget:function(){var a=
this.$.target||this.$.srcElement;return a?new CKEDITOR.dom.node(a):null},getPhase:function(){return this.$.eventPhase||2},getPageOffset:function(){var a=this.getTarget().getDocument().$;return{x:this.$.pageX||this.$.clientX+(a.documentElement.scrollLeft||a.body.scrollLeft),y:this.$.pageY||this.$.clientY+(a.documentElement.scrollTop||a.body.scrollTop)}}};CKEDITOR.CTRL=1114112;CKEDITOR.SHIFT=2228224;CKEDITOR.ALT=4456448;CKEDITOR.EVENT_PHASE_CAPTURING=1;CKEDITOR.EVENT_PHASE_AT_TARGET=2;
CKEDITOR.EVENT_PHASE_BUBBLING=3;CKEDITOR.dom.domObject=function(a){if(a)this.$=a};
CKEDITOR.dom.domObject.prototype=function(){var a=function(a,b){return function(f){typeof CKEDITOR!="undefined"&&a.fire(b,new CKEDITOR.dom.event(f))}};return{getPrivate:function(){var a;if(!(a=this.getCustomData("_")))this.setCustomData("_",a={});return a},on:function(c){var b=this.getCustomData("_cke_nativeListeners");if(!b){b={};this.setCustomData("_cke_nativeListeners",b)}if(!b[c]){b=b[c]=a(this,c);this.$.addEventListener?this.$.addEventListener(c,b,!!CKEDITOR.event.useCapture):this.$.attachEvent&&
this.$.attachEvent("on"+c,b)}return CKEDITOR.event.prototype.on.apply(this,arguments)},removeListener:function(a){CKEDITOR.event.prototype.removeListener.apply(this,arguments);if(!this.hasListeners(a)){var b=this.getCustomData("_cke_nativeListeners"),f=b&&b[a];if(f){this.$.removeEventListener?this.$.removeEventListener(a,f,false):this.$.detachEvent&&this.$.detachEvent("on"+a,f);delete b[a]}}},removeAllListeners:function(){var a=this.getCustomData("_cke_nativeListeners"),b;for(b in a){var f=a[b];this.$.detachEvent?
this.$.detachEvent("on"+b,f):this.$.removeEventListener&&this.$.removeEventListener(b,f,false);delete a[b]}CKEDITOR.event.prototype.removeAllListeners.call(this)}}}();
(function(a){var c={};CKEDITOR.on("reset",function(){c={}});a.equals=function(a){try{return a&&a.$===this.$}catch(c){return false}};a.setCustomData=function(a,f){var d=this.getUniqueId();(c[d]||(c[d]={}))[a]=f;return this};a.getCustomData=function(a){var f=this.$["data-cke-expando"];return(f=f&&c[f])&&a in f?f[a]:null};a.removeCustomData=function(a){var f=this.$["data-cke-expando"],f=f&&c[f],d,e;if(f){d=f[a];e=a in f;delete f[a]}return e?d:null};a.clearCustomData=function(){this.removeAllListeners();
var a=this.$["data-cke-expando"];a&&delete c[a]};a.getUniqueId=function(){return this.$["data-cke-expando"]||(this.$["data-cke-expando"]=CKEDITOR.tools.getNextNumber())};CKEDITOR.event.implementOn(a)})(CKEDITOR.dom.domObject.prototype);
CKEDITOR.dom.node=function(a){return a?new CKEDITOR.dom[a.nodeType==CKEDITOR.NODE_DOCUMENT?"document":a.nodeType==CKEDITOR.NODE_ELEMENT?"element":a.nodeType==CKEDITOR.NODE_TEXT?"text":a.nodeType==CKEDITOR.NODE_COMMENT?"comment":a.nodeType==CKEDITOR.NODE_DOCUMENT_FRAGMENT?"documentFragment":"domObject"](a):this};CKEDITOR.dom.node.prototype=new CKEDITOR.dom.domObject;CKEDITOR.NODE_ELEMENT=1;CKEDITOR.NODE_DOCUMENT=9;CKEDITOR.NODE_TEXT=3;CKEDITOR.NODE_COMMENT=8;CKEDITOR.NODE_DOCUMENT_FRAGMENT=11;
CKEDITOR.POSITION_IDENTICAL=0;CKEDITOR.POSITION_DISCONNECTED=1;CKEDITOR.POSITION_FOLLOWING=2;CKEDITOR.POSITION_PRECEDING=4;CKEDITOR.POSITION_IS_CONTAINED=8;CKEDITOR.POSITION_CONTAINS=16;
CKEDITOR.tools.extend(CKEDITOR.dom.node.prototype,{appendTo:function(a,c){a.append(this,c);return a},clone:function(a,c){var b=this.$.cloneNode(a),f=function(d){d["data-cke-expando"]&&(d["data-cke-expando"]=false);if(d.nodeType==CKEDITOR.NODE_ELEMENT){c||d.removeAttribute("id",false);if(a)for(var d=d.childNodes,e=0;e<d.length;e++)f(d[e])}};f(b);return new CKEDITOR.dom.node(b)},hasPrevious:function(){return!!this.$.previousSibling},hasNext:function(){return!!this.$.nextSibling},insertAfter:function(a){a.$.parentNode.insertBefore(this.$,
a.$.nextSibling);return a},insertBefore:function(a){a.$.parentNode.insertBefore(this.$,a.$);return a},insertBeforeMe:function(a){this.$.parentNode.insertBefore(a.$,this.$);return a},getAddress:function(a){for(var c=[],b=this.getDocument().$.documentElement,f=this.$;f&&f!=b;){var d=f.parentNode;d&&c.unshift(this.getIndex.call({$:f},a));f=d}return c},getDocument:function(){return new CKEDITOR.dom.document(this.$.ownerDocument||this.$.parentNode.ownerDocument)},getIndex:function(a){var c=this.$,b=-1,
f;if(!this.$.parentNode)return b;do if(!a||!(c!=this.$&&c.nodeType==CKEDITOR.NODE_TEXT&&(f||!c.nodeValue))){b++;f=c.nodeType==CKEDITOR.NODE_TEXT}while(c=c.previousSibling);return b},getNextSourceNode:function(a,c,b){if(b&&!b.call)var f=b,b=function(a){return!a.equals(f)};var a=!a&&this.getFirst&&this.getFirst(),d;if(!a){if(this.type==CKEDITOR.NODE_ELEMENT&&b&&b(this,true)===false)return null;a=this.getNext()}for(;!a&&(d=(d||this).getParent());){if(b&&b(d,true)===false)return null;a=d.getNext()}return!a||
b&&b(a)===false?null:c&&c!=a.type?a.getNextSourceNode(false,c,b):a},getPreviousSourceNode:function(a,c,b){if(b&&!b.call)var f=b,b=function(a){return!a.equals(f)};var a=!a&&this.getLast&&this.getLast(),d;if(!a){if(this.type==CKEDITOR.NODE_ELEMENT&&b&&b(this,true)===false)return null;a=this.getPrevious()}for(;!a&&(d=(d||this).getParent());){if(b&&b(d,true)===false)return null;a=d.getPrevious()}return!a||b&&b(a)===false?null:c&&a.type!=c?a.getPreviousSourceNode(false,c,b):a},getPrevious:function(a){var c=
this.$,b;do b=(c=c.previousSibling)&&c.nodeType!=10&&new CKEDITOR.dom.node(c);while(b&&a&&!a(b));return b},getNext:function(a){var c=this.$,b;do b=(c=c.nextSibling)&&new CKEDITOR.dom.node(c);while(b&&a&&!a(b));return b},getParent:function(a){var c=this.$.parentNode;return c&&(c.nodeType==CKEDITOR.NODE_ELEMENT||a&&c.nodeType==CKEDITOR.NODE_DOCUMENT_FRAGMENT)?new CKEDITOR.dom.node(c):null},getParents:function(a){var c=this,b=[];do b[a?"push":"unshift"](c);while(c=c.getParent());return b},getCommonAncestor:function(a){if(a.equals(this))return this;
if(a.contains&&a.contains(this))return a;var c=this.contains?this:this.getParent();do if(c.contains(a))return c;while(c=c.getParent());return null},getPosition:function(a){var c=this.$,b=a.$;if(c.compareDocumentPosition)return c.compareDocumentPosition(b);if(c==b)return CKEDITOR.POSITION_IDENTICAL;if(this.type==CKEDITOR.NODE_ELEMENT&&a.type==CKEDITOR.NODE_ELEMENT){if(c.contains){if(c.contains(b))return CKEDITOR.POSITION_CONTAINS+CKEDITOR.POSITION_PRECEDING;if(b.contains(c))return CKEDITOR.POSITION_IS_CONTAINED+
CKEDITOR.POSITION_FOLLOWING}if("sourceIndex"in c)return c.sourceIndex<0||b.sourceIndex<0?CKEDITOR.POSITION_DISCONNECTED:c.sourceIndex<b.sourceIndex?CKEDITOR.POSITION_PRECEDING:CKEDITOR.POSITION_FOLLOWING}for(var c=this.getAddress(),a=a.getAddress(),b=Math.min(c.length,a.length),f=0;f<=b-1;f++)if(c[f]!=a[f]){if(f<b)return c[f]<a[f]?CKEDITOR.POSITION_PRECEDING:CKEDITOR.POSITION_FOLLOWING;break}return c.length<a.length?CKEDITOR.POSITION_CONTAINS+CKEDITOR.POSITION_PRECEDING:CKEDITOR.POSITION_IS_CONTAINED+
CKEDITOR.POSITION_FOLLOWING},getAscendant:function(a,c){var b=this.$,f;if(!c)b=b.parentNode;for(;b;){if(b.nodeName&&(f=b.nodeName.toLowerCase(),typeof a=="string"?f==a:f in a))return new CKEDITOR.dom.node(b);try{b=b.parentNode}catch(d){b=null}}return null},hasAscendant:function(a,c){var b=this.$;if(!c)b=b.parentNode;for(;b;){if(b.nodeName&&b.nodeName.toLowerCase()==a)return true;b=b.parentNode}return false},move:function(a,c){a.append(this.remove(),c)},remove:function(a){var c=this.$,b=c.parentNode;
if(b){if(a)for(;a=c.firstChild;)b.insertBefore(c.removeChild(a),c);b.removeChild(c)}return this},replace:function(a){this.insertBefore(a);a.remove()},trim:function(){this.ltrim();this.rtrim()},ltrim:function(){for(var a;this.getFirst&&(a=this.getFirst());){if(a.type==CKEDITOR.NODE_TEXT){var c=CKEDITOR.tools.ltrim(a.getText()),b=a.getLength();if(c){if(c.length<b){a.split(b-c.length);this.$.removeChild(this.$.firstChild)}}else{a.remove();continue}}break}},rtrim:function(){for(var a;this.getLast&&(a=
this.getLast());){if(a.type==CKEDITOR.NODE_TEXT){var c=CKEDITOR.tools.rtrim(a.getText()),b=a.getLength();if(c){if(c.length<b){a.split(c.length);this.$.lastChild.parentNode.removeChild(this.$.lastChild)}}else{a.remove();continue}}break}if(CKEDITOR.env.needsBrFiller)(a=this.$.lastChild)&&(a.type==1&&a.nodeName.toLowerCase()=="br")&&a.parentNode.removeChild(a)},isReadOnly:function(){var a=this;this.type!=CKEDITOR.NODE_ELEMENT&&(a=this.getParent());if(a&&typeof a.$.isContentEditable!="undefined")return!(a.$.isContentEditable||
a.data("cke-editable"));for(;a;){if(a.data("cke-editable"))break;if(a.getAttribute("contentEditable")=="false")return true;if(a.getAttribute("contentEditable")=="true")break;a=a.getParent()}return!a}});CKEDITOR.dom.window=function(a){CKEDITOR.dom.domObject.call(this,a)};CKEDITOR.dom.window.prototype=new CKEDITOR.dom.domObject;
CKEDITOR.tools.extend(CKEDITOR.dom.window.prototype,{focus:function(){this.$.focus()},getViewPaneSize:function(){var a=this.$.document,c=a.compatMode=="CSS1Compat";return{width:(c?a.documentElement.clientWidth:a.body.clientWidth)||0,height:(c?a.documentElement.clientHeight:a.body.clientHeight)||0}},getScrollPosition:function(){var a=this.$;if("pageXOffset"in a)return{x:a.pageXOffset||0,y:a.pageYOffset||0};a=a.document;return{x:a.documentElement.scrollLeft||a.body.scrollLeft||0,y:a.documentElement.scrollTop||
a.body.scrollTop||0}},getFrame:function(){var a=this.$.frameElement;return a?new CKEDITOR.dom.element.get(a):null}});CKEDITOR.dom.document=function(a){CKEDITOR.dom.domObject.call(this,a)};CKEDITOR.dom.document.prototype=new CKEDITOR.dom.domObject;
CKEDITOR.tools.extend(CKEDITOR.dom.document.prototype,{type:CKEDITOR.NODE_DOCUMENT,appendStyleSheet:function(a){if(this.$.createStyleSheet)this.$.createStyleSheet(a);else{var c=new CKEDITOR.dom.element("link");c.setAttributes({rel:"stylesheet",type:"text/css",href:a});this.getHead().append(c)}},appendStyleText:function(a){if(this.$.createStyleSheet){var c=this.$.createStyleSheet("");c.cssText=a}else{var b=new CKEDITOR.dom.element("style",this);b.append(new CKEDITOR.dom.text(a,this));this.getHead().append(b)}return c||
b.$.sheet},createElement:function(a,c){var b=new CKEDITOR.dom.element(a,this);if(c){c.attributes&&b.setAttributes(c.attributes);c.styles&&b.setStyles(c.styles)}return b},createText:function(a){return new CKEDITOR.dom.text(a,this)},focus:function(){this.getWindow().focus()},getActive:function(){return new CKEDITOR.dom.element(this.$.activeElement)},getById:function(a){return(a=this.$.getElementById(a))?new CKEDITOR.dom.element(a):null},getByAddress:function(a,c){for(var b=this.$.documentElement,f=
0;b&&f<a.length;f++){var d=a[f];if(c)for(var e=-1,g=0;g<b.childNodes.length;g++){var n=b.childNodes[g];if(!(c===true&&n.nodeType==3&&n.previousSibling&&n.previousSibling.nodeType==3)){e++;if(e==d){b=n;break}}}else b=b.childNodes[d]}return b?new CKEDITOR.dom.node(b):null},getElementsByTag:function(a,c){if((!CKEDITOR.env.ie||document.documentMode>8)&&c)a=c+":"+a;return new CKEDITOR.dom.nodeList(this.$.getElementsByTagName(a))},getHead:function(){var a=this.$.getElementsByTagName("head")[0];return a=
a?new CKEDITOR.dom.element(a):this.getDocumentElement().append(new CKEDITOR.dom.element("head"),true)},getBody:function(){return new CKEDITOR.dom.element(this.$.body)},getDocumentElement:function(){return new CKEDITOR.dom.element(this.$.documentElement)},getWindow:function(){return new CKEDITOR.dom.window(this.$.parentWindow||this.$.defaultView)},write:function(a){this.$.open("text/html","replace");CKEDITOR.env.ie&&(a=a.replace(/(?:^\s*<!DOCTYPE[^>]*?>)|^/i,'$&\n<script data-cke-temp="1">('+CKEDITOR.tools.fixDomain+
")();<\/script>"));this.$.write(a);this.$.close()},find:function(a){return new CKEDITOR.dom.nodeList(this.$.querySelectorAll(a))},findOne:function(a){return(a=this.$.querySelector(a))?new CKEDITOR.dom.element(a):null},_getHtml5ShivFrag:function(){var a=this.getCustomData("html5ShivFrag");if(!a){a=this.$.createDocumentFragment();CKEDITOR.tools.enableHtml5Elements(a,true);this.setCustomData("html5ShivFrag",a)}return a}});CKEDITOR.dom.nodeList=function(a){this.$=a};
CKEDITOR.dom.nodeList.prototype={count:function(){return this.$.length},getItem:function(a){if(a<0||a>=this.$.length)return null;return(a=this.$[a])?new CKEDITOR.dom.node(a):null}};CKEDITOR.dom.element=function(a,c){typeof a=="string"&&(a=(c?c.$:document).createElement(a));CKEDITOR.dom.domObject.call(this,a)};CKEDITOR.dom.element.get=function(a){return(a=typeof a=="string"?document.getElementById(a)||document.getElementsByName(a)[0]:a)&&(a.$?a:new CKEDITOR.dom.element(a))};
CKEDITOR.dom.element.prototype=new CKEDITOR.dom.node;CKEDITOR.dom.element.createFromHtml=function(a,c){var b=new CKEDITOR.dom.element("div",c);b.setHtml(a);return b.getFirst().remove()};
CKEDITOR.dom.element.setMarker=function(a,c,b,f){var d=c.getCustomData("list_marker_id")||c.setCustomData("list_marker_id",CKEDITOR.tools.getNextNumber()).getCustomData("list_marker_id"),e=c.getCustomData("list_marker_names")||c.setCustomData("list_marker_names",{}).getCustomData("list_marker_names");a[d]=c;e[b]=1;return c.setCustomData(b,f)};CKEDITOR.dom.element.clearAllMarkers=function(a){for(var c in a)CKEDITOR.dom.element.clearMarkers(a,a[c],1)};
CKEDITOR.dom.element.clearMarkers=function(a,c,b){var f=c.getCustomData("list_marker_names"),d=c.getCustomData("list_marker_id"),e;for(e in f)c.removeCustomData(e);c.removeCustomData("list_marker_names");if(b){c.removeCustomData("list_marker_id");delete a[d]}};
(function(){function a(a){var e=true;if(!a.$.id){a.$.id="cke_tmp_"+CKEDITOR.tools.getNextNumber();e=false}return function(){e||a.removeAttribute("id")}}function c(a,e){return"#"+a.$.id+" "+e.split(/,\s*/).join(", #"+a.$.id+" ")}function b(a){for(var e=0,b=0,c=f[a].length;b<c;b++)e=e+(parseInt(this.getComputedStyle(f[a][b])||0,10)||0);return e}CKEDITOR.tools.extend(CKEDITOR.dom.element.prototype,{type:CKEDITOR.NODE_ELEMENT,addClass:function(a){var e=this.$.className;e&&(RegExp("(?:^|\\s)"+a+"(?:\\s|$)",
"").test(e)||(e=e+(" "+a)));this.$.className=e||a;return this},removeClass:function(a){var e=this.getAttribute("class");if(e){a=RegExp("(?:^|\\s+)"+a+"(?=\\s|$)","i");if(a.test(e))(e=e.replace(a,"").replace(/^\s+/,""))?this.setAttribute("class",e):this.removeAttribute("class")}return this},hasClass:function(a){return RegExp("(?:^|\\s+)"+a+"(?=\\s|$)","").test(this.getAttribute("class"))},append:function(a,e){typeof a=="string"&&(a=this.getDocument().createElement(a));e?this.$.insertBefore(a.$,this.$.firstChild):
this.$.appendChild(a.$);return a},appendHtml:function(a){if(this.$.childNodes.length){var e=new CKEDITOR.dom.element("div",this.getDocument());e.setHtml(a);e.moveChildren(this)}else this.setHtml(a)},appendText:function(a){this.$.text!=void 0?this.$.text=this.$.text+a:this.append(new CKEDITOR.dom.text(a))},appendBogus:function(a){if(a||CKEDITOR.env.needsBrFiller){for(a=this.getLast();a&&a.type==CKEDITOR.NODE_TEXT&&!CKEDITOR.tools.rtrim(a.getText());)a=a.getPrevious();if(!a||!a.is||!a.is("br")){a=this.getDocument().createElement("br");
CKEDITOR.env.gecko&&a.setAttribute("type","_moz");this.append(a)}}},breakParent:function(a){var e=new CKEDITOR.dom.range(this.getDocument());e.setStartAfter(this);e.setEndAfter(a);a=e.extractContents();e.insertNode(this.remove());a.insertAfterNode(this)},contains:CKEDITOR.env.ie||CKEDITOR.env.webkit?function(a){var e=this.$;return a.type!=CKEDITOR.NODE_ELEMENT?e.contains(a.getParent().$):e!=a.$&&e.contains(a.$)}:function(a){return!!(this.$.compareDocumentPosition(a.$)&16)},focus:function(){function a(){try{this.$.focus()}catch(d){}}
return function(e){e?CKEDITOR.tools.setTimeout(a,100,this):a.call(this)}}(),getHtml:function(){var a=this.$.innerHTML;return CKEDITOR.env.ie?a.replace(/<\?[^>]*>/g,""):a},getOuterHtml:function(){if(this.$.outerHTML)return this.$.outerHTML.replace(/<\?[^>]*>/,"");var a=this.$.ownerDocument.createElement("div");a.appendChild(this.$.cloneNode(true));return a.innerHTML},getClientRect:function(){var a=CKEDITOR.tools.extend({},this.$.getBoundingClientRect());!a.width&&(a.width=a.right-a.left);!a.height&&
(a.height=a.bottom-a.top);return a},setHtml:CKEDITOR.env.ie&&CKEDITOR.env.version<9?function(a){try{var e=this.$;if(this.getParent())return e.innerHTML=a;var b=this.getDocument()._getHtml5ShivFrag();b.appendChild(e);e.innerHTML=a;b.removeChild(e);return a}catch(c){this.$.innerHTML="";e=new CKEDITOR.dom.element("body",this.getDocument());e.$.innerHTML=a;for(e=e.getChildren();e.count();)this.append(e.getItem(0));return a}}:function(a){return this.$.innerHTML=a},setText:function(){var a=document.createElement("p");
a.innerHTML="x";a=a.textContent;return function(e){this.$[a?"textContent":"innerText"]=e}}(),getAttribute:function(){var a=function(a){return this.$.getAttribute(a,2)};return CKEDITOR.env.ie&&(CKEDITOR.env.ie7Compat||CKEDITOR.env.quirks)?function(a){switch(a){case "class":a="className";break;case "http-equiv":a="httpEquiv";break;case "name":return this.$.name;case "tabindex":a=this.$.getAttribute(a,2);a!==0&&this.$.tabIndex===0&&(a=null);return a;case "checked":a=this.$.attributes.getNamedItem(a);
return(a.specified?a.nodeValue:this.$.checked)?"checked":null;case "hspace":case "value":return this.$[a];case "style":return this.$.style.cssText;case "contenteditable":case "contentEditable":return this.$.attributes.getNamedItem("contentEditable").specified?this.$.getAttribute("contentEditable"):null}return this.$.getAttribute(a,2)}:a}(),getChildren:function(){return new CKEDITOR.dom.nodeList(this.$.childNodes)},getComputedStyle:CKEDITOR.env.ie?function(a){return this.$.currentStyle[CKEDITOR.tools.cssStyleToDomStyle(a)]}:
function(a){var e=this.getWindow().$.getComputedStyle(this.$,null);return e?e.getPropertyValue(a):""},getDtd:function(){var a=CKEDITOR.dtd[this.getName()];this.getDtd=function(){return a};return a},getElementsByTag:CKEDITOR.dom.document.prototype.getElementsByTag,getTabIndex:CKEDITOR.env.ie?function(){var a=this.$.tabIndex;a===0&&(!CKEDITOR.dtd.$tabIndex[this.getName()]&&parseInt(this.getAttribute("tabindex"),10)!==0)&&(a=-1);return a}:CKEDITOR.env.webkit?function(){var a=this.$.tabIndex;if(a==void 0){a=
parseInt(this.getAttribute("tabindex"),10);isNaN(a)&&(a=-1)}return a}:function(){return this.$.tabIndex},getText:function(){return this.$.textContent||this.$.innerText||""},getWindow:function(){return this.getDocument().getWindow()},getId:function(){return this.$.id||null},getNameAtt:function(){return this.$.name||null},getName:function(){var a=this.$.nodeName.toLowerCase();if(CKEDITOR.env.ie&&!(document.documentMode>8)){var e=this.$.scopeName;e!="HTML"&&(a=e.toLowerCase()+":"+a)}return(this.getName=
function(){return a})()},getValue:function(){return this.$.value},getFirst:function(a){var e=this.$.firstChild;(e=e&&new CKEDITOR.dom.node(e))&&(a&&!a(e))&&(e=e.getNext(a));return e},getLast:function(a){var e=this.$.lastChild;(e=e&&new CKEDITOR.dom.node(e))&&(a&&!a(e))&&(e=e.getPrevious(a));return e},getStyle:function(a){return this.$.style[CKEDITOR.tools.cssStyleToDomStyle(a)]},is:function(){var a=this.getName();if(typeof arguments[0]=="object")return!!arguments[0][a];for(var e=0;e<arguments.length;e++)if(arguments[e]==
a)return true;return false},isEditable:function(a){var e=this.getName();if(this.isReadOnly()||this.getComputedStyle("display")=="none"||this.getComputedStyle("visibility")=="hidden"||CKEDITOR.dtd.$nonEditable[e]||CKEDITOR.dtd.$empty[e]||this.is("a")&&(this.data("cke-saved-name")||this.hasAttribute("name"))&&!this.getChildCount())return false;if(a!==false){a=CKEDITOR.dtd[e]||CKEDITOR.dtd.span;return!(!a||!a["#"])}return true},isIdentical:function(a){var e=this.clone(0,1),a=a.clone(0,1);e.removeAttributes(["_moz_dirty",
"data-cke-expando","data-cke-saved-href","data-cke-saved-name"]);a.removeAttributes(["_moz_dirty","data-cke-expando","data-cke-saved-href","data-cke-saved-name"]);if(e.$.isEqualNode){e.$.style.cssText=CKEDITOR.tools.normalizeCssText(e.$.style.cssText);a.$.style.cssText=CKEDITOR.tools.normalizeCssText(a.$.style.cssText);return e.$.isEqualNode(a.$)}e=e.getOuterHtml();a=a.getOuterHtml();if(CKEDITOR.env.ie&&CKEDITOR.env.version<9&&this.is("a")){var b=this.getParent();if(b.type==CKEDITOR.NODE_ELEMENT){b=
b.clone();b.setHtml(e);e=b.getHtml();b.setHtml(a);a=b.getHtml()}}return e==a},isVisible:function(){var a=(this.$.offsetHeight||this.$.offsetWidth)&&this.getComputedStyle("visibility")!="hidden",e,b;if(a&&CKEDITOR.env.webkit){e=this.getWindow();if(!e.equals(CKEDITOR.document.getWindow())&&(b=e.$.frameElement))a=(new CKEDITOR.dom.element(b)).isVisible()}return!!a},isEmptyInlineRemoveable:function(){if(!CKEDITOR.dtd.$removeEmpty[this.getName()])return false;for(var a=this.getChildren(),e=0,b=a.count();e<
b;e++){var c=a.getItem(e);if(!(c.type==CKEDITOR.NODE_ELEMENT&&c.data("cke-bookmark"))&&(c.type==CKEDITOR.NODE_ELEMENT&&!c.isEmptyInlineRemoveable()||c.type==CKEDITOR.NODE_TEXT&&CKEDITOR.tools.trim(c.getText())))return false}return true},hasAttributes:CKEDITOR.env.ie&&(CKEDITOR.env.ie7Compat||CKEDITOR.env.quirks)?function(){for(var a=this.$.attributes,e=0;e<a.length;e++){var b=a[e];switch(b.nodeName){case "class":if(this.getAttribute("class"))return true;case "data-cke-expando":continue;default:if(b.specified)return true}}return false}:
function(){var a=this.$.attributes,e=a.length,b={"data-cke-expando":1,_moz_dirty:1};return e>0&&(e>2||!b[a[0].nodeName]||e==2&&!b[a[1].nodeName])},hasAttribute:function(){function a(d){var b=this.$.attributes.getNamedItem(d);if(this.getName()=="input")switch(d){case "class":return this.$.className.length>0;case "checked":return!!this.$.checked;case "value":d=this.getAttribute("type");return d=="checkbox"||d=="radio"?this.$.value!="on":!!this.$.value}return!b?false:b.specified}return CKEDITOR.env.ie?
CKEDITOR.env.version<8?function(e){return e=="name"?!!this.$.name:a.call(this,e)}:a:function(a){return!!this.$.attributes.getNamedItem(a)}}(),hide:function(){this.setStyle("display","none")},moveChildren:function(a,e){var b=this.$,a=a.$;if(b!=a){var c;if(e)for(;c=b.lastChild;)a.insertBefore(b.removeChild(c),a.firstChild);else for(;c=b.firstChild;)a.appendChild(b.removeChild(c))}},mergeSiblings:function(){function a(d,b,c){if(b&&b.type==CKEDITOR.NODE_ELEMENT){for(var f=[];b.data("cke-bookmark")||b.isEmptyInlineRemoveable();){f.push(b);
b=c?b.getNext():b.getPrevious();if(!b||b.type!=CKEDITOR.NODE_ELEMENT)return}if(d.isIdentical(b)){for(var i=c?d.getLast():d.getFirst();f.length;)f.shift().move(d,!c);b.moveChildren(d,!c);b.remove();i&&i.type==CKEDITOR.NODE_ELEMENT&&i.mergeSiblings()}}}return function(e){if(e===false||CKEDITOR.dtd.$removeEmpty[this.getName()]||this.is("a")){a(this,this.getNext(),true);a(this,this.getPrevious())}}}(),show:function(){this.setStyles({display:"",visibility:""})},setAttribute:function(){var a=function(a,
d){this.$.setAttribute(a,d);return this};return CKEDITOR.env.ie&&(CKEDITOR.env.ie7Compat||CKEDITOR.env.quirks)?function(e,b){e=="class"?this.$.className=b:e=="style"?this.$.style.cssText=b:e=="tabindex"?this.$.tabIndex=b:e=="checked"?this.$.checked=b:e=="contenteditable"?a.call(this,"contentEditable",b):a.apply(this,arguments);return this}:CKEDITOR.env.ie8Compat&&CKEDITOR.env.secure?function(b,c){if(b=="src"&&c.match(/^http:\/\//))try{a.apply(this,arguments)}catch(f){}else a.apply(this,arguments);
return this}:a}(),setAttributes:function(a){for(var b in a)this.setAttribute(b,a[b]);return this},setValue:function(a){this.$.value=a;return this},removeAttribute:function(){var a=function(a){this.$.removeAttribute(a)};return CKEDITOR.env.ie&&(CKEDITOR.env.ie7Compat||CKEDITOR.env.quirks)?function(a){a=="class"?a="className":a=="tabindex"?a="tabIndex":a=="contenteditable"&&(a="contentEditable");this.$.removeAttribute(a)}:a}(),removeAttributes:function(a){if(CKEDITOR.tools.isArray(a))for(var b=0;b<
a.length;b++)this.removeAttribute(a[b]);else for(b in a)a.hasOwnProperty(b)&&this.removeAttribute(b)},removeStyle:function(a){var b=this.$.style;if(!b.removeProperty&&(a=="border"||a=="margin"||a=="padding")){var c=["top","left","right","bottom"],f;a=="border"&&(f=["color","style","width"]);for(var b=[],h=0;h<c.length;h++)if(f)for(var i=0;i<f.length;i++)b.push([a,c[h],f[i]].join("-"));else b.push([a,c[h]].join("-"));for(a=0;a<b.length;a++)this.removeStyle(b[a])}else{b.removeProperty?b.removeProperty(a):
b.removeAttribute(CKEDITOR.tools.cssStyleToDomStyle(a));this.$.style.cssText||this.removeAttribute("style")}},setStyle:function(a,b){this.$.style[CKEDITOR.tools.cssStyleToDomStyle(a)]=b;return this},setStyles:function(a){for(var b in a)this.setStyle(b,a[b]);return this},setOpacity:function(a){if(CKEDITOR.env.ie&&CKEDITOR.env.version<9){a=Math.round(a*100);this.setStyle("filter",a>=100?"":"progid:DXImageTransform.Microsoft.Alpha(opacity="+a+")")}else this.setStyle("opacity",a)},unselectable:function(){this.setStyles(CKEDITOR.tools.cssVendorPrefix("user-select",
"none"));if(CKEDITOR.env.ie){this.setAttribute("unselectable","on");for(var a,b=this.getElementsByTag("*"),c=0,f=b.count();c<f;c++){a=b.getItem(c);a.setAttribute("unselectable","on")}}},getPositionedAncestor:function(){for(var a=this;a.getName()!="html";){if(a.getComputedStyle("position")!="static")return a;a=a.getParent()}return null},getDocumentPosition:function(a){var b=0,c=0,f=this.getDocument(),h=f.getBody(),i=f.$.compatMode=="BackCompat";if(document.documentElement.getBoundingClientRect){var m=
this.$.getBoundingClientRect(),p=f.$.documentElement,s=p.clientTop||h.$.clientTop||0,x=p.clientLeft||h.$.clientLeft||0,q=true;if(CKEDITOR.env.ie){q=f.getDocumentElement().contains(this);f=f.getBody().contains(this);q=i&&f||!i&&q}if(q){b=m.left+(!i&&p.scrollLeft||h.$.scrollLeft);b=b-x;c=m.top+(!i&&p.scrollTop||h.$.scrollTop);c=c-s}}else{h=this;for(f=null;h&&!(h.getName()=="body"||h.getName()=="html");){b=b+(h.$.offsetLeft-h.$.scrollLeft);c=c+(h.$.offsetTop-h.$.scrollTop);if(!h.equals(this)){b=b+(h.$.clientLeft||
0);c=c+(h.$.clientTop||0)}for(;f&&!f.equals(h);){b=b-f.$.scrollLeft;c=c-f.$.scrollTop;f=f.getParent()}f=h;h=(m=h.$.offsetParent)?new CKEDITOR.dom.element(m):null}}if(a){h=this.getWindow();f=a.getWindow();if(!h.equals(f)&&h.$.frameElement){a=(new CKEDITOR.dom.element(h.$.frameElement)).getDocumentPosition(a);b=b+a.x;c=c+a.y}}if(!document.documentElement.getBoundingClientRect&&CKEDITOR.env.gecko&&!i){b=b+(this.$.clientLeft?1:0);c=c+(this.$.clientTop?1:0)}return{x:b,y:c}},scrollIntoView:function(a){var b=
this.getParent();if(b){do{(b.$.clientWidth&&b.$.clientWidth<b.$.scrollWidth||b.$.clientHeight&&b.$.clientHeight<b.$.scrollHeight)&&!b.is("body")&&this.scrollIntoParent(b,a,1);if(b.is("html")){var c=b.getWindow();try{var f=c.$.frameElement;f&&(b=new CKEDITOR.dom.element(f))}catch(h){}}}while(b=b.getParent())}},scrollIntoParent:function(a,b,c){var f,h,i,m;function p(b,e){if(/body|html/.test(a.getName()))a.getWindow().$.scrollBy(b,e);else{a.$.scrollLeft=a.$.scrollLeft+b;a.$.scrollTop=a.$.scrollTop+e}}
function s(a,b){var d={x:0,y:0};if(!a.is(q?"body":"html")){var e=a.$.getBoundingClientRect();d.x=e.left;d.y=e.top}e=a.getWindow();if(!e.equals(b)){e=s(CKEDITOR.dom.element.get(e.$.frameElement),b);d.x=d.x+e.x;d.y=d.y+e.y}return d}function x(a,b){return parseInt(a.getComputedStyle("margin-"+b)||0,10)||0}!a&&(a=this.getWindow());i=a.getDocument();var q=i.$.compatMode=="BackCompat";a instanceof CKEDITOR.dom.window&&(a=q?i.getBody():i.getDocumentElement());i=a.getWindow();h=s(this,i);var o=s(a,i),u=this.$.offsetHeight;
f=this.$.offsetWidth;var A=a.$.clientHeight,k=a.$.clientWidth;i=h.x-x(this,"left")-o.x||0;m=h.y-x(this,"top")-o.y||0;f=h.x+f+x(this,"right")-(o.x+k)||0;h=h.y+u+x(this,"bottom")-(o.y+A)||0;if(m<0||h>0)p(0,b===true?m:b===false?h:m<0?m:h);if(c&&(i<0||f>0))p(i<0?i:f,0)},setState:function(a,b,c){b=b||"cke";switch(a){case CKEDITOR.TRISTATE_ON:this.addClass(b+"_on");this.removeClass(b+"_off");this.removeClass(b+"_disabled");c&&this.setAttribute("aria-pressed",true);c&&this.removeAttribute("aria-disabled");
break;case CKEDITOR.TRISTATE_DISABLED:this.addClass(b+"_disabled");this.removeClass(b+"_off");this.removeClass(b+"_on");c&&this.setAttribute("aria-disabled",true);c&&this.removeAttribute("aria-pressed");break;default:this.addClass(b+"_off");this.removeClass(b+"_on");this.removeClass(b+"_disabled");c&&this.removeAttribute("aria-pressed");c&&this.removeAttribute("aria-disabled")}},getFrameDocument:function(){var a=this.$;try{a.contentWindow.document}catch(b){a.src=a.src}return a&&new CKEDITOR.dom.document(a.contentWindow.document)},
copyAttributes:function(a,b){for(var c=this.$.attributes,b=b||{},f=0;f<c.length;f++){var h=c[f],i=h.nodeName.toLowerCase(),m;if(!(i in b))if(i=="checked"&&(m=this.getAttribute(i)))a.setAttribute(i,m);else if(!CKEDITOR.env.ie||this.hasAttribute(i)){m=this.getAttribute(i);if(m===null)m=h.nodeValue;a.setAttribute(i,m)}}if(this.$.style.cssText!=="")a.$.style.cssText=this.$.style.cssText},renameNode:function(a){if(this.getName()!=a){var b=this.getDocument(),a=new CKEDITOR.dom.element(a,b);this.copyAttributes(a);
this.moveChildren(a);this.getParent()&&this.$.parentNode.replaceChild(a.$,this.$);a.$["data-cke-expando"]=this.$["data-cke-expando"];this.$=a.$;delete this.getName}},getChild:function(){function a(b,d){var c=b.childNodes;if(d>=0&&d<c.length)return c[d]}return function(b){var c=this.$;if(b.slice)for(;b.length>0&&c;)c=a(c,b.shift());else c=a(c,b);return c?new CKEDITOR.dom.node(c):null}}(),getChildCount:function(){return this.$.childNodes.length},disableContextMenu:function(){this.on("contextmenu",function(a){a.data.getTarget().hasClass("cke_enable_context_menu")||
a.data.preventDefault()})},getDirection:function(a){return a?this.getComputedStyle("direction")||this.getDirection()||this.getParent()&&this.getParent().getDirection(1)||this.getDocument().$.dir||"ltr":this.getStyle("direction")||this.getAttribute("dir")},data:function(a,b){a="data-"+a;if(b===void 0)return this.getAttribute(a);b===false?this.removeAttribute(a):this.setAttribute(a,b);return null},getEditor:function(){var a=CKEDITOR.instances,b,c;for(b in a){c=a[b];if(c.element.equals(this)&&c.elementMode!=
CKEDITOR.ELEMENT_MODE_APPENDTO)return c}return null},find:function(b){var e=a(this),b=new CKEDITOR.dom.nodeList(this.$.querySelectorAll(c(this,b)));e();return b},findOne:function(b){var e=a(this),b=this.$.querySelector(c(this,b));e();return b?new CKEDITOR.dom.element(b):null},forEach:function(a,b,c){if(!c&&(!b||this.type==b))var f=a(this);if(f!==false)for(var c=this.getChildren(),h=0;h<c.count();h++){f=c.getItem(h);f.type==CKEDITOR.NODE_ELEMENT?f.forEach(a,b):(!b||f.type==b)&&a(f)}}});var f={width:["border-left-width",
"border-right-width","padding-left","padding-right"],height:["border-top-width","border-bottom-width","padding-top","padding-bottom"]};CKEDITOR.dom.element.prototype.setSize=function(a,c,f){if(typeof c=="number"){if(f&&(!CKEDITOR.env.ie||!CKEDITOR.env.quirks))c=c-b.call(this,a);this.setStyle(a,c+"px")}};CKEDITOR.dom.element.prototype.getSize=function(a,c){var f=Math.max(this.$["offset"+CKEDITOR.tools.capitalize(a)],this.$["client"+CKEDITOR.tools.capitalize(a)])||0;c&&(f=f-b.call(this,a));return f}})();
CKEDITOR.dom.documentFragment=function(a){a=a||CKEDITOR.document;this.$=a.type==CKEDITOR.NODE_DOCUMENT?a.$.createDocumentFragment():a};
CKEDITOR.tools.extend(CKEDITOR.dom.documentFragment.prototype,CKEDITOR.dom.element.prototype,{type:CKEDITOR.NODE_DOCUMENT_FRAGMENT,insertAfterNode:function(a){a=a.$;a.parentNode.insertBefore(this.$,a.nextSibling)}},!0,{append:1,appendBogus:1,getFirst:1,getLast:1,getParent:1,getNext:1,getPrevious:1,appendTo:1,moveChildren:1,insertBefore:1,insertAfterNode:1,replace:1,trim:1,type:1,ltrim:1,rtrim:1,getDocument:1,getChildCount:1,getChild:1,getChildren:1});
(function(){function a(a,b){var c=this.range;if(this._.end)return null;if(!this._.start){this._.start=1;if(c.collapsed){this.end();return null}c.optimize()}var d,e=c.startContainer;d=c.endContainer;var f=c.startOffset,m=c.endOffset,k,l=this.guard,j=this.type,v=a?"getPreviousSourceNode":"getNextSourceNode";if(!a&&!this._.guardLTR){var g=d.type==CKEDITOR.NODE_ELEMENT?d:d.getParent(),r=d.type==CKEDITOR.NODE_ELEMENT?d.getChild(m):d.getNext();this._.guardLTR=function(a,b){return(!b||!g.equals(a))&&(!r||
!a.equals(r))&&(a.type!=CKEDITOR.NODE_ELEMENT||!b||!a.equals(c.root))}}if(a&&!this._.guardRTL){var h=e.type==CKEDITOR.NODE_ELEMENT?e:e.getParent(),i=e.type==CKEDITOR.NODE_ELEMENT?f?e.getChild(f-1):null:e.getPrevious();this._.guardRTL=function(a,b){return(!b||!h.equals(a))&&(!i||!a.equals(i))&&(a.type!=CKEDITOR.NODE_ELEMENT||!b||!a.equals(c.root))}}var F=a?this._.guardRTL:this._.guardLTR;k=l?function(a,b){return F(a,b)===false?false:l(a,b)}:F;if(this.current)d=this.current[v](false,j,k);else{if(a)d.type==
CKEDITOR.NODE_ELEMENT&&(d=m>0?d.getChild(m-1):k(d,true)===false?null:d.getPreviousSourceNode(true,j,k));else{d=e;if(d.type==CKEDITOR.NODE_ELEMENT&&!(d=d.getChild(f)))d=k(e,true)===false?null:e.getNextSourceNode(true,j,k)}d&&k(d)===false&&(d=null)}for(;d&&!this._.end;){this.current=d;if(!this.evaluator||this.evaluator(d)!==false){if(!b)return d}else if(b&&this.evaluator)return false;d=d[v](false,j,k)}this.end();return this.current=null}function c(b){for(var d,c=null;d=a.call(this,b);)c=d;return c}
function b(a){if(i(a))return false;if(a.type==CKEDITOR.NODE_TEXT)return true;if(a.type==CKEDITOR.NODE_ELEMENT){if(a.is(CKEDITOR.dtd.$inline)||a.is("hr")||a.getAttribute("contenteditable")=="false")return true;var b;if(b=!CKEDITOR.env.needsBrFiller)if(b=a.is(m))a:{b=0;for(var d=a.getChildCount();b<d;++b)if(!i(a.getChild(b))){b=false;break a}b=true}if(b)return true}return false}CKEDITOR.dom.walker=CKEDITOR.tools.createClass({$:function(a){this.range=a;this._={}},proto:{end:function(){this._.end=1},
next:function(){return a.call(this)},previous:function(){return a.call(this,1)},checkForward:function(){return a.call(this,0,1)!==false},checkBackward:function(){return a.call(this,1,1)!==false},lastForward:function(){return c.call(this)},lastBackward:function(){return c.call(this,1)},reset:function(){delete this.current;this._={}}}});var f={block:1,"list-item":1,table:1,"table-row-group":1,"table-header-group":1,"table-footer-group":1,"table-row":1,"table-column-group":1,"table-column":1,"table-cell":1,
"table-caption":1},d={absolute:1,fixed:1};CKEDITOR.dom.element.prototype.isBlockBoundary=function(a){return this.getComputedStyle("float")=="none"&&!(this.getComputedStyle("position")in d)&&f[this.getComputedStyle("display")]?true:!!(this.is(CKEDITOR.dtd.$block)||a&&this.is(a))};CKEDITOR.dom.walker.blockBoundary=function(a){return function(b){return!(b.type==CKEDITOR.NODE_ELEMENT&&b.isBlockBoundary(a))}};CKEDITOR.dom.walker.listItemBoundary=function(){return this.blockBoundary({br:1})};CKEDITOR.dom.walker.bookmark=
function(a,b){function d(a){return a&&a.getName&&a.getName()=="span"&&a.data("cke-bookmark")}return function(c){var e,f;e=c&&c.type!=CKEDITOR.NODE_ELEMENT&&(f=c.getParent())&&d(f);e=a?e:e||d(c);return!!(b^e)}};CKEDITOR.dom.walker.whitespaces=function(a){return function(b){var d;b&&b.type==CKEDITOR.NODE_TEXT&&(d=!CKEDITOR.tools.trim(b.getText())||CKEDITOR.env.webkit&&b.getText()=="​");return!!(a^d)}};CKEDITOR.dom.walker.invisible=function(a){var b=CKEDITOR.dom.walker.whitespaces();return function(d){if(b(d))d=
1;else{d.type==CKEDITOR.NODE_TEXT&&(d=d.getParent());d=!d.$.offsetHeight}return!!(a^d)}};CKEDITOR.dom.walker.nodeType=function(a,b){return function(d){return!!(b^d.type==a)}};CKEDITOR.dom.walker.bogus=function(a){function b(a){return!g(a)&&!n(a)}return function(d){var c=CKEDITOR.env.needsBrFiller?d.is&&d.is("br"):d.getText&&e.test(d.getText());if(c){c=d.getParent();d=d.getNext(b);c=c.isBlockBoundary()&&(!d||d.type==CKEDITOR.NODE_ELEMENT&&d.isBlockBoundary())}return!!(a^c)}};CKEDITOR.dom.walker.temp=
function(a){return function(b){b.type!=CKEDITOR.NODE_ELEMENT&&(b=b.getParent());b=b&&b.hasAttribute("data-cke-temp");return!!(a^b)}};var e=/^[\t\r\n ]*(?:&nbsp;|\xa0)$/,g=CKEDITOR.dom.walker.whitespaces(),n=CKEDITOR.dom.walker.bookmark(),h=CKEDITOR.dom.walker.temp();CKEDITOR.dom.walker.ignored=function(a){return function(b){b=g(b)||n(b)||h(b);return!!(a^b)}};var i=CKEDITOR.dom.walker.ignored(),m=function(a){var b={},d;for(d in a)CKEDITOR.dtd[d]["#"]&&(b[d]=1);return b}(CKEDITOR.dtd.$block);CKEDITOR.dom.walker.editable=
function(a){return function(d){return!!(a^b(d))}};CKEDITOR.dom.element.prototype.getBogus=function(){var a=this;do a=a.getPreviousSourceNode();while(n(a)||g(a)||a.type==CKEDITOR.NODE_ELEMENT&&a.is(CKEDITOR.dtd.$inline)&&!a.is(CKEDITOR.dtd.$empty));return a&&(CKEDITOR.env.needsBrFiller?a.is&&a.is("br"):a.getText&&e.test(a.getText()))?a:false}})();
CKEDITOR.dom.range=function(a){this.endOffset=this.endContainer=this.startOffset=this.startContainer=null;this.collapsed=true;var c=a instanceof CKEDITOR.dom.document;this.document=c?a:a.getDocument();this.root=c?a.getBody():a};
(function(){function a(){var a=false,b=CKEDITOR.dom.walker.whitespaces(),d=CKEDITOR.dom.walker.bookmark(true),c=CKEDITOR.dom.walker.bogus();return function(f){if(d(f)||b(f))return true;if(c(f)&&!a)return a=true;return f.type==CKEDITOR.NODE_TEXT&&(f.hasAscendant("pre")||CKEDITOR.tools.trim(f.getText()).length)||f.type==CKEDITOR.NODE_ELEMENT&&!f.is(e)?false:true}}function c(a){var b=CKEDITOR.dom.walker.whitespaces(),d=CKEDITOR.dom.walker.bookmark(1);return function(c){return d(c)||b(c)?true:!a&&g(c)||
c.type==CKEDITOR.NODE_ELEMENT&&c.is(CKEDITOR.dtd.$removeEmpty)}}function b(a){return function(){var b;return this[a?"getPreviousNode":"getNextNode"](function(a){!b&&i(a)&&(b=a);return h(a)&&!(g(a)&&a.equals(b))})}}var f=function(a){a.collapsed=a.startContainer&&a.endContainer&&a.startContainer.equals(a.endContainer)&&a.startOffset==a.endOffset},d=function(a,b,d,c){a.optimizeBookmark();var e=a.startContainer,f=a.endContainer,u=a.startOffset,g=a.endOffset,k,l;if(f.type==CKEDITOR.NODE_TEXT)f=f.split(g);
else if(f.getChildCount()>0)if(g>=f.getChildCount()){f=f.append(a.document.createText(""));l=true}else f=f.getChild(g);if(e.type==CKEDITOR.NODE_TEXT){e.split(u);e.equals(f)&&(f=e.getNext())}else if(u)if(u>=e.getChildCount()){e=e.append(a.document.createText(""));k=true}else e=e.getChild(u).getPrevious();else{e=e.append(a.document.createText(""),1);k=true}var u=e.getParents(),g=f.getParents(),j,v,h;for(j=0;j<u.length;j++){v=u[j];h=g[j];if(!v.equals(h))break}for(var r=d,i,n,F,D=j;D<u.length;D++){i=
u[D];r&&!i.equals(e)&&(n=r.append(i.clone()));for(i=i.getNext();i;){if(i.equals(g[D])||i.equals(f))break;F=i.getNext();if(b==2)r.append(i.clone(true));else{i.remove();b==1&&r.append(i)}i=F}r&&(r=n)}r=d;for(d=j;d<g.length;d++){i=g[d];b>0&&!i.equals(f)&&(n=r.append(i.clone()));if(!u[d]||i.$.parentNode!=u[d].$.parentNode)for(i=i.getPrevious();i;){if(i.equals(u[d])||i.equals(e))break;F=i.getPrevious();if(b==2)r.$.insertBefore(i.$.cloneNode(true),r.$.firstChild);else{i.remove();b==1&&r.$.insertBefore(i.$,
r.$.firstChild)}i=F}r&&(r=n)}if(b==2){v=a.startContainer;if(v.type==CKEDITOR.NODE_TEXT){v.$.data=v.$.data+v.$.nextSibling.data;v.$.parentNode.removeChild(v.$.nextSibling)}a=a.endContainer;if(a.type==CKEDITOR.NODE_TEXT&&a.$.nextSibling){a.$.data=a.$.data+a.$.nextSibling.data;a.$.parentNode.removeChild(a.$.nextSibling)}}else{if(v&&h&&(e.$.parentNode!=v.$.parentNode||f.$.parentNode!=h.$.parentNode)){b=h.getIndex();k&&h.$.parentNode==e.$.parentNode&&b--;if(c&&v.type==CKEDITOR.NODE_ELEMENT){c=CKEDITOR.dom.element.createFromHtml('<span data-cke-bookmark="1" style="display:none">&nbsp;</span>',
a.document);c.insertAfter(v);v.mergeSiblings(false);a.moveToBookmark({startNode:c})}else a.setStart(h.getParent(),b)}a.collapse(true)}k&&e.remove();l&&f.$.parentNode&&f.remove()},e={abbr:1,acronym:1,b:1,bdo:1,big:1,cite:1,code:1,del:1,dfn:1,em:1,font:1,i:1,ins:1,label:1,kbd:1,q:1,samp:1,small:1,span:1,strike:1,strong:1,sub:1,sup:1,tt:1,u:1,"var":1},g=CKEDITOR.dom.walker.bogus(),n=/^[\t\r\n ]*(?:&nbsp;|\xa0)$/,h=CKEDITOR.dom.walker.editable(),i=CKEDITOR.dom.walker.ignored(true);CKEDITOR.dom.range.prototype=
{clone:function(){var a=new CKEDITOR.dom.range(this.root);a.startContainer=this.startContainer;a.startOffset=this.startOffset;a.endContainer=this.endContainer;a.endOffset=this.endOffset;a.collapsed=this.collapsed;return a},collapse:function(a){if(a){this.endContainer=this.startContainer;this.endOffset=this.startOffset}else{this.startContainer=this.endContainer;this.startOffset=this.endOffset}this.collapsed=true},cloneContents:function(){var a=new CKEDITOR.dom.documentFragment(this.document);this.collapsed||
d(this,2,a);return a},deleteContents:function(a){this.collapsed||d(this,0,null,a)},extractContents:function(a){var b=new CKEDITOR.dom.documentFragment(this.document);this.collapsed||d(this,1,b,a);return b},createBookmark:function(a){var b,d,c,e,f=this.collapsed;b=this.document.createElement("span");b.data("cke-bookmark",1);b.setStyle("display","none");b.setHtml("&nbsp;");if(a){c="cke_bm_"+CKEDITOR.tools.getNextNumber();b.setAttribute("id",c+(f?"C":"S"))}if(!f){d=b.clone();d.setHtml("&nbsp;");a&&d.setAttribute("id",
c+"E");e=this.clone();e.collapse();e.insertNode(d)}e=this.clone();e.collapse(true);e.insertNode(b);if(d){this.setStartAfter(b);this.setEndBefore(d)}else this.moveToPosition(b,CKEDITOR.POSITION_AFTER_END);return{startNode:a?c+(f?"C":"S"):b,endNode:a?c+"E":d,serializable:a,collapsed:f}},createBookmark2:function(){function a(b){var d=b.container,c=b.offset,e;e=d;var f=c;e=e.type!=CKEDITOR.NODE_ELEMENT||f===0||f==e.getChildCount()?0:e.getChild(f-1).type==CKEDITOR.NODE_TEXT&&e.getChild(f).type==CKEDITOR.NODE_TEXT;
if(e){d=d.getChild(c-1);c=d.getLength()}d.type==CKEDITOR.NODE_ELEMENT&&c>1&&(c=d.getChild(c-1).getIndex(true)+1);if(d.type==CKEDITOR.NODE_TEXT){e=d;for(f=0;(e=e.getPrevious())&&e.type==CKEDITOR.NODE_TEXT;)f=f+e.getLength();c=c+f}b.container=d;b.offset=c}return function(b){var d=this.collapsed,c={container:this.startContainer,offset:this.startOffset},e={container:this.endContainer,offset:this.endOffset};if(b){a(c);d||a(e)}return{start:c.container.getAddress(b),end:d?null:e.container.getAddress(b),
startOffset:c.offset,endOffset:e.offset,normalized:b,collapsed:d,is2:true}}}(),moveToBookmark:function(a){if(a.is2){var b=this.document.getByAddress(a.start,a.normalized),d=a.startOffset,c=a.end&&this.document.getByAddress(a.end,a.normalized),a=a.endOffset;this.setStart(b,d);c?this.setEnd(c,a):this.collapse(true)}else{b=(d=a.serializable)?this.document.getById(a.startNode):a.startNode;a=d?this.document.getById(a.endNode):a.endNode;this.setStartBefore(b);b.remove();if(a){this.setEndBefore(a);a.remove()}else this.collapse(true)}},
getBoundaryNodes:function(){var a=this.startContainer,b=this.endContainer,d=this.startOffset,c=this.endOffset,e;if(a.type==CKEDITOR.NODE_ELEMENT){e=a.getChildCount();if(e>d)a=a.getChild(d);else if(e<1)a=a.getPreviousSourceNode();else{for(a=a.$;a.lastChild;)a=a.lastChild;a=new CKEDITOR.dom.node(a);a=a.getNextSourceNode()||a}}if(b.type==CKEDITOR.NODE_ELEMENT){e=b.getChildCount();if(e>c)b=b.getChild(c).getPreviousSourceNode(true);else if(e<1)b=b.getPreviousSourceNode();else{for(b=b.$;b.lastChild;)b=
b.lastChild;b=new CKEDITOR.dom.node(b)}}a.getPosition(b)&CKEDITOR.POSITION_FOLLOWING&&(a=b);return{startNode:a,endNode:b}},getCommonAncestor:function(a,b){var d=this.startContainer,c=this.endContainer,d=d.equals(c)?a&&d.type==CKEDITOR.NODE_ELEMENT&&this.startOffset==this.endOffset-1?d.getChild(this.startOffset):d:d.getCommonAncestor(c);return b&&!d.is?d.getParent():d},optimize:function(){var a=this.startContainer,b=this.startOffset;a.type!=CKEDITOR.NODE_ELEMENT&&(b?b>=a.getLength()&&this.setStartAfter(a):
this.setStartBefore(a));a=this.endContainer;b=this.endOffset;a.type!=CKEDITOR.NODE_ELEMENT&&(b?b>=a.getLength()&&this.setEndAfter(a):this.setEndBefore(a))},optimizeBookmark:function(){var a=this.startContainer,b=this.endContainer;a.is&&(a.is("span")&&a.data("cke-bookmark"))&&this.setStartAt(a,CKEDITOR.POSITION_BEFORE_START);b&&(b.is&&b.is("span")&&b.data("cke-bookmark"))&&this.setEndAt(b,CKEDITOR.POSITION_AFTER_END)},trim:function(a,b){var d=this.startContainer,c=this.startOffset,e=this.collapsed;
if((!a||e)&&d&&d.type==CKEDITOR.NODE_TEXT){if(c)if(c>=d.getLength()){c=d.getIndex()+1;d=d.getParent()}else{var f=d.split(c),c=d.getIndex()+1,d=d.getParent();if(this.startContainer.equals(this.endContainer))this.setEnd(f,this.endOffset-this.startOffset);else if(d.equals(this.endContainer))this.endOffset=this.endOffset+1}else{c=d.getIndex();d=d.getParent()}this.setStart(d,c);if(e){this.collapse(true);return}}d=this.endContainer;c=this.endOffset;if(!b&&!e&&d&&d.type==CKEDITOR.NODE_TEXT){if(c){c>=d.getLength()||
d.split(c);c=d.getIndex()+1}else c=d.getIndex();d=d.getParent();this.setEnd(d,c)}},enlarge:function(a,b){function d(a){return a&&a.type==CKEDITOR.NODE_ELEMENT&&a.hasAttribute("contenteditable")?null:a}var c=RegExp(/[^\s\ufeff]/);switch(a){case CKEDITOR.ENLARGE_INLINE:var e=1;case CKEDITOR.ENLARGE_ELEMENT:if(this.collapsed)break;var f=this.getCommonAncestor(),u=this.root,i,k,l,j,v,g=false,r,h;r=this.startContainer;var n=this.startOffset;if(r.type==CKEDITOR.NODE_TEXT){if(n){r=!CKEDITOR.tools.trim(r.substring(0,
n)).length&&r;g=!!r}if(r&&!(j=r.getPrevious()))l=r.getParent()}else{n&&(j=r.getChild(n-1)||r.getLast());j||(l=r)}for(l=d(l);l||j;){if(l&&!j){!v&&l.equals(f)&&(v=true);if(e?l.isBlockBoundary():!u.contains(l))break;if(!g||l.getComputedStyle("display")!="inline"){g=false;v?i=l:this.setStartBefore(l)}j=l.getPrevious()}for(;j;){r=false;if(j.type==CKEDITOR.NODE_COMMENT)j=j.getPrevious();else{if(j.type==CKEDITOR.NODE_TEXT){h=j.getText();c.test(h)&&(j=null);r=/[\s\ufeff]$/.test(h)}else if((j.$.offsetWidth>
0||b&&j.is("br"))&&!j.data("cke-bookmark"))if(g&&CKEDITOR.dtd.$removeEmpty[j.getName()]){h=j.getText();if(c.test(h))j=null;else for(var n=j.$.getElementsByTagName("*"),F=0,D;D=n[F++];)if(!CKEDITOR.dtd.$removeEmpty[D.nodeName.toLowerCase()]){j=null;break}j&&(r=!!h.length)}else j=null;r&&(g?v?i=l:l&&this.setStartBefore(l):g=true);if(j){r=j.getPrevious();if(!l&&!r){l=j;j=null;break}j=r}else l=null}}l&&(l=d(l.getParent()))}r=this.endContainer;n=this.endOffset;l=j=null;v=g=false;var L=function(a,b){var d=
new CKEDITOR.dom.range(u);d.setStart(a,b);d.setEndAt(u,CKEDITOR.POSITION_BEFORE_END);var d=new CKEDITOR.dom.walker(d),e;for(d.guard=function(a){return!(a.type==CKEDITOR.NODE_ELEMENT&&a.isBlockBoundary())};e=d.next();){if(e.type!=CKEDITOR.NODE_TEXT)return false;h=e!=a?e.getText():e.substring(b);if(c.test(h))return false}return true};if(r.type==CKEDITOR.NODE_TEXT)if(CKEDITOR.tools.trim(r.substring(n)).length)g=true;else{g=!r.getLength();if(n==r.getLength()){if(!(j=r.getNext()))l=r.getParent()}else L(r,
n)&&(l=r.getParent())}else(j=r.getChild(n))||(l=r);for(;l||j;){if(l&&!j){!v&&l.equals(f)&&(v=true);if(e?l.isBlockBoundary():!u.contains(l))break;if(!g||l.getComputedStyle("display")!="inline"){g=false;v?k=l:l&&this.setEndAfter(l)}j=l.getNext()}for(;j;){r=false;if(j.type==CKEDITOR.NODE_TEXT){h=j.getText();L(j,0)||(j=null);r=/^[\s\ufeff]/.test(h)}else if(j.type==CKEDITOR.NODE_ELEMENT){if((j.$.offsetWidth>0||b&&j.is("br"))&&!j.data("cke-bookmark"))if(g&&CKEDITOR.dtd.$removeEmpty[j.getName()]){h=j.getText();
if(c.test(h))j=null;else{n=j.$.getElementsByTagName("*");for(F=0;D=n[F++];)if(!CKEDITOR.dtd.$removeEmpty[D.nodeName.toLowerCase()]){j=null;break}}j&&(r=!!h.length)}else j=null}else r=1;r&&g&&(v?k=l:this.setEndAfter(l));if(j){r=j.getNext();if(!l&&!r){l=j;j=null;break}j=r}else l=null}l&&(l=d(l.getParent()))}if(i&&k){f=i.contains(k)?k:i;this.setStartBefore(f);this.setEndAfter(f)}break;case CKEDITOR.ENLARGE_BLOCK_CONTENTS:case CKEDITOR.ENLARGE_LIST_ITEM_CONTENTS:l=new CKEDITOR.dom.range(this.root);u=
this.root;l.setStartAt(u,CKEDITOR.POSITION_AFTER_START);l.setEnd(this.startContainer,this.startOffset);l=new CKEDITOR.dom.walker(l);var J,w,z=CKEDITOR.dom.walker.blockBoundary(a==CKEDITOR.ENLARGE_LIST_ITEM_CONTENTS?{br:1}:null),t=null,E=function(a){if(a.type==CKEDITOR.NODE_ELEMENT&&a.getAttribute("contenteditable")=="false")if(t){if(t.equals(a)){t=null;return}}else t=a;else if(t)return;var b=z(a);b||(J=a);return b},e=function(a){var b=E(a);!b&&(a.is&&a.is("br"))&&(w=a);return b};l.guard=E;l=l.lastBackward();
J=J||u;this.setStartAt(J,!J.is("br")&&(!l&&this.checkStartOfBlock()||l&&J.contains(l))?CKEDITOR.POSITION_AFTER_START:CKEDITOR.POSITION_AFTER_END);if(a==CKEDITOR.ENLARGE_LIST_ITEM_CONTENTS){l=this.clone();l=new CKEDITOR.dom.walker(l);var y=CKEDITOR.dom.walker.whitespaces(),C=CKEDITOR.dom.walker.bookmark();l.evaluator=function(a){return!y(a)&&!C(a)};if((l=l.previous())&&l.type==CKEDITOR.NODE_ELEMENT&&l.is("br"))break}l=this.clone();l.collapse();l.setEndAt(u,CKEDITOR.POSITION_BEFORE_END);l=new CKEDITOR.dom.walker(l);
l.guard=a==CKEDITOR.ENLARGE_LIST_ITEM_CONTENTS?e:E;J=t=w=null;l=l.lastForward();J=J||u;this.setEndAt(J,!l&&this.checkEndOfBlock()||l&&J.contains(l)?CKEDITOR.POSITION_BEFORE_END:CKEDITOR.POSITION_BEFORE_START);w&&this.setEndAfter(w)}},shrink:function(a,b,d){if(!this.collapsed){var a=a||CKEDITOR.SHRINK_TEXT,c=this.clone(),e=this.startContainer,f=this.endContainer,u=this.startOffset,g=this.endOffset,k=1,l=1;if(e&&e.type==CKEDITOR.NODE_TEXT)if(u)if(u>=e.getLength())c.setStartAfter(e);else{c.setStartBefore(e);
k=0}else c.setStartBefore(e);if(f&&f.type==CKEDITOR.NODE_TEXT)if(g)if(g>=f.getLength())c.setEndAfter(f);else{c.setEndAfter(f);l=0}else c.setEndBefore(f);var c=new CKEDITOR.dom.walker(c),j=CKEDITOR.dom.walker.bookmark();c.evaluator=function(b){return b.type==(a==CKEDITOR.SHRINK_ELEMENT?CKEDITOR.NODE_ELEMENT:CKEDITOR.NODE_TEXT)};var v;c.guard=function(b,c){if(j(b))return true;if(a==CKEDITOR.SHRINK_ELEMENT&&b.type==CKEDITOR.NODE_TEXT||c&&b.equals(v)||d===false&&b.type==CKEDITOR.NODE_ELEMENT&&b.isBlockBoundary()||
b.type==CKEDITOR.NODE_ELEMENT&&b.hasAttribute("contenteditable"))return false;!c&&b.type==CKEDITOR.NODE_ELEMENT&&(v=b);return true};if(k)(e=c[a==CKEDITOR.SHRINK_ELEMENT?"lastForward":"next"]())&&this.setStartAt(e,b?CKEDITOR.POSITION_AFTER_START:CKEDITOR.POSITION_BEFORE_START);if(l){c.reset();(c=c[a==CKEDITOR.SHRINK_ELEMENT?"lastBackward":"previous"]())&&this.setEndAt(c,b?CKEDITOR.POSITION_BEFORE_END:CKEDITOR.POSITION_AFTER_END)}return!(!k&&!l)}},insertNode:function(a){this.optimizeBookmark();this.trim(false,
true);var b=this.startContainer,d=b.getChild(this.startOffset);d?a.insertBefore(d):b.append(a);a.getParent()&&a.getParent().equals(this.endContainer)&&this.endOffset++;this.setStartBefore(a)},moveToPosition:function(a,b){this.setStartAt(a,b);this.collapse(true)},moveToRange:function(a){this.setStart(a.startContainer,a.startOffset);this.setEnd(a.endContainer,a.endOffset)},selectNodeContents:function(a){this.setStart(a,0);this.setEnd(a,a.type==CKEDITOR.NODE_TEXT?a.getLength():a.getChildCount())},setStart:function(a,
b){if(a.type==CKEDITOR.NODE_ELEMENT&&CKEDITOR.dtd.$empty[a.getName()]){b=a.getIndex();a=a.getParent()}this.startContainer=a;this.startOffset=b;if(!this.endContainer){this.endContainer=a;this.endOffset=b}f(this)},setEnd:function(a,b){if(a.type==CKEDITOR.NODE_ELEMENT&&CKEDITOR.dtd.$empty[a.getName()]){b=a.getIndex()+1;a=a.getParent()}this.endContainer=a;this.endOffset=b;if(!this.startContainer){this.startContainer=a;this.startOffset=b}f(this)},setStartAfter:function(a){this.setStart(a.getParent(),a.getIndex()+
1)},setStartBefore:function(a){this.setStart(a.getParent(),a.getIndex())},setEndAfter:function(a){this.setEnd(a.getParent(),a.getIndex()+1)},setEndBefore:function(a){this.setEnd(a.getParent(),a.getIndex())},setStartAt:function(a,b){switch(b){case CKEDITOR.POSITION_AFTER_START:this.setStart(a,0);break;case CKEDITOR.POSITION_BEFORE_END:a.type==CKEDITOR.NODE_TEXT?this.setStart(a,a.getLength()):this.setStart(a,a.getChildCount());break;case CKEDITOR.POSITION_BEFORE_START:this.setStartBefore(a);break;case CKEDITOR.POSITION_AFTER_END:this.setStartAfter(a)}f(this)},
setEndAt:function(a,b){switch(b){case CKEDITOR.POSITION_AFTER_START:this.setEnd(a,0);break;case CKEDITOR.POSITION_BEFORE_END:a.type==CKEDITOR.NODE_TEXT?this.setEnd(a,a.getLength()):this.setEnd(a,a.getChildCount());break;case CKEDITOR.POSITION_BEFORE_START:this.setEndBefore(a);break;case CKEDITOR.POSITION_AFTER_END:this.setEndAfter(a)}f(this)},fixBlock:function(a,b){var d=this.createBookmark(),c=this.document.createElement(b);this.collapse(a);this.enlarge(CKEDITOR.ENLARGE_BLOCK_CONTENTS);this.extractContents().appendTo(c);
c.trim();c.appendBogus();this.insertNode(c);this.moveToBookmark(d);return c},splitBlock:function(a){var b=new CKEDITOR.dom.elementPath(this.startContainer,this.root),d=new CKEDITOR.dom.elementPath(this.endContainer,this.root),c=b.block,e=d.block,f=null;if(!b.blockLimit.equals(d.blockLimit))return null;if(a!="br"){if(!c){c=this.fixBlock(true,a);e=(new CKEDITOR.dom.elementPath(this.endContainer,this.root)).block}e||(e=this.fixBlock(false,a))}a=c&&this.checkStartOfBlock();b=e&&this.checkEndOfBlock();
this.deleteContents();if(c&&c.equals(e))if(b){f=new CKEDITOR.dom.elementPath(this.startContainer,this.root);this.moveToPosition(e,CKEDITOR.POSITION_AFTER_END);e=null}else if(a){f=new CKEDITOR.dom.elementPath(this.startContainer,this.root);this.moveToPosition(c,CKEDITOR.POSITION_BEFORE_START);c=null}else{e=this.splitElement(c);c.is("ul","ol")||c.appendBogus()}return{previousBlock:c,nextBlock:e,wasStartOfBlock:a,wasEndOfBlock:b,elementPath:f}},splitElement:function(a){if(!this.collapsed)return null;
this.setEndAt(a,CKEDITOR.POSITION_BEFORE_END);var b=this.extractContents(),d=a.clone(false);b.appendTo(d);d.insertAfter(a);this.moveToPosition(a,CKEDITOR.POSITION_AFTER_END);return d},removeEmptyBlocksAtEnd:function(){function a(c){return function(a){return b(a)||(d(a)||a.type==CKEDITOR.NODE_ELEMENT&&a.isEmptyInlineRemoveable())||c.is("table")&&a.is("caption")?false:true}}var b=CKEDITOR.dom.walker.whitespaces(),d=CKEDITOR.dom.walker.bookmark(false);return function(b){for(var d=this.createBookmark(),
c=this[b?"endPath":"startPath"](),e=c.block||c.blockLimit,f;e&&!e.equals(c.root)&&!e.getFirst(a(e));){f=e.getParent();this[b?"setEndAt":"setStartAt"](e,CKEDITOR.POSITION_AFTER_END);e.remove(1);e=f}this.moveToBookmark(d)}}(),startPath:function(){return new CKEDITOR.dom.elementPath(this.startContainer,this.root)},endPath:function(){return new CKEDITOR.dom.elementPath(this.endContainer,this.root)},checkBoundaryOfElement:function(a,b){var d=b==CKEDITOR.START,e=this.clone();e.collapse(d);e[d?"setStartAt":
"setEndAt"](a,d?CKEDITOR.POSITION_AFTER_START:CKEDITOR.POSITION_BEFORE_END);e=new CKEDITOR.dom.walker(e);e.evaluator=c(d);return e[d?"checkBackward":"checkForward"]()},checkStartOfBlock:function(){var b=this.startContainer,d=this.startOffset;if(CKEDITOR.env.ie&&d&&b.type==CKEDITOR.NODE_TEXT){b=CKEDITOR.tools.ltrim(b.substring(0,d));n.test(b)&&this.trim(0,1)}this.trim();b=new CKEDITOR.dom.elementPath(this.startContainer,this.root);d=this.clone();d.collapse(true);d.setStartAt(b.block||b.blockLimit,
CKEDITOR.POSITION_AFTER_START);b=new CKEDITOR.dom.walker(d);b.evaluator=a();return b.checkBackward()},checkEndOfBlock:function(){var b=this.endContainer,d=this.endOffset;if(CKEDITOR.env.ie&&b.type==CKEDITOR.NODE_TEXT){b=CKEDITOR.tools.rtrim(b.substring(d));n.test(b)&&this.trim(1,0)}this.trim();b=new CKEDITOR.dom.elementPath(this.endContainer,this.root);d=this.clone();d.collapse(false);d.setEndAt(b.block||b.blockLimit,CKEDITOR.POSITION_BEFORE_END);b=new CKEDITOR.dom.walker(d);b.evaluator=a();return b.checkForward()},
getPreviousNode:function(a,b,d){var c=this.clone();c.collapse(1);c.setStartAt(d||this.root,CKEDITOR.POSITION_AFTER_START);d=new CKEDITOR.dom.walker(c);d.evaluator=a;d.guard=b;return d.previous()},getNextNode:function(a,b,d){var c=this.clone();c.collapse();c.setEndAt(d||this.root,CKEDITOR.POSITION_BEFORE_END);d=new CKEDITOR.dom.walker(c);d.evaluator=a;d.guard=b;return d.next()},checkReadOnly:function(){function a(b,d){for(;b;){if(b.type==CKEDITOR.NODE_ELEMENT){if(b.getAttribute("contentEditable")==
"false"&&!b.data("cke-editable"))return 0;if(b.is("html")||b.getAttribute("contentEditable")=="true"&&(b.contains(d)||b.equals(d)))break}b=b.getParent()}return 1}return function(){var b=this.startContainer,d=this.endContainer;return!(a(b,d)&&a(d,b))}}(),moveToElementEditablePosition:function(a,b){if(a.type==CKEDITOR.NODE_ELEMENT&&!a.isEditable(false)){this.moveToPosition(a,b?CKEDITOR.POSITION_AFTER_END:CKEDITOR.POSITION_BEFORE_START);return true}for(var d=0;a;){if(a.type==CKEDITOR.NODE_TEXT){b&&this.endContainer&&
this.checkEndOfBlock()&&n.test(a.getText())?this.moveToPosition(a,CKEDITOR.POSITION_BEFORE_START):this.moveToPosition(a,b?CKEDITOR.POSITION_AFTER_END:CKEDITOR.POSITION_BEFORE_START);d=1;break}if(a.type==CKEDITOR.NODE_ELEMENT)if(a.isEditable()){this.moveToPosition(a,b?CKEDITOR.POSITION_BEFORE_END:CKEDITOR.POSITION_AFTER_START);d=1}else if(b&&a.is("br")&&this.endContainer&&this.checkEndOfBlock())this.moveToPosition(a,CKEDITOR.POSITION_BEFORE_START);else if(a.getAttribute("contenteditable")=="false"&&
a.is(CKEDITOR.dtd.$block)){this.setStartBefore(a);this.setEndAfter(a);return true}var c=a,e=d,f=void 0;c.type==CKEDITOR.NODE_ELEMENT&&c.isEditable(false)&&(f=c[b?"getLast":"getFirst"](i));!e&&!f&&(f=c[b?"getPrevious":"getNext"](i));a=f}return!!d},moveToClosestEditablePosition:function(a,b){var d=new CKEDITOR.dom.range(this.root),c=0,e,f=[CKEDITOR.POSITION_AFTER_END,CKEDITOR.POSITION_BEFORE_START];d.moveToPosition(a,f[b?0:1]);if(a.is(CKEDITOR.dtd.$block)){if(e=d[b?"getNextEditableNode":"getPreviousEditableNode"]()){c=
1;if(e.type==CKEDITOR.NODE_ELEMENT&&e.is(CKEDITOR.dtd.$block)&&e.getAttribute("contenteditable")=="false"){d.setStartAt(e,CKEDITOR.POSITION_BEFORE_START);d.setEndAt(e,CKEDITOR.POSITION_AFTER_END)}else d.moveToPosition(e,f[b?1:0])}}else c=1;c&&this.moveToRange(d);return!!c},moveToElementEditStart:function(a){return this.moveToElementEditablePosition(a)},moveToElementEditEnd:function(a){return this.moveToElementEditablePosition(a,true)},getEnclosedNode:function(){var a=this.clone();a.optimize();if(a.startContainer.type!=
CKEDITOR.NODE_ELEMENT||a.endContainer.type!=CKEDITOR.NODE_ELEMENT)return null;var a=new CKEDITOR.dom.walker(a),b=CKEDITOR.dom.walker.bookmark(false,true),d=CKEDITOR.dom.walker.whitespaces(true);a.evaluator=function(a){return d(a)&&b(a)};var c=a.next();a.reset();return c&&c.equals(a.previous())?c:null},getTouchedStartNode:function(){var a=this.startContainer;return this.collapsed||a.type!=CKEDITOR.NODE_ELEMENT?a:a.getChild(this.startOffset)||a},getTouchedEndNode:function(){var a=this.endContainer;
return this.collapsed||a.type!=CKEDITOR.NODE_ELEMENT?a:a.getChild(this.endOffset-1)||a},getNextEditableNode:b(),getPreviousEditableNode:b(1),scrollIntoView:function(){var a=new CKEDITOR.dom.element.createFromHtml("<span>&nbsp;</span>",this.document),b,d,c,e=this.clone();e.optimize();if(c=e.startContainer.type==CKEDITOR.NODE_TEXT){d=e.startContainer.getText();b=e.startContainer.split(e.startOffset);a.insertAfter(e.startContainer)}else e.insertNode(a);a.scrollIntoView();if(c){e.startContainer.setText(d);
b.remove()}a.remove()}}})();CKEDITOR.POSITION_AFTER_START=1;CKEDITOR.POSITION_BEFORE_END=2;CKEDITOR.POSITION_BEFORE_START=3;CKEDITOR.POSITION_AFTER_END=4;CKEDITOR.ENLARGE_ELEMENT=1;CKEDITOR.ENLARGE_BLOCK_CONTENTS=2;CKEDITOR.ENLARGE_LIST_ITEM_CONTENTS=3;CKEDITOR.ENLARGE_INLINE=4;CKEDITOR.START=1;CKEDITOR.END=2;CKEDITOR.SHRINK_ELEMENT=1;CKEDITOR.SHRINK_TEXT=2;"use strict";
(function(){function a(a){if(!(arguments.length<1)){this.range=a;this.forceBrBreak=0;this.enlargeBr=1;this.enforceRealBlocks=0;this._||(this._={})}}function c(a,b,d){for(a=a.getNextSourceNode(b,null,d);!e(a);)a=a.getNextSourceNode(b,null,d);return a}function b(a){var b=[];a.forEach(function(a){if(a.getAttribute("contenteditable")=="true"){b.push(a);return false}},CKEDITOR.NODE_ELEMENT,true);return b}function f(a,d,c,e){a:{e==void 0&&(e=b(c));for(var g;g=e.shift();)if(g.getDtd().p){e={element:g,remaining:e};
break a}e=null}if(!e)return 0;if((g=CKEDITOR.filter.instances[e.element.data("cke-filter")])&&!g.check(d))return f(a,d,c,e.remaining);d=new CKEDITOR.dom.range(e.element);d.selectNodeContents(e.element);d=d.createIterator();d.enlargeBr=a.enlargeBr;d.enforceRealBlocks=a.enforceRealBlocks;d.activeFilter=d.filter=g;a._.nestedEditable={element:e.element,container:c,remaining:e.remaining,iterator:d};return 1}var d=/^[\r\n\t ]+$/,e=CKEDITOR.dom.walker.bookmark(false,true),g=CKEDITOR.dom.walker.whitespaces(true),
n=function(a){return e(a)&&g(a)};a.prototype={getNextParagraph:function(a){var b,g,p,s,x,a=a||"p";if(this._.nestedEditable){if(b=this._.nestedEditable.iterator.getNextParagraph(a)){this.activeFilter=this._.nestedEditable.iterator.activeFilter;return b}this.activeFilter=this.filter;if(f(this,a,this._.nestedEditable.container,this._.nestedEditable.remaining)){this.activeFilter=this._.nestedEditable.iterator.activeFilter;return this._.nestedEditable.iterator.getNextParagraph(a)}this._.nestedEditable=
null}if(!this.range.root.getDtd()[a])return null;if(!this._.started){var q=this.range.clone();q.shrink(CKEDITOR.SHRINK_ELEMENT,true);g=q.endContainer.hasAscendant("pre",true)||q.startContainer.hasAscendant("pre",true);q.enlarge(this.forceBrBreak&&!g||!this.enlargeBr?CKEDITOR.ENLARGE_LIST_ITEM_CONTENTS:CKEDITOR.ENLARGE_BLOCK_CONTENTS);if(!q.collapsed){g=new CKEDITOR.dom.walker(q.clone());var o=CKEDITOR.dom.walker.bookmark(true,true);g.evaluator=o;this._.nextNode=g.next();g=new CKEDITOR.dom.walker(q.clone());
g.evaluator=o;g=g.previous();this._.lastNode=g.getNextSourceNode(true);if(this._.lastNode&&this._.lastNode.type==CKEDITOR.NODE_TEXT&&!CKEDITOR.tools.trim(this._.lastNode.getText())&&this._.lastNode.getParent().isBlockBoundary()){o=this.range.clone();o.moveToPosition(this._.lastNode,CKEDITOR.POSITION_AFTER_END);if(o.checkEndOfBlock()){o=new CKEDITOR.dom.elementPath(o.endContainer,o.root);this._.lastNode=(o.block||o.blockLimit).getNextSourceNode(true)}}if(!this._.lastNode||!q.root.contains(this._.lastNode)){this._.lastNode=
this._.docEndMarker=q.document.createText("");this._.lastNode.insertAfter(g)}q=null}this._.started=1;g=q}o=this._.nextNode;q=this._.lastNode;for(this._.nextNode=null;o;){var u=0,A=o.hasAscendant("pre"),k=o.type!=CKEDITOR.NODE_ELEMENT,l=0;if(k)o.type==CKEDITOR.NODE_TEXT&&d.test(o.getText())&&(k=0);else{var j=o.getName();if(CKEDITOR.dtd.$block[j]&&o.getAttribute("contenteditable")=="false"){b=o;f(this,a,b);break}else if(o.isBlockBoundary(this.forceBrBreak&&!A&&{br:1})){if(j=="br")k=1;else if(!g&&!o.getChildCount()&&
j!="hr"){b=o;p=o.equals(q);break}if(g){g.setEndAt(o,CKEDITOR.POSITION_BEFORE_START);if(j!="br")this._.nextNode=o}u=1}else{if(o.getFirst()){if(!g){g=this.range.clone();g.setStartAt(o,CKEDITOR.POSITION_BEFORE_START)}o=o.getFirst();continue}k=1}}if(k&&!g){g=this.range.clone();g.setStartAt(o,CKEDITOR.POSITION_BEFORE_START)}p=(!u||k)&&o.equals(q);if(g&&!u)for(;!o.getNext(n)&&!p;){j=o.getParent();if(j.isBlockBoundary(this.forceBrBreak&&!A&&{br:1})){u=1;k=0;p||j.equals(q);g.setEndAt(j,CKEDITOR.POSITION_BEFORE_END);
break}o=j;k=1;p=o.equals(q);l=1}k&&g.setEndAt(o,CKEDITOR.POSITION_AFTER_END);o=c(o,l,q);if((p=!o)||u&&g)break}if(!b){if(!g){this._.docEndMarker&&this._.docEndMarker.remove();return this._.nextNode=null}b=new CKEDITOR.dom.elementPath(g.startContainer,g.root);o=b.blockLimit;u={div:1,th:1,td:1};b=b.block;if(!b&&o&&!this.enforceRealBlocks&&u[o.getName()]&&g.checkStartOfBlock()&&g.checkEndOfBlock()&&!o.equals(g.root))b=o;else if(!b||this.enforceRealBlocks&&b.getName()=="li"){b=this.range.document.createElement(a);
g.extractContents().appendTo(b);b.trim();g.insertNode(b);s=x=true}else if(b.getName()!="li"){if(!g.checkStartOfBlock()||!g.checkEndOfBlock()){b=b.clone(false);g.extractContents().appendTo(b);b.trim();x=g.splitBlock();s=!x.wasStartOfBlock;x=!x.wasEndOfBlock;g.insertNode(b)}}else if(!p)this._.nextNode=b.equals(q)?null:c(g.getBoundaryNodes().endNode,1,q)}if(s)(s=b.getPrevious())&&s.type==CKEDITOR.NODE_ELEMENT&&(s.getName()=="br"?s.remove():s.getLast()&&s.getLast().$.nodeName.toLowerCase()=="br"&&s.getLast().remove());
if(x)(s=b.getLast())&&s.type==CKEDITOR.NODE_ELEMENT&&s.getName()=="br"&&(!CKEDITOR.env.needsBrFiller||s.getPrevious(e)||s.getNext(e))&&s.remove();if(!this._.nextNode)this._.nextNode=p||b.equals(q)||!q?null:c(b,1,q);return b}};CKEDITOR.dom.range.prototype.createIterator=function(){return new a(this)}})();
CKEDITOR.command=function(a,c){this.uiItems=[];this.exec=function(b){if(this.state==CKEDITOR.TRISTATE_DISABLED||!this.checkAllowed())return false;this.editorFocus&&a.focus();return this.fire("exec")===false?true:c.exec.call(this,a,b)!==false};this.refresh=function(a,b){if(!this.readOnly&&a.readOnly)return true;if(this.context&&!b.isContextFor(this.context)){this.disable();return true}if(!this.checkAllowed(true)){this.disable();return true}this.startDisabled||this.enable();this.modes&&!this.modes[a.mode]&&
this.disable();return this.fire("refresh",{editor:a,path:b})===false?true:c.refresh&&c.refresh.apply(this,arguments)!==false};var b;this.checkAllowed=function(c){return!c&&typeof b=="boolean"?b:b=a.activeFilter.checkFeature(this)};CKEDITOR.tools.extend(this,c,{modes:{wysiwyg:1},editorFocus:1,contextSensitive:!!c.context,state:CKEDITOR.TRISTATE_DISABLED});CKEDITOR.event.call(this)};
CKEDITOR.command.prototype={enable:function(){this.state==CKEDITOR.TRISTATE_DISABLED&&this.checkAllowed()&&this.setState(!this.preserveState||typeof this.previousState=="undefined"?CKEDITOR.TRISTATE_OFF:this.previousState)},disable:function(){this.setState(CKEDITOR.TRISTATE_DISABLED)},setState:function(a){if(this.state==a||a!=CKEDITOR.TRISTATE_DISABLED&&!this.checkAllowed())return false;this.previousState=this.state;this.state=a;this.fire("state");return true},toggleState:function(){this.state==CKEDITOR.TRISTATE_OFF?
this.setState(CKEDITOR.TRISTATE_ON):this.state==CKEDITOR.TRISTATE_ON&&this.setState(CKEDITOR.TRISTATE_OFF)}};CKEDITOR.event.implementOn(CKEDITOR.command.prototype);CKEDITOR.ENTER_P=1;CKEDITOR.ENTER_BR=2;CKEDITOR.ENTER_DIV=3;
CKEDITOR.config={customConfig:"config.js",autoUpdateElement:!0,language:"",defaultLanguage:"en",contentsLangDirection:"",enterMode:CKEDITOR.ENTER_P,forceEnterMode:!1,shiftEnterMode:CKEDITOR.ENTER_BR,docType:"<!DOCTYPE html>",bodyId:"",bodyClass:"",fullPage:!1,height:200,extraPlugins:"",removePlugins:"",protectedSource:[],tabIndex:0,width:"",baseFloatZIndex:1E4,blockedKeystrokes:[CKEDITOR.CTRL+66,CKEDITOR.CTRL+73,CKEDITOR.CTRL+85]};
(function(){function a(a,b,d,c,e){var f,o,a=[];for(f in b){o=b[f];o=typeof o=="boolean"?{}:typeof o=="function"?{match:o}:L(o);if(f.charAt(0)!="$")o.elements=f;if(d)o.featureName=d.toLowerCase();var j=o;j.elements=g(j.elements,/\s+/)||null;j.propertiesOnly=j.propertiesOnly||j.elements===true;var k=/\s*,\s*/,l=void 0;for(l in t){j[l]=g(j[l],k)||null;var v=j,r=E[l],y=g(j[E[l]],k),q=j[l],w=[],u=true,h=void 0;y?u=false:y={};for(h in q)if(h.charAt(0)=="!"){h=h.slice(1);w.push(h);y[h]=true;u=false}for(;h=
w.pop();){q[h]=q["!"+h];delete q["!"+h]}v[r]=(u?false:y)||null}j.match=j.match||null;c.push(o);a.push(o)}for(var b=e.elements,e=e.generic,i,d=0,c=a.length;d<c;++d){f=L(a[d]);o=f.classes===true||f.styles===true||f.attributes===true;j=f;l=r=k=void 0;for(k in t)j[k]=A(j[k]);v=true;for(l in E){k=E[l];r=j[k];y=[];q=void 0;for(q in r)q.indexOf("*")>-1?y.push(RegExp("^"+q.replace(/\*/g,".*")+"$")):y.push(q);r=y;if(r.length){j[k]=r;v=false}}j.nothingRequired=v;j.noProperties=!(j.attributes||j.classes||j.styles);
if(f.elements===true||f.elements===null)e[o?"unshift":"push"](f);else{j=f.elements;delete f.elements;for(i in j)if(b[i])b[i][o?"unshift":"push"](f);else b[i]=[f]}}}function c(a,d,c,e){if(!a.match||a.match(d))if(e||n(a,d)){if(!a.propertiesOnly)c.valid=true;if(!c.allAttributes)c.allAttributes=b(a.attributes,d.attributes,c.validAttributes);if(!c.allStyles)c.allStyles=b(a.styles,d.styles,c.validStyles);if(!c.allClasses){a=a.classes;d=d.classes;e=c.validClasses;if(a)if(a===true)a=true;else{for(var f=0,
o=d.length,j;f<o;++f){j=d[f];e[j]||(e[j]=a(j))}a=false}else a=false;c.allClasses=a}}}function b(a,b,d){if(!a)return false;if(a===true)return true;for(var c in b)d[c]||(d[c]=a(c));return false}function f(a,b,c){if(!a.match||a.match(b)){if(a.noProperties)return false;c.hadInvalidAttribute=d(a.attributes,b.attributes)||c.hadInvalidAttribute;c.hadInvalidStyle=d(a.styles,b.styles)||c.hadInvalidStyle;a=a.classes;b=b.classes;if(a){for(var e=false,f=a===true,o=b.length;o--;)if(f||a(b[o])){b.splice(o,1);e=
true}a=e}else a=false;c.hadInvalidClass=a||c.hadInvalidClass}}function d(a,b){if(!a)return false;var d=false,c=a===true,e;for(e in b)if(c||a(e)){delete b[e];d=true}return d}function e(a,b,d){if(a.disabled||a.customConfig&&!d||!b)return false;a._.cachedChecks={};return true}function g(a,b){if(!a)return false;if(a===true)return a;if(typeof a=="string"){a=J(a);return a=="*"?true:CKEDITOR.tools.convertArrayToObject(a.split(b))}if(CKEDITOR.tools.isArray(a))return a.length?CKEDITOR.tools.convertArrayToObject(a):
false;var d={},c=0,e;for(e in a){d[e]=a[e];c++}return c?d:false}function n(a,b){if(a.nothingRequired)return true;var d,c,e,f;if(e=a.requiredClasses){f=b.classes;for(d=0;d<e.length;++d){c=e[d];if(typeof c=="string"){if(CKEDITOR.tools.indexOf(f,c)==-1)return false}else if(!CKEDITOR.tools.checkIfAnyArrayItemMatches(f,c))return false}}return h(b.styles,a.requiredStyles)&&h(b.attributes,a.requiredAttributes)}function h(a,b){if(!b)return true;for(var d=0,c;d<b.length;++d){c=b[d];if(typeof c=="string"){if(!(c in
a))return false}else if(!CKEDITOR.tools.checkIfAnyObjectPropertyMatches(a,c))return false}return true}function i(a){if(!a)return{};for(var a=a.split(/\s*,\s*/).sort(),b={};a.length;)b[a.shift()]=w;return b}function m(a){for(var b,d,c,e,f={},o=1,a=J(a);b=a.match(y);){if(d=b[2]){c=p(d,"styles");e=p(d,"attrs");d=p(d,"classes")}else c=e=d=null;f["$"+o++]={elements:b[1],classes:d,styles:c,attributes:e};a=a.slice(b[0].length)}return f}function p(a,b){var d=a.match(C[b]);return d?J(d[1]):null}function s(a){var b=
a.styleBackup=a.attributes.style,d=a.classBackup=a.attributes["class"];if(!a.styles)a.styles=CKEDITOR.tools.parseCssText(b||"",1);if(!a.classes)a.classes=d?d.split(/\s+/):[]}function x(a,b,d,e){var j=0,k;if(e.toHtml)b.name=b.name.replace(ba,"$1");if(e.doCallbacks&&a.elementCallbacks){a:for(var l=a.elementCallbacks,g=0,r=l.length,y;g<r;++g)if(y=l[g](b)){k=y;break a}if(k)return k}if(e.doTransform)if(k=a._.transformations[b.name]){s(b);for(l=0;l<k.length;++l)v(a,b,k[l]);o(b)}if(e.doFilter){a:{l=b.name;
g=a._;a=g.allowedRules.elements[l];k=g.allowedRules.generic;l=g.disallowedRules.elements[l];g=g.disallowedRules.generic;r=e.skipRequired;y={valid:false,validAttributes:{},validClasses:{},validStyles:{},allAttributes:false,allClasses:false,allStyles:false,hadInvalidAttribute:false,hadInvalidClass:false,hadInvalidStyle:false};var q,w;if(!a&&!k)a=null;else{s(b);if(l){q=0;for(w=l.length;q<w;++q)if(f(l[q],b,y)===false){a=null;break a}}if(g){q=0;for(w=g.length;q<w;++q)f(g[q],b,y)}if(a){q=0;for(w=a.length;q<
w;++q)c(a[q],b,y,r)}if(k){q=0;for(w=k.length;q<w;++q)c(k[q],b,y,r)}a=y}}if(!a){d.push(b);return D}if(!a.valid){d.push(b);return D}w=a.validAttributes;var h=a.validStyles;k=a.validClasses;var l=b.attributes,E=b.styles,g=b.classes,r=b.classBackup,i=b.styleBackup,t,z,C=[];y=[];var I=/^data-cke-/;q=false;delete l.style;delete l["class"];delete b.classBackup;delete b.styleBackup;if(!a.allAttributes)for(t in l)if(!w[t])if(I.test(t)){if(t!=(z=t.replace(/^data-cke-saved-/,""))&&!w[z]){delete l[t];q=true}}else{delete l[t];
q=true}if(!a.allStyles||a.hadInvalidStyle){for(t in E)a.allStyles||h[t]?C.push(t+":"+E[t]):q=true;if(C.length)l.style=C.sort().join("; ")}else if(i)l.style=i;if(!a.allClasses||a.hadInvalidClass){for(t=0;t<g.length;++t)(a.allClasses||k[g[t]])&&y.push(g[t]);y.length&&(l["class"]=y.sort().join(" "));r&&y.length<r.split(/\s+/).length&&(q=true)}else r&&(l["class"]=r);q&&(j=D);if(!e.skipFinalValidation&&!u(b)){d.push(b);return D}}if(e.toHtml)b.name=b.name.replace(ca,"cke:$1");return j}function q(a){var b=
[],d;for(d in a)d.indexOf("*")>-1&&b.push(d.replace(/\*/g,".*"));return b.length?RegExp("^(?:"+b.join("|")+")$"):null}function o(a){var b=a.attributes,d;delete b.style;delete b["class"];if(d=CKEDITOR.tools.writeCssText(a.styles,true))b.style=d;a.classes.length&&(b["class"]=a.classes.sort().join(" "))}function u(a){switch(a.name){case "a":if(!a.children.length&&!a.attributes.name)return false;break;case "img":if(!a.attributes.src)return false}return true}function A(a){if(!a)return false;if(a===true)return true;
var b=q(a);return function(d){return d in a||b&&d.match(b)}}function k(){return new CKEDITOR.htmlParser.element("br")}function l(a){return a.type==CKEDITOR.NODE_ELEMENT&&(a.name=="br"||F.$block[a.name])}function j(a,b,d){var c=a.name;if(F.$empty[c]||!a.children.length)if(c=="hr"&&b=="br")a.replaceWith(k());else{a.parent&&d.push({check:"it",el:a.parent});a.remove()}else if(F.$block[c]||c=="tr")if(b=="br"){if(a.previous&&!l(a.previous)){b=k();b.insertBefore(a)}if(a.next&&!l(a.next)){b=k();b.insertAfter(a)}a.replaceWithChildren()}else{var c=
a.children,e;b:{e=F[b];for(var f=0,o=c.length,j;f<o;++f){j=c[f];if(j.type==CKEDITOR.NODE_ELEMENT&&!e[j.name]){e=false;break b}}e=true}if(e){a.name=b;a.attributes={};d.push({check:"parent-down",el:a})}else{e=a.parent;for(var f=e.type==CKEDITOR.NODE_DOCUMENT_FRAGMENT||e.name=="body",g,o=c.length;o>0;){j=c[--o];if(f&&(j.type==CKEDITOR.NODE_TEXT||j.type==CKEDITOR.NODE_ELEMENT&&F.$inline[j.name])){if(!g){g=new CKEDITOR.htmlParser.element(b);g.insertAfter(a);d.push({check:"parent-down",el:g})}g.add(j,0)}else{g=
null;j.insertAfter(a);e.type!=CKEDITOR.NODE_DOCUMENT_FRAGMENT&&(j.type==CKEDITOR.NODE_ELEMENT&&!F[e.name][j.name])&&d.push({check:"el-up",el:j})}}a.remove()}}else if(c=="style")a.remove();else{a.parent&&d.push({check:"it",el:a.parent});a.replaceWithChildren()}}function v(a,b,d){var c,e;for(c=0;c<d.length;++c){e=d[c];if((!e.check||a.check(e.check,false))&&(!e.left||e.left(b))){e.right(b,G);break}}}function I(a,b){var d=b.getDefinition(),c=d.attributes,e=d.styles,f,o,j,k;if(a.name!=d.element)return false;
for(f in c)if(f=="class"){d=c[f].split(/\s+/);for(j=a.classes.join("|");k=d.pop();)if(j.indexOf(k)==-1)return false}else if(a.attributes[f]!=c[f])return false;for(o in e)if(a.styles[o]!=e[o])return false;return true}function r(a,b){var d,c;if(typeof a=="string")d=a;else if(a instanceof CKEDITOR.style)c=a;else{d=a[0];c=a[1]}return[{element:d,left:c,right:function(a,d){d.transform(a,b)}}]}function O(a){return function(b){return I(b,a)}}function S(a){return function(b,d){d[a](b)}}var F=CKEDITOR.dtd,
D=1,L=CKEDITOR.tools.copy,J=CKEDITOR.tools.trim,w="cke-test",z=["","p","br","div"];CKEDITOR.FILTER_SKIP_TREE=2;CKEDITOR.filter=function(a){this.allowedContent=[];this.disallowedContent=[];this.elementCallbacks=null;this.disabled=false;this.editor=null;this.id=CKEDITOR.tools.getNextNumber();this._={allowedRules:{elements:{},generic:[]},disallowedRules:{elements:{},generic:[]},transformations:{},cachedTests:{}};CKEDITOR.filter.instances[this.id]=this;if(a instanceof CKEDITOR.editor){a=this.editor=a;
this.customConfig=true;var b=a.config.allowedContent;if(b===true)this.disabled=true;else{if(!b)this.customConfig=false;this.allow(b,"config",1);this.allow(a.config.extraAllowedContent,"extra",1);this.allow(z[a.enterMode]+" "+z[a.shiftEnterMode],"default",1);this.disallow(a.config.disallowedContent)}}else{this.customConfig=false;this.allow(a,"default",1)}};CKEDITOR.filter.instances={};CKEDITOR.filter.prototype={allow:function(b,d,c){if(!e(this,b,c))return false;var f,o;if(typeof b=="string")b=m(b);
else if(b instanceof CKEDITOR.style){if(b.toAllowedContentRules)return this.allow(b.toAllowedContentRules(this.editor),d,c);f=b.getDefinition();b={};c=f.attributes;b[f.element]=f={styles:f.styles,requiredStyles:f.styles&&CKEDITOR.tools.objectKeys(f.styles)};if(c){c=L(c);f.classes=c["class"]?c["class"].split(/\s+/):null;f.requiredClasses=f.classes;delete c["class"];f.attributes=c;f.requiredAttributes=c&&CKEDITOR.tools.objectKeys(c)}}else if(CKEDITOR.tools.isArray(b)){for(f=0;f<b.length;++f)o=this.allow(b[f],
d,c);return o}a(this,b,d,this.allowedContent,this._.allowedRules);return true},applyTo:function(a,b,d,c){if(this.disabled)return false;var e=this,f=[],o=this.editor&&this.editor.config.protectedSource,k,l=false,g={doFilter:!d,doTransform:true,doCallbacks:true,toHtml:b};a.forEach(function(a){if(a.type==CKEDITOR.NODE_ELEMENT){if(a.attributes["data-cke-filter"]=="off")return false;if(!b||!(a.name=="span"&&~CKEDITOR.tools.objectKeys(a.attributes).join("|").indexOf("data-cke-"))){k=x(e,a,f,g);if(k&D)l=
true;else if(k&2)return false}}else if(a.type==CKEDITOR.NODE_COMMENT&&a.value.match(/^\{cke_protected\}(?!\{C\})/)){var d;a:{var c=decodeURIComponent(a.value.replace(/^\{cke_protected\}/,""));d=[];var j,v,r;if(o)for(v=0;v<o.length;++v)if((r=c.match(o[v]))&&r[0].length==c.length){d=true;break a}c=CKEDITOR.htmlParser.fragment.fromHtml(c);c.children.length==1&&(j=c.children[0]).type==CKEDITOR.NODE_ELEMENT&&x(e,j,d,g);d=!d.length}d||f.push(a)}},null,true);f.length&&(l=true);for(var v,a=[],c=z[c||(this.editor?
this.editor.enterMode:CKEDITOR.ENTER_P)];d=f.pop();)d.type==CKEDITOR.NODE_ELEMENT?j(d,c,a):d.remove();for(;v=a.pop();){d=v.el;if(d.parent)switch(v.check){case "it":F.$removeEmpty[d.name]&&!d.children.length?j(d,c,a):u(d)||j(d,c,a);break;case "el-up":d.parent.type!=CKEDITOR.NODE_DOCUMENT_FRAGMENT&&!F[d.parent.name][d.name]&&j(d,c,a);break;case "parent-down":d.parent.type!=CKEDITOR.NODE_DOCUMENT_FRAGMENT&&!F[d.parent.name][d.name]&&j(d.parent,c,a)}}return l},checkFeature:function(a){if(this.disabled||
!a)return true;a.toFeature&&(a=a.toFeature(this.editor));return!a.requiredContent||this.check(a.requiredContent)},disable:function(){this.disabled=true},disallow:function(b){if(!e(this,b,true))return false;typeof b=="string"&&(b=m(b));a(this,b,null,this.disallowedContent,this._.disallowedRules);return true},addContentForms:function(a){if(!this.disabled&&a){var b,d,c=[],e;for(b=0;b<a.length&&!e;++b){d=a[b];if((typeof d=="string"||d instanceof CKEDITOR.style)&&this.check(d))e=d}if(e){for(b=0;b<a.length;++b)c.push(r(a[b],
e));this.addTransformations(c)}}},addElementCallback:function(a){if(!this.elementCallbacks)this.elementCallbacks=[];this.elementCallbacks.push(a)},addFeature:function(a){if(this.disabled||!a)return true;a.toFeature&&(a=a.toFeature(this.editor));this.allow(a.allowedContent,a.name);this.addTransformations(a.contentTransformations);this.addContentForms(a.contentForms);return a.requiredContent&&(this.customConfig||this.disallowedContent.length)?this.check(a.requiredContent):true},addTransformations:function(a){var b,
d;if(!this.disabled&&a){var c=this._.transformations,e;for(e=0;e<a.length;++e){b=a[e];var f=void 0,o=void 0,j=void 0,k=void 0,l=void 0,g=void 0;d=[];for(o=0;o<b.length;++o){j=b[o];if(typeof j=="string"){j=j.split(/\s*:\s*/);k=j[0];l=null;g=j[1]}else{k=j.check;l=j.left;g=j.right}if(!f){f=j;f=f.element?f.element:k?k.match(/^([a-z0-9]+)/i)[0]:f.left.getDefinition().element}l instanceof CKEDITOR.style&&(l=O(l));d.push({check:k==f?null:k,left:l,right:typeof g=="string"?S(g):g})}b=f;c[b]||(c[b]=[]);c[b].push(d)}}},
check:function(a,b,d){if(this.disabled)return true;if(CKEDITOR.tools.isArray(a)){for(var c=a.length;c--;)if(this.check(a[c],b,d))return true;return false}var e,f;if(typeof a=="string"){f=a+"<"+(b===false?"0":"1")+(d?"1":"0")+">";if(f in this._.cachedChecks)return this._.cachedChecks[f];c=m(a).$1;e=c.styles;var j=c.classes;c.name=c.elements;c.classes=j=j?j.split(/\s*,\s*/):[];c.styles=i(e);c.attributes=i(c.attributes);c.children=[];j.length&&(c.attributes["class"]=j.join(" "));if(e)c.attributes.style=
CKEDITOR.tools.writeCssText(c.styles);e=c}else{c=a.getDefinition();e=c.styles;j=c.attributes||{};if(e){e=L(e);j.style=CKEDITOR.tools.writeCssText(e,true)}else e={};e={name:c.element,attributes:j,classes:j["class"]?j["class"].split(/\s+/):[],styles:e,children:[]}}var j=CKEDITOR.tools.clone(e),k=[],l;if(b!==false&&(l=this._.transformations[e.name])){for(c=0;c<l.length;++c)v(this,e,l[c]);o(e)}x(this,j,k,{doFilter:true,doTransform:b!==false,skipRequired:!d,skipFinalValidation:!d});b=k.length>0?false:
CKEDITOR.tools.objectCompare(e.attributes,j.attributes,true)?true:false;typeof a=="string"&&(this._.cachedChecks[f]=b);return b},getAllowedEnterMode:function(){var a=["p","div","br"],b={p:CKEDITOR.ENTER_P,div:CKEDITOR.ENTER_DIV,br:CKEDITOR.ENTER_BR};return function(d,c){var e=a.slice(),f;if(this.check(z[d]))return d;for(c||(e=e.reverse());f=e.pop();)if(this.check(f))return b[f];return CKEDITOR.ENTER_BR}}()};var t={styles:1,attributes:1,classes:1},E={styles:"requiredStyles",attributes:"requiredAttributes",
classes:"requiredClasses"},y=/^([a-z0-9*\s]+)((?:\s*\{[!\w\-,\s\*]+\}\s*|\s*\[[!\w\-,\s\*]+\]\s*|\s*\([!\w\-,\s\*]+\)\s*){0,3})(?:;\s*|$)/i,C={styles:/{([^}]+)}/,attrs:/\[([^\]]+)\]/,classes:/\(([^\)]+)\)/},ba=/^cke:(object|embed|param)$/,ca=/^(object|embed|param)$/,G=CKEDITOR.filter.transformationsTools={sizeToStyle:function(a){this.lengthToStyle(a,"width");this.lengthToStyle(a,"height")},sizeToAttribute:function(a){this.lengthToAttribute(a,"width");this.lengthToAttribute(a,"height")},lengthToStyle:function(a,
b,d){d=d||b;if(!(d in a.styles)){var c=a.attributes[b];if(c){/^\d+$/.test(c)&&(c=c+"px");a.styles[d]=c}}delete a.attributes[b]},lengthToAttribute:function(a,b,d){d=d||b;if(!(d in a.attributes)){var c=a.styles[b],e=c&&c.match(/^(\d+)(?:\.\d*)?px$/);e?a.attributes[d]=e[1]:c==w&&(a.attributes[d]=w)}delete a.styles[b]},alignmentToStyle:function(a){if(!("float"in a.styles)){var b=a.attributes.align;if(b=="left"||b=="right")a.styles["float"]=b}delete a.attributes.align},alignmentToAttribute:function(a){if(!("align"in
a.attributes)){var b=a.styles["float"];if(b=="left"||b=="right")a.attributes.align=b}delete a.styles["float"]},matchesStyle:I,transform:function(a,b){if(typeof b=="string")a.name=b;else{var d=b.getDefinition(),c=d.styles,e=d.attributes,f,j,o,k;a.name=d.element;for(f in e)if(f=="class"){d=a.classes.join("|");for(o=e[f].split(/\s+/);k=o.pop();)d.indexOf(k)==-1&&a.classes.push(k)}else a.attributes[f]=e[f];for(j in c)a.styles[j]=c[j]}}}})();
(function(){CKEDITOR.focusManager=function(a){if(a.focusManager)return a.focusManager;this.hasFocus=false;this.currentActive=null;this._={editor:a};return this};CKEDITOR.focusManager._={blurDelay:200};CKEDITOR.focusManager.prototype={focus:function(a){this._.timer&&clearTimeout(this._.timer);if(a)this.currentActive=a;if(!this.hasFocus&&!this._.locked){(a=CKEDITOR.currentInstance)&&a.focusManager.blur(1);this.hasFocus=true;(a=this._.editor.container)&&a.addClass("cke_focus");this._.editor.fire("focus")}},
lock:function(){this._.locked=1},unlock:function(){delete this._.locked},blur:function(a){function c(){if(this.hasFocus){this.hasFocus=false;var a=this._.editor.container;a&&a.removeClass("cke_focus");this._.editor.fire("blur")}}if(!this._.locked){this._.timer&&clearTimeout(this._.timer);var b=CKEDITOR.focusManager._.blurDelay;a||!b?c.call(this):this._.timer=CKEDITOR.tools.setTimeout(function(){delete this._.timer;c.call(this)},b,this)}},add:function(a,c){var b=a.getCustomData("focusmanager");if(!b||
b!=this){b&&b.remove(a);var b="focus",f="blur";if(c)if(CKEDITOR.env.ie){b="focusin";f="focusout"}else CKEDITOR.event.useCapture=1;var d={blur:function(){a.equals(this.currentActive)&&this.blur()},focus:function(){this.focus(a)}};a.on(b,d.focus,this);a.on(f,d.blur,this);if(c)CKEDITOR.event.useCapture=0;a.setCustomData("focusmanager",this);a.setCustomData("focusmanager_handlers",d)}},remove:function(a){a.removeCustomData("focusmanager");var c=a.removeCustomData("focusmanager_handlers");a.removeListener("blur",
c.blur);a.removeListener("focus",c.focus)}}})();CKEDITOR.keystrokeHandler=function(a){if(a.keystrokeHandler)return a.keystrokeHandler;this.keystrokes={};this.blockedKeystrokes={};this._={editor:a};return this};
(function(){var a,c=function(b){var b=b.data,d=b.getKeystroke(),c=this.keystrokes[d],g=this._.editor;a=g.fire("key",{keyCode:d,domEvent:b})===false;if(!a){c&&(a=g.execCommand(c,{from:"keystrokeHandler"})!==false);a||(a=!!this.blockedKeystrokes[d])}a&&b.preventDefault(true);return!a},b=function(b){if(a){a=false;b.data.preventDefault(true)}};CKEDITOR.keystrokeHandler.prototype={attach:function(a){a.on("keydown",c,this);if(CKEDITOR.env.gecko&&CKEDITOR.env.mac)a.on("keypress",b,this)}}})();
(function(){CKEDITOR.lang={languages:{af:1,ar:1,bg:1,bn:1,bs:1,ca:1,cs:1,cy:1,da:1,de:1,el:1,"en-au":1,"en-ca":1,"en-gb":1,en:1,eo:1,es:1,et:1,eu:1,fa:1,fi:1,fo:1,"fr-ca":1,fr:1,gl:1,gu:1,he:1,hi:1,hr:1,hu:1,id:1,is:1,it:1,ja:1,ka:1,km:1,ko:1,ku:1,lt:1,lv:1,mk:1,mn:1,ms:1,nb:1,nl:1,no:1,pl:1,"pt-br":1,pt:1,ro:1,ru:1,si:1,sk:1,sl:1,sq:1,"sr-latn":1,sr:1,sv:1,th:1,tr:1,tt:1,ug:1,uk:1,vi:1,"zh-cn":1,zh:1},rtl:{ar:1,fa:1,he:1,ku:1,ug:1},load:function(a,c,b){if(!a||!CKEDITOR.lang.languages[a])a=this.detect(c,
a);var f=this,c=function(){f[a].dir=f.rtl[a]?"rtl":"ltr";b(a,f[a])};this[a]?c():CKEDITOR.scriptLoader.load(CKEDITOR.getUrl("lang/"+a+".js"),c,this)},detect:function(a,c){var b=this.languages,c=c||navigator.userLanguage||navigator.language||a,f=c.toLowerCase().match(/([a-z]+)(?:-([a-z]+))?/),d=f[1],f=f[2];b[d+"-"+f]?d=d+"-"+f:b[d]||(d=null);CKEDITOR.lang.detect=d?function(){return d}:function(a){return a};return d||a}}})();
CKEDITOR.scriptLoader=function(){var a={},c={};return{load:function(b,f,d,e){var g=typeof b=="string";g&&(b=[b]);d||(d=CKEDITOR);var n=b.length,h=[],i=[],m=function(a){f&&(g?f.call(d,a):f.call(d,h,i))};if(n===0)m(true);else{var p=function(a,b){(b?h:i).push(a);if(--n<=0){e&&CKEDITOR.document.getDocumentElement().removeStyle("cursor");m(b)}},s=function(b,d){a[b]=1;var e=c[b];delete c[b];for(var f=0;f<e.length;f++)e[f](b,d)},x=function(b){if(a[b])p(b,true);else{var d=c[b]||(c[b]=[]);d.push(p);if(!(d.length>
1)){var e=new CKEDITOR.dom.element("script");e.setAttributes({type:"text/javascript",src:b});if(f)if(CKEDITOR.env.ie&&CKEDITOR.env.version<11)e.$.onreadystatechange=function(){if(e.$.readyState=="loaded"||e.$.readyState=="complete"){e.$.onreadystatechange=null;s(b,true)}};else{e.$.onload=function(){setTimeout(function(){s(b,true)},0)};e.$.onerror=function(){s(b,false)}}e.appendTo(CKEDITOR.document.getHead())}}};e&&CKEDITOR.document.getDocumentElement().setStyle("cursor","wait");for(var q=0;q<n;q++)x(b[q])}},
queue:function(){function a(){var b;(b=c[0])&&this.load(b.scriptUrl,b.callback,CKEDITOR,0)}var c=[];return function(d,e){var g=this;c.push({scriptUrl:d,callback:function(){e&&e.apply(this,arguments);c.shift();a.call(g)}});c.length==1&&a.call(this)}}()}}();CKEDITOR.resourceManager=function(a,c){this.basePath=a;this.fileName=c;this.registered={};this.loaded={};this.externals={};this._={waitingList:{}}};
CKEDITOR.resourceManager.prototype={add:function(a,c){if(this.registered[a])throw'[CKEDITOR.resourceManager.add] The resource name "'+a+'" is already registered.';var b=this.registered[a]=c||{};b.name=a;b.path=this.getPath(a);CKEDITOR.fire(a+CKEDITOR.tools.capitalize(this.fileName)+"Ready",b);return this.get(a)},get:function(a){return this.registered[a]||null},getPath:function(a){var c=this.externals[a];return CKEDITOR.getUrl(c&&c.dir||this.basePath+a+"/")},getFilePath:function(a){var c=this.externals[a];
return CKEDITOR.getUrl(this.getPath(a)+(c?c.file:this.fileName+".js"))},addExternal:function(a,c,b){for(var a=a.split(","),f=0;f<a.length;f++){var d=a[f];b||(c=c.replace(/[^\/]+$/,function(a){b=a;return""}));this.externals[d]={dir:c,file:b||this.fileName+".js"}}},load:function(a,c,b){CKEDITOR.tools.isArray(a)||(a=a?[a]:[]);for(var f=this.loaded,d=this.registered,e=[],g={},n={},h=0;h<a.length;h++){var i=a[h];if(i)if(!f[i]&&!d[i]){var m=this.getFilePath(i);e.push(m);m in g||(g[m]=[]);g[m].push(i)}else n[i]=
this.get(i)}CKEDITOR.scriptLoader.load(e,function(a,d){if(d.length)throw'[CKEDITOR.resourceManager.load] Resource name "'+g[d[0]].join(",")+'" was not found at "'+d[0]+'".';for(var e=0;e<a.length;e++)for(var q=g[a[e]],o=0;o<q.length;o++){var u=q[o];n[u]=this.get(u);f[u]=1}c.call(b,n)},this)}};CKEDITOR.plugins=new CKEDITOR.resourceManager("plugins/","plugin");
CKEDITOR.plugins.load=CKEDITOR.tools.override(CKEDITOR.plugins.load,function(a){var c={};return function(b,f,d){var e={},g=function(b){a.call(this,b,function(a){CKEDITOR.tools.extend(e,a);var b=[],n;for(n in a){var p=a[n],s=p&&p.requires;if(!c[n]){if(p.icons)for(var x=p.icons.split(","),q=x.length;q--;)CKEDITOR.skin.addIcon(x[q],p.path+"icons/"+(CKEDITOR.env.hidpi&&p.hidpi?"hidpi/":"")+x[q]+".png");c[n]=1}if(s){s.split&&(s=s.split(","));for(p=0;p<s.length;p++)e[s[p]]||b.push(s[p])}}if(b.length)g.call(this,
b);else{for(n in e){p=e[n];if(p.onLoad&&!p.onLoad._called){p.onLoad()===false&&delete e[n];p.onLoad._called=1}}f&&f.call(d||window,e)}},this)};g.call(this,b)}});CKEDITOR.plugins.setLang=function(a,c,b){var f=this.get(a),a=f.langEntries||(f.langEntries={}),f=f.lang||(f.lang=[]);f.split&&(f=f.split(","));CKEDITOR.tools.indexOf(f,c)==-1&&f.push(c);a[c]=b};CKEDITOR.ui=function(a){if(a.ui)return a.ui;this.items={};this.instances={};this.editor=a;this._={handlers:{}};return this};
CKEDITOR.ui.prototype={add:function(a,c,b){b.name=a.toLowerCase();var f=this.items[a]={type:c,command:b.command||null,args:Array.prototype.slice.call(arguments,2)};CKEDITOR.tools.extend(f,b)},get:function(a){return this.instances[a]},create:function(a){var c=this.items[a],b=c&&this._.handlers[c.type],f=c&&c.command&&this.editor.getCommand(c.command),b=b&&b.create.apply(this,c.args);this.instances[a]=b;f&&f.uiItems.push(b);if(b&&!b.type)b.type=c.type;return b},addHandler:function(a,c){this._.handlers[a]=
c},space:function(a){return CKEDITOR.document.getById(this.spaceId(a))},spaceId:function(a){return this.editor.id+"_"+a}};CKEDITOR.event.implementOn(CKEDITOR.ui);
(function(){function a(a,e,f){CKEDITOR.event.call(this);a=a&&CKEDITOR.tools.clone(a);if(e!==void 0){if(e instanceof CKEDITOR.dom.element){if(!f)throw Error("One of the element modes must be specified.");}else throw Error("Expect element of type CKEDITOR.dom.element.");if(CKEDITOR.env.ie&&CKEDITOR.env.quirks&&f==CKEDITOR.ELEMENT_MODE_INLINE)throw Error("Inline element mode is not supported on IE quirks.");if(!(f==CKEDITOR.ELEMENT_MODE_INLINE?e.is(CKEDITOR.dtd.$editable)||e.is("textarea"):f==CKEDITOR.ELEMENT_MODE_REPLACE?
!e.is(CKEDITOR.dtd.$nonBodyContent):1))throw Error('The specified element mode is not supported on element: "'+e.getName()+'".');this.element=e;this.elementMode=f;this.name=this.elementMode!=CKEDITOR.ELEMENT_MODE_APPENDTO&&(e.getId()||e.getNameAtt())}else this.elementMode=CKEDITOR.ELEMENT_MODE_NONE;this._={};this.commands={};this.templates={};this.name=this.name||c();this.id=CKEDITOR.tools.getNextId();this.status="unloaded";this.config=CKEDITOR.tools.prototypedCopy(CKEDITOR.config);this.ui=new CKEDITOR.ui(this);
this.focusManager=new CKEDITOR.focusManager(this);this.keystrokeHandler=new CKEDITOR.keystrokeHandler(this);this.on("readOnly",b);this.on("selectionChange",function(a){d(this,a.data.path)});this.on("activeFilterChange",function(){d(this,this.elementPath(),true)});this.on("mode",b);this.on("instanceReady",function(){this.config.startupFocus&&this.focus()});CKEDITOR.fire("instanceCreated",null,this);CKEDITOR.add(this);CKEDITOR.tools.setTimeout(function(){g(this,a)},0,this)}function c(){do var a="editor"+
++s;while(CKEDITOR.instances[a]);return a}function b(){var a=this.commands,b;for(b in a)f(this,a[b])}function f(a,b){b[b.startDisabled?"disable":a.readOnly&&!b.readOnly?"disable":b.modes[a.mode]?"enable":"disable"]()}function d(a,b,d){if(b){var c,e,f=a.commands;for(e in f){c=f[e];(d||c.contextSensitive)&&c.refresh(a,b)}}}function e(a){var b=a.config.customConfig;if(!b)return false;var b=CKEDITOR.getUrl(b),d=x[b]||(x[b]={});if(d.fn){d.fn.call(a,a.config);(CKEDITOR.getUrl(a.config.customConfig)==b||
!e(a))&&a.fireOnce("customConfigLoaded")}else CKEDITOR.scriptLoader.queue(b,function(){d.fn=CKEDITOR.editorConfig?CKEDITOR.editorConfig:function(){};e(a)});return true}function g(a,b){a.on("customConfigLoaded",function(){if(b){if(b.on)for(var d in b.on)a.on(d,b.on[d]);CKEDITOR.tools.extend(a.config,b,true);delete a.config.on}d=a.config;a.readOnly=!(!d.readOnly&&!(a.elementMode==CKEDITOR.ELEMENT_MODE_INLINE?a.element.is("textarea")?a.element.hasAttribute("disabled"):a.element.isReadOnly():a.elementMode==
CKEDITOR.ELEMENT_MODE_REPLACE&&a.element.hasAttribute("disabled")));a.blockless=a.elementMode==CKEDITOR.ELEMENT_MODE_INLINE?!(a.element.is("textarea")||CKEDITOR.dtd[a.element.getName()].p):false;a.tabIndex=d.tabIndex||a.element&&a.element.getAttribute("tabindex")||0;a.activeEnterMode=a.enterMode=a.blockless?CKEDITOR.ENTER_BR:d.enterMode;a.activeShiftEnterMode=a.shiftEnterMode=a.blockless?CKEDITOR.ENTER_BR:d.shiftEnterMode;if(d.skin)CKEDITOR.skinName=d.skin;a.fireOnce("configLoaded");a.dataProcessor=
new CKEDITOR.htmlDataProcessor(a);a.filter=a.activeFilter=new CKEDITOR.filter(a);n(a)});if(b&&b.customConfig!=void 0)a.config.customConfig=b.customConfig;e(a)||a.fireOnce("customConfigLoaded")}function n(a){CKEDITOR.skin.loadPart("editor",function(){h(a)})}function h(a){CKEDITOR.lang.load(a.config.language,a.config.defaultLanguage,function(b,d){var c=a.config.title;a.langCode=b;a.lang=CKEDITOR.tools.prototypedCopy(d);a.title=typeof c=="string"||c===false?c:[a.lang.editor,a.name].join(", ");if(!a.config.contentsLangDirection)a.config.contentsLangDirection=
a.elementMode==CKEDITOR.ELEMENT_MODE_INLINE?a.element.getDirection(1):a.lang.dir;a.fire("langLoaded");i(a)})}function i(a){a.getStylesSet(function(b){a.once("loaded",function(){a.fire("stylesSet",{styles:b})},null,null,1);m(a)})}function m(a){var b=a.config,d=b.plugins,c=b.extraPlugins,e=b.removePlugins;if(c)var f=RegExp("(?:^|,)(?:"+c.replace(/\s*,\s*/g,"|")+")(?=,|$)","g"),d=d.replace(f,""),d=d+(","+c);if(e)var j=RegExp("(?:^|,)(?:"+e.replace(/\s*,\s*/g,"|")+")(?=,|$)","g"),d=d.replace(j,"");CKEDITOR.env.air&&
(d=d+",adobeair");CKEDITOR.plugins.load(d.split(","),function(d){var c=[],e=[],f=[];a.plugins=d;for(var k in d){var l=d[k],g=l.lang,h=null,u=l.requires,w;CKEDITOR.tools.isArray(u)&&(u=u.join(","));if(u&&(w=u.match(j)))for(;u=w.pop();)CKEDITOR.tools.setTimeout(function(a,b){throw Error('Plugin "'+a.replace(",","")+'" cannot be removed from the plugins list, because it\'s required by "'+b+'" plugin.');},0,null,[u,k]);if(g&&!a.lang[k]){g.split&&(g=g.split(","));if(CKEDITOR.tools.indexOf(g,a.langCode)>=
0)h=a.langCode;else{h=a.langCode.replace(/-.*/,"");h=h!=a.langCode&&CKEDITOR.tools.indexOf(g,h)>=0?h:CKEDITOR.tools.indexOf(g,"en")>=0?"en":g[0]}if(!l.langEntries||!l.langEntries[h])f.push(CKEDITOR.getUrl(l.path+"lang/"+h+".js"));else{a.lang[k]=l.langEntries[h];h=null}}e.push(h);c.push(l)}CKEDITOR.scriptLoader.load(f,function(){for(var d=["beforeInit","init","afterInit"],f=0;f<d.length;f++)for(var j=0;j<c.length;j++){var k=c[j];f===0&&(e[j]&&k.lang&&k.langEntries)&&(a.lang[k.name]=k.langEntries[e[j]]);
if(k[d[f]])k[d[f]](a)}a.fireOnce("pluginsLoaded");b.keystrokes&&a.setKeystroke(a.config.keystrokes);for(j=0;j<a.config.blockedKeystrokes.length;j++)a.keystrokeHandler.blockedKeystrokes[a.config.blockedKeystrokes[j]]=1;a.status="loaded";a.fireOnce("loaded");CKEDITOR.fire("instanceLoaded",null,a)})})}function p(){var a=this.element;if(a&&this.elementMode!=CKEDITOR.ELEMENT_MODE_APPENDTO){var b=this.getData();this.config.htmlEncodeOutput&&(b=CKEDITOR.tools.htmlEncode(b));a.is("textarea")?a.setValue(b):
a.setHtml(b);return true}return false}a.prototype=CKEDITOR.editor.prototype;CKEDITOR.editor=a;var s=0,x={};CKEDITOR.tools.extend(CKEDITOR.editor.prototype,{addCommand:function(a,b){b.name=a.toLowerCase();var d=new CKEDITOR.command(this,b);this.mode&&f(this,d);return this.commands[a]=d},_attachToForm:function(){var a=this,b=a.element,d=new CKEDITOR.dom.element(b.$.form);if(b.is("textarea")&&d){var c=function(d){a.updateElement();a._.required&&(!b.getValue()&&a.fire("required")===false)&&d.data.preventDefault()};
d.on("submit",c);if(d.$.submit&&d.$.submit.call&&d.$.submit.apply)d.$.submit=CKEDITOR.tools.override(d.$.submit,function(a){return function(){c();a.apply?a.apply(this):a()}});a.on("destroy",function(){d.removeListener("submit",c)})}},destroy:function(a){this.fire("beforeDestroy");!a&&p.call(this);this.editable(null);this.status="destroyed";this.fire("destroy");this.removeAllListeners();CKEDITOR.remove(this);CKEDITOR.fire("instanceDestroyed",null,this)},elementPath:function(a){if(!a){a=this.getSelection();
if(!a)return null;a=a.getStartElement()}return a?new CKEDITOR.dom.elementPath(a,this.editable()):null},createRange:function(){var a=this.editable();return a?new CKEDITOR.dom.range(a):null},execCommand:function(a,b){var d=this.getCommand(a),c={name:a,commandData:b,command:d};if(d&&d.state!=CKEDITOR.TRISTATE_DISABLED&&this.fire("beforeCommandExec",c)!==false){c.returnValue=d.exec(c.commandData);if(!d.async&&this.fire("afterCommandExec",c)!==false)return c.returnValue}return false},getCommand:function(a){return this.commands[a]},
getData:function(a){!a&&this.fire("beforeGetData");var b=this._.data;if(typeof b!="string")b=(b=this.element)&&this.elementMode==CKEDITOR.ELEMENT_MODE_REPLACE?b.is("textarea")?b.getValue():b.getHtml():"";b={dataValue:b};!a&&this.fire("getData",b);return b.dataValue},getSnapshot:function(){var a=this.fire("getSnapshot");if(typeof a!="string"){var b=this.element;b&&this.elementMode==CKEDITOR.ELEMENT_MODE_REPLACE&&(a=b.is("textarea")?b.getValue():b.getHtml())}return a},loadSnapshot:function(a){this.fire("loadSnapshot",
a)},setData:function(a,b,d){var c=true,e=b;if(b&&typeof b=="object"){d=b.internal;e=b.callback;c=!b.noSnapshot}!d&&c&&this.fire("saveSnapshot");if(e||!d)this.once("dataReady",function(a){!d&&c&&this.fire("saveSnapshot");e&&e.call(a.editor)});a={dataValue:a};!d&&this.fire("setData",a);this._.data=a.dataValue;!d&&this.fire("afterSetData",a)},setReadOnly:function(a){a=a==void 0||a;if(this.readOnly!=a){this.readOnly=a;this.keystrokeHandler.blockedKeystrokes[8]=+a;this.editable().setReadOnly(a);this.fire("readOnly")}},
insertHtml:function(a,b){this.fire("insertHtml",{dataValue:a,mode:b})},insertText:function(a){this.fire("insertText",a)},insertElement:function(a){this.fire("insertElement",a)},focus:function(){this.fire("beforeFocus")},checkDirty:function(){return this.status=="ready"&&this._.previousValue!==this.getSnapshot()},resetDirty:function(){this._.previousValue=this.getSnapshot()},updateElement:function(){return p.call(this)},setKeystroke:function(){for(var a=this.keystrokeHandler.keystrokes,b=CKEDITOR.tools.isArray(arguments[0])?
arguments[0]:[[].slice.call(arguments,0)],d,c,e=b.length;e--;){d=b[e];c=0;if(CKEDITOR.tools.isArray(d)){c=d[1];d=d[0]}c?a[d]=c:delete a[d]}},addFeature:function(a){return this.filter.addFeature(a)},setActiveFilter:function(a){if(!a)a=this.filter;if(this.activeFilter!==a){this.activeFilter=a;this.fire("activeFilterChange");a===this.filter?this.setActiveEnterMode(null,null):this.setActiveEnterMode(a.getAllowedEnterMode(this.enterMode),a.getAllowedEnterMode(this.shiftEnterMode,true))}},setActiveEnterMode:function(a,
b){a=a?this.blockless?CKEDITOR.ENTER_BR:a:this.enterMode;b=b?this.blockless?CKEDITOR.ENTER_BR:b:this.shiftEnterMode;if(this.activeEnterMode!=a||this.activeShiftEnterMode!=b){this.activeEnterMode=a;this.activeShiftEnterMode=b;this.fire("activeEnterModeChange")}}})})();CKEDITOR.ELEMENT_MODE_NONE=0;CKEDITOR.ELEMENT_MODE_REPLACE=1;CKEDITOR.ELEMENT_MODE_APPENDTO=2;CKEDITOR.ELEMENT_MODE_INLINE=3;
CKEDITOR.htmlParser=function(){this._={htmlPartsRegex:RegExp("<(?:(?:\\/([^>]+)>)|(?:!--([\\S|\\s]*?)--\>)|(?:([^\\s>]+)\\s*((?:(?:\"[^\"]*\")|(?:'[^']*')|[^\"'>])*)\\/?>))","g")}};
(function(){var a=/([\w\-:.]+)(?:(?:\s*=\s*(?:(?:"([^"]*)")|(?:'([^']*)')|([^\s>]+)))|(?=\s|$))/g,c={checked:1,compact:1,declare:1,defer:1,disabled:1,ismap:1,multiple:1,nohref:1,noresize:1,noshade:1,nowrap:1,readonly:1,selected:1};CKEDITOR.htmlParser.prototype={onTagOpen:function(){},onTagClose:function(){},onText:function(){},onCDATA:function(){},onComment:function(){},parse:function(b){for(var f,d,e=0,g;f=this._.htmlPartsRegex.exec(b);){d=f.index;if(d>e){e=b.substring(e,d);if(g)g.push(e);else this.onText(e)}e=
this._.htmlPartsRegex.lastIndex;if(d=f[1]){d=d.toLowerCase();if(g&&CKEDITOR.dtd.$cdata[d]){this.onCDATA(g.join(""));g=null}if(!g){this.onTagClose(d);continue}}if(g)g.push(f[0]);else if(d=f[3]){d=d.toLowerCase();if(!/="/.test(d)){var n={},h;f=f[4];var i=!!(f&&f.charAt(f.length-1)=="/");if(f)for(;h=a.exec(f);){var m=h[1].toLowerCase();h=h[2]||h[3]||h[4]||"";n[m]=!h&&c[m]?m:CKEDITOR.tools.htmlDecodeAttr(h)}this.onTagOpen(d,n,i);!g&&CKEDITOR.dtd.$cdata[d]&&(g=[])}}else if(d=f[2])this.onComment(d)}if(b.length>
e)this.onText(b.substring(e,b.length))}}})();
CKEDITOR.htmlParser.basicWriter=CKEDITOR.tools.createClass({$:function(){this._={output:[]}},proto:{openTag:function(a){this._.output.push("<",a)},openTagClose:function(a,c){c?this._.output.push(" />"):this._.output.push(">")},attribute:function(a,c){typeof c=="string"&&(c=CKEDITOR.tools.htmlEncodeAttr(c));this._.output.push(" ",a,'="',c,'"')},closeTag:function(a){this._.output.push("</",a,">")},text:function(a){this._.output.push(a)},comment:function(a){this._.output.push("<\!--",a,"--\>")},write:function(a){this._.output.push(a)},
reset:function(){this._.output=[];this._.indent=false},getHtml:function(a){var c=this._.output.join("");a&&this.reset();return c}}});"use strict";
(function(){CKEDITOR.htmlParser.node=function(){};CKEDITOR.htmlParser.node.prototype={remove:function(){var a=this.parent.children,c=CKEDITOR.tools.indexOf(a,this),b=this.previous,f=this.next;b&&(b.next=f);f&&(f.previous=b);a.splice(c,1);this.parent=null},replaceWith:function(a){var c=this.parent.children,b=CKEDITOR.tools.indexOf(c,this),f=a.previous=this.previous,d=a.next=this.next;f&&(f.next=a);d&&(d.previous=a);c[b]=a;a.parent=this.parent;this.parent=null},insertAfter:function(a){var c=a.parent.children,
b=CKEDITOR.tools.indexOf(c,a),f=a.next;c.splice(b+1,0,this);this.next=a.next;this.previous=a;a.next=this;f&&(f.previous=this);this.parent=a.parent},insertBefore:function(a){var c=a.parent.children,b=CKEDITOR.tools.indexOf(c,a);c.splice(b,0,this);this.next=a;(this.previous=a.previous)&&(a.previous.next=this);a.previous=this;this.parent=a.parent},getAscendant:function(a){var c=typeof a=="function"?a:typeof a=="string"?function(b){return b.name==a}:function(b){return b.name in a},b=this.parent;for(;b&&
b.type==CKEDITOR.NODE_ELEMENT;){if(c(b))return b;b=b.parent}return null},wrapWith:function(a){this.replaceWith(a);a.add(this);return a},getIndex:function(){return CKEDITOR.tools.indexOf(this.parent.children,this)},getFilterContext:function(a){return a||{}}}})();"use strict";CKEDITOR.htmlParser.comment=function(a){this.value=a;this._={isBlockLike:false}};
CKEDITOR.htmlParser.comment.prototype=CKEDITOR.tools.extend(new CKEDITOR.htmlParser.node,{type:CKEDITOR.NODE_COMMENT,filter:function(a,c){var b=this.value;if(!(b=a.onComment(c,b,this))){this.remove();return false}if(typeof b!="string"){this.replaceWith(b);return false}this.value=b;return true},writeHtml:function(a,c){c&&this.filter(c);a.comment(this.value)}});"use strict";
(function(){CKEDITOR.htmlParser.text=function(a){this.value=a;this._={isBlockLike:false}};CKEDITOR.htmlParser.text.prototype=CKEDITOR.tools.extend(new CKEDITOR.htmlParser.node,{type:CKEDITOR.NODE_TEXT,filter:function(a,c){if(!(this.value=a.onText(c,this.value,this))){this.remove();return false}},writeHtml:function(a,c){c&&this.filter(c);a.text(this.value)}})})();"use strict";
(function(){CKEDITOR.htmlParser.cdata=function(a){this.value=a};CKEDITOR.htmlParser.cdata.prototype=CKEDITOR.tools.extend(new CKEDITOR.htmlParser.node,{type:CKEDITOR.NODE_TEXT,filter:function(){},writeHtml:function(a){a.write(this.value)}})})();"use strict";CKEDITOR.htmlParser.fragment=function(){this.children=[];this.parent=null;this._={isBlockLike:true,hasInlineStarted:false}};
(function(){function a(a){return a.attributes["data-cke-survive"]?false:a.name=="a"&&a.attributes.href||CKEDITOR.dtd.$removeEmpty[a.name]}var c=CKEDITOR.tools.extend({table:1,ul:1,ol:1,dl:1},CKEDITOR.dtd.table,CKEDITOR.dtd.ul,CKEDITOR.dtd.ol,CKEDITOR.dtd.dl),b={ol:1,ul:1},f=CKEDITOR.tools.extend({},{html:1},CKEDITOR.dtd.html,CKEDITOR.dtd.body,CKEDITOR.dtd.head,{style:1,script:1}),d={ul:"li",ol:"li",dl:"dd",table:"tbody",tbody:"tr",thead:"tr",tfoot:"tr",tr:"td"};CKEDITOR.htmlParser.fragment.fromHtml=
function(e,g,n){function h(a){var b;if(u.length>0)for(var d=0;d<u.length;d++){var c=u[d],e=c.name,f=CKEDITOR.dtd[e],j=k.name&&CKEDITOR.dtd[k.name];if((!j||j[e])&&(!a||!f||f[a]||!CKEDITOR.dtd[a])){if(!b){i();b=1}c=c.clone();c.parent=k;k=c;u.splice(d,1);d--}else if(e==k.name){p(k,k.parent,1);d--}}}function i(){for(;A.length;)p(A.shift(),k)}function m(a){if(a._.isBlockLike&&a.name!="pre"&&a.name!="textarea"){var b=a.children.length,d=a.children[b-1],c;if(d&&d.type==CKEDITOR.NODE_TEXT)(c=CKEDITOR.tools.rtrim(d.value))?
d.value=c:a.children.length=b-1}}function p(b,d,c){var d=d||k||o,e=k;if(b.previous===void 0){if(s(d,b)){k=d;q.onTagOpen(n,{});b.returnPoint=d=k}m(b);(!a(b)||b.children.length)&&d.add(b);b.name=="pre"&&(j=false);b.name=="textarea"&&(l=false)}if(b.returnPoint){k=b.returnPoint;delete b.returnPoint}else k=c?d:e}function s(a,b){if((a==o||a.name=="body")&&n&&(!a.name||CKEDITOR.dtd[a.name][n])){var d,c;return(d=b.attributes&&(c=b.attributes["data-cke-real-element-type"])?c:b.name)&&d in CKEDITOR.dtd.$inline&&
!(d in CKEDITOR.dtd.head)&&!b.isOrphan||b.type==CKEDITOR.NODE_TEXT}}function x(a,b){return a in CKEDITOR.dtd.$listItem||a in CKEDITOR.dtd.$tableContent?a==b||a=="dt"&&b=="dd"||a=="dd"&&b=="dt":false}var q=new CKEDITOR.htmlParser,o=g instanceof CKEDITOR.htmlParser.element?g:typeof g=="string"?new CKEDITOR.htmlParser.element(g):new CKEDITOR.htmlParser.fragment,u=[],A=[],k=o,l=o.name=="textarea",j=o.name=="pre";q.onTagOpen=function(d,e,g,o){e=new CKEDITOR.htmlParser.element(d,e);if(e.isUnknown&&g)e.isEmpty=
true;e.isOptionalClose=o;if(a(e))u.push(e);else{if(d=="pre")j=true;else{if(d=="br"&&j){k.add(new CKEDITOR.htmlParser.text("\n"));return}d=="textarea"&&(l=true)}if(d=="br")A.push(e);else{for(;;){o=(g=k.name)?CKEDITOR.dtd[g]||(k._.isBlockLike?CKEDITOR.dtd.div:CKEDITOR.dtd.span):f;if(!e.isUnknown&&!k.isUnknown&&!o[d])if(k.isOptionalClose)q.onTagClose(g);else if(d in b&&g in b){g=k.children;(g=g[g.length-1])&&g.name=="li"||p(g=new CKEDITOR.htmlParser.element("li"),k);!e.returnPoint&&(e.returnPoint=k);
k=g}else if(d in CKEDITOR.dtd.$listItem&&!x(d,g))q.onTagOpen(d=="li"?"ul":"dl",{},0,1);else if(g in c&&!x(d,g)){!e.returnPoint&&(e.returnPoint=k);k=k.parent}else{g in CKEDITOR.dtd.$inline&&u.unshift(k);if(k.parent)p(k,k.parent,1);else{e.isOrphan=1;break}}else break}h(d);i();e.parent=k;e.isEmpty?p(e):k=e}}};q.onTagClose=function(a){for(var b=u.length-1;b>=0;b--)if(a==u[b].name){u.splice(b,1);return}for(var d=[],c=[],e=k;e!=o&&e.name!=a;){e._.isBlockLike||c.unshift(e);d.push(e);e=e.returnPoint||e.parent}if(e!=
o){for(b=0;b<d.length;b++){var f=d[b];p(f,f.parent)}k=e;e._.isBlockLike&&i();p(e,e.parent);if(e==k)k=k.parent;u=u.concat(c)}a=="body"&&(n=false)};q.onText=function(a){if((!k._.hasInlineStarted||A.length)&&!j&&!l){a=CKEDITOR.tools.ltrim(a);if(a.length===0)return}var b=k.name,e=b?CKEDITOR.dtd[b]||(k._.isBlockLike?CKEDITOR.dtd.div:CKEDITOR.dtd.span):f;if(!l&&!e["#"]&&b in c){q.onTagOpen(d[b]||"");q.onText(a)}else{i();h();!j&&!l&&(a=a.replace(/[\t\r\n ]{2,}|[\t\r\n]/g," "));a=new CKEDITOR.htmlParser.text(a);
if(s(k,a))this.onTagOpen(n,{},0,1);k.add(a)}};q.onCDATA=function(a){k.add(new CKEDITOR.htmlParser.cdata(a))};q.onComment=function(a){i();h();k.add(new CKEDITOR.htmlParser.comment(a))};q.parse(e);for(i();k!=o;)p(k,k.parent,1);m(o);return o};CKEDITOR.htmlParser.fragment.prototype={type:CKEDITOR.NODE_DOCUMENT_FRAGMENT,add:function(a,b){isNaN(b)&&(b=this.children.length);var d=b>0?this.children[b-1]:null;if(d){if(a._.isBlockLike&&d.type==CKEDITOR.NODE_TEXT){d.value=CKEDITOR.tools.rtrim(d.value);if(d.value.length===
0){this.children.pop();this.add(a);return}}d.next=a}a.previous=d;a.parent=this;this.children.splice(b,0,a);if(!this._.hasInlineStarted)this._.hasInlineStarted=a.type==CKEDITOR.NODE_TEXT||a.type==CKEDITOR.NODE_ELEMENT&&!a._.isBlockLike},filter:function(a,b){b=this.getFilterContext(b);a.onRoot(b,this);this.filterChildren(a,false,b)},filterChildren:function(a,b,d){if(this.childrenFilteredBy!=a.id){d=this.getFilterContext(d);if(b&&!this.parent)a.onRoot(d,this);this.childrenFilteredBy=a.id;for(b=0;b<this.children.length;b++)this.children[b].filter(a,
d)===false&&b--}},writeHtml:function(a,b){b&&this.filter(b);this.writeChildrenHtml(a)},writeChildrenHtml:function(a,b,d){var c=this.getFilterContext();if(d&&!this.parent&&b)b.onRoot(c,this);b&&this.filterChildren(b,false,c);b=0;d=this.children;for(c=d.length;b<c;b++)d[b].writeHtml(a)},forEach:function(a,b,d){if(!d&&(!b||this.type==b))var c=a(this);if(c!==false)for(var d=this.children,f=0;f<d.length;f++){c=d[f];c.type==CKEDITOR.NODE_ELEMENT?c.forEach(a,b):(!b||c.type==b)&&a(c)}},getFilterContext:function(a){return a||
{}}}})();"use strict";
(function(){function a(){this.rules=[]}function c(b,c,d,e){var g,n;for(g in c){(n=b[g])||(n=b[g]=new a);n.add(c[g],d,e)}}CKEDITOR.htmlParser.filter=CKEDITOR.tools.createClass({$:function(b){this.id=CKEDITOR.tools.getNextNumber();this.elementNameRules=new a;this.attributeNameRules=new a;this.elementsRules={};this.attributesRules={};this.textRules=new a;this.commentRules=new a;this.rootRules=new a;b&&this.addRules(b,10)},proto:{addRules:function(a,f){var d;if(typeof f=="number")d=f;else if(f&&"priority"in
f)d=f.priority;typeof d!="number"&&(d=10);typeof f!="object"&&(f={});a.elementNames&&this.elementNameRules.addMany(a.elementNames,d,f);a.attributeNames&&this.attributeNameRules.addMany(a.attributeNames,d,f);a.elements&&c(this.elementsRules,a.elements,d,f);a.attributes&&c(this.attributesRules,a.attributes,d,f);a.text&&this.textRules.add(a.text,d,f);a.comment&&this.commentRules.add(a.comment,d,f);a.root&&this.rootRules.add(a.root,d,f)},applyTo:function(a){a.filter(this)},onElementName:function(a,c){return this.elementNameRules.execOnName(a,
c)},onAttributeName:function(a,c){return this.attributeNameRules.execOnName(a,c)},onText:function(a,c,d){return this.textRules.exec(a,c,d)},onComment:function(a,c,d){return this.commentRules.exec(a,c,d)},onRoot:function(a,c){return this.rootRules.exec(a,c)},onElement:function(a,c){for(var d=[this.elementsRules["^"],this.elementsRules[c.name],this.elementsRules.$],e,g=0;g<3;g++)if(e=d[g]){e=e.exec(a,c,this);if(e===false)return null;if(e&&e!=c)return this.onNode(a,e);if(c.parent&&!c.name)break}return c},
onNode:function(a,c){var d=c.type;return d==CKEDITOR.NODE_ELEMENT?this.onElement(a,c):d==CKEDITOR.NODE_TEXT?new CKEDITOR.htmlParser.text(this.onText(a,c.value)):d==CKEDITOR.NODE_COMMENT?new CKEDITOR.htmlParser.comment(this.onComment(a,c.value)):null},onAttribute:function(a,c,d,e){return(d=this.attributesRules[d])?d.exec(a,e,c,this):e}}});CKEDITOR.htmlParser.filterRulesGroup=a;a.prototype={add:function(a,c,d){this.rules.splice(this.findIndex(c),0,{value:a,priority:c,options:d})},addMany:function(a,
c,d){for(var e=[this.findIndex(c),0],g=0,n=a.length;g<n;g++)e.push({value:a[g],priority:c,options:d});this.rules.splice.apply(this.rules,e)},findIndex:function(a){for(var c=this.rules,d=c.length-1;d>=0&&a<c[d].priority;)d--;return d+1},exec:function(a,c){var d=c instanceof CKEDITOR.htmlParser.node||c instanceof CKEDITOR.htmlParser.fragment,e=Array.prototype.slice.call(arguments,1),g=this.rules,n=g.length,h,i,m,p;for(p=0;p<n;p++){if(d){h=c.type;i=c.name}m=g[p];if(!(a.nonEditable&&!m.options.applyToAll||
a.nestedEditable&&m.options.excludeNestedEditable)){m=m.value.apply(null,e);if(m===false||d&&m&&(m.name!=i||m.type!=h))return m;m!=void 0&&(e[0]=c=m)}}return c},execOnName:function(a,c){for(var d=0,e=this.rules,g=e.length,n;c&&d<g;d++){n=e[d];!(a.nonEditable&&!n.options.applyToAll||a.nestedEditable&&n.options.excludeNestedEditable)&&(c=c.replace(n.value[0],n.value[1]))}return c}}})();
(function(){function a(a,c){function l(a){return a||CKEDITOR.env.needsNbspFiller?new CKEDITOR.htmlParser.text(" "):new CKEDITOR.htmlParser.element("br",{"data-cke-bogus":1})}function o(a,d){return function(c){if(c.type!=CKEDITOR.NODE_DOCUMENT_FRAGMENT){var j=[],k=b(c),o,g;if(k)for(r(k,1)&&j.push(k);k;){if(e(k)&&(o=f(k))&&r(o))if((g=f(o))&&!e(g))j.push(o);else{l(v).insertAfter(o);o.remove()}k=k.previous}for(k=0;k<j.length;k++)j[k].remove();if(j=typeof d=="function"?d(c)!==false:d)if(!v&&!CKEDITOR.env.needsBrFiller&&
c.type==CKEDITOR.NODE_DOCUMENT_FRAGMENT)j=false;else if(!v&&!CKEDITOR.env.needsBrFiller&&(document.documentMode>7||c.name in CKEDITOR.dtd.tr||c.name in CKEDITOR.dtd.$listItem))j=false;else{j=b(c);j=!j||c.name=="form"&&j.name=="input"}j&&c.add(l(a))}}}function r(a,b){if((!v||CKEDITOR.env.needsBrFiller)&&a.type==CKEDITOR.NODE_ELEMENT&&a.name=="br"&&!a.attributes["data-cke-eol"])return true;var d;if(a.type==CKEDITOR.NODE_TEXT&&(d=a.value.match(u))){if(d.index){(new CKEDITOR.htmlParser.text(a.value.substring(0,
d.index))).insertBefore(a);a.value=d[0]}if(!CKEDITOR.env.needsBrFiller&&v&&(!b||a.parent.name in h))return true;if(!v)if((d=a.previous)&&d.name=="br"||!d||e(d))return true}return false}var w={elements:{}},v=c=="html",h=CKEDITOR.tools.extend({},j),t;for(t in h)"#"in k[t]||delete h[t];for(t in h)w.elements[t]=o(v,a.config.fillEmptyBlocks!==false);w.root=o(v);w.elements.br=function(a){return function(b){if(b.parent.type!=CKEDITOR.NODE_DOCUMENT_FRAGMENT){var c=b.attributes;if("data-cke-bogus"in c||"data-cke-eol"in
c)delete c["data-cke-bogus"];else{for(c=b.next;c&&d(c);)c=c.next;var j=f(b);!c&&e(b.parent)?g(b.parent,l(a)):e(c)&&(j&&!e(j))&&l(a).insertBefore(c)}}}}(v);return w}function c(a,b){return a!=CKEDITOR.ENTER_BR&&b!==false?a==CKEDITOR.ENTER_DIV?"div":"p":false}function b(a){for(a=a.children[a.children.length-1];a&&d(a);)a=a.previous;return a}function f(a){for(a=a.previous;a&&d(a);)a=a.previous;return a}function d(a){return a.type==CKEDITOR.NODE_TEXT&&!CKEDITOR.tools.trim(a.value)||a.type==CKEDITOR.NODE_ELEMENT&&
a.attributes["data-cke-bookmark"]}function e(a){return a&&(a.type==CKEDITOR.NODE_ELEMENT&&a.name in j||a.type==CKEDITOR.NODE_DOCUMENT_FRAGMENT)}function g(a,b){var d=a.children[a.children.length-1];a.children.push(b);b.parent=a;if(d){d.next=b;b.previous=d}}function n(a){a=a.attributes;a.contenteditable!="false"&&(a["data-cke-editable"]=a.contenteditable?"true":1);a.contenteditable="false"}function h(a){a=a.attributes;switch(a["data-cke-editable"]){case "true":a.contenteditable="true";break;case "1":delete a.contenteditable}}
function i(a){return a.replace(S,function(a,b,d){return"<"+b+d.replace(F,function(a,b){return D.test(b)&&d.indexOf("data-cke-saved-"+b)==-1?" data-cke-saved-"+a+" data-cke-"+CKEDITOR.rnd+"-"+a:a})+">"})}function m(a,b){return a.replace(b,function(a,b,d){a.indexOf("<textarea")===0&&(a=b+x(d).replace(/</g,"&lt;").replace(/>/g,"&gt;")+"</textarea>");return"<cke:encoded>"+encodeURIComponent(a)+"</cke:encoded>"})}function p(a){return a.replace(w,function(a,b){return decodeURIComponent(b)})}function s(a){return a.replace(/<\!--(?!{cke_protected})[\s\S]+?--\>/g,
function(a){return"<\!--"+A+"{C}"+encodeURIComponent(a).replace(/--/g,"%2D%2D")+"--\>"})}function x(a){return a.replace(/<\!--\{cke_protected\}\{C\}([\s\S]+?)--\>/g,function(a,b){return decodeURIComponent(b)})}function q(a,b){var d=b._.dataStore;return a.replace(/<\!--\{cke_protected\}([\s\S]+?)--\>/g,function(a,b){return decodeURIComponent(b)}).replace(/\{cke_protected_(\d+)\}/g,function(a,b){return d&&d[b]||""})}function o(a,b){for(var d=[],c=b.config.protectedSource,e=b._.dataStore||(b._.dataStore=
{id:1}),f=/<\!--\{cke_temp(comment)?\}(\d*?)--\>/g,c=[/<script[\s\S]*?<\/script>/gi,/<noscript[\s\S]*?<\/noscript>/gi].concat(c),a=a.replace(/<\!--[\s\S]*?--\>/g,function(a){return"<\!--{cke_tempcomment}"+(d.push(a)-1)+"--\>"}),j=0;j<c.length;j++)a=a.replace(c[j],function(a){a=a.replace(f,function(a,b,c){return d[c]});return/cke_temp(comment)?/.test(a)?a:"<\!--{cke_temp}"+(d.push(a)-1)+"--\>"});a=a.replace(f,function(a,b,c){return"<\!--"+A+(b?"{C}":"")+encodeURIComponent(d[c]).replace(/--/g,"%2D%2D")+
"--\>"});a=a.replace(/<\w+(?:\s+(?:(?:[^\s=>]+\s*=\s*(?:[^'"\s>]+|'[^']*'|"[^"]*"))|[^\s=>]+))+\s*>/g,function(a){return a.replace(/<\!--\{cke_protected\}([^>]*)--\>/g,function(a,b){e[e.id]=decodeURIComponent(b);return"{cke_protected_"+e.id++ +"}"})});return a=a.replace(/<(title|iframe|textarea)([^>]*)>([\s\S]*?)<\/\1>/g,function(a,d,c,e){return"<"+d+c+">"+q(x(e),b)+"</"+d+">"})}CKEDITOR.htmlDataProcessor=function(b){var d,e,f=this;this.editor=b;this.dataFilter=d=new CKEDITOR.htmlParser.filter;this.htmlFilter=
e=new CKEDITOR.htmlParser.filter;this.writer=new CKEDITOR.htmlParser.basicWriter;d.addRules(v);d.addRules(I,{applyToAll:true});d.addRules(a(b,"data"),{applyToAll:true});e.addRules(r);e.addRules(O,{applyToAll:true});e.addRules(a(b,"html"),{applyToAll:true});b.on("toHtml",function(a){var a=a.data,d=a.dataValue,d=o(d,b),d=m(d,J),d=i(d),d=m(d,L),d=d.replace(z,"$1cke:$2"),d=d.replace(E,"<cke:$1$2></cke:$1>"),d=d.replace(/(<pre\b[^>]*>)(\r\n|\n)/g,"$1$2$2"),d=d.replace(/([^a-z0-9<\-])(on\w{3,})(?!>)/gi,
"$1data-cke-"+CKEDITOR.rnd+"-$2"),e=a.context||b.editable().getName(),f;if(CKEDITOR.env.ie&&CKEDITOR.env.version<9&&e=="pre"){e="div";d="<pre>"+d+"</pre>";f=1}e=b.document.createElement(e);e.setHtml("a"+d);d=e.getHtml().substr(1);d=d.replace(RegExp("data-cke-"+CKEDITOR.rnd+"-","ig"),"");f&&(d=d.replace(/^<pre>|<\/pre>$/gi,""));d=d.replace(t,"$1$2");d=p(d);d=x(d);a.dataValue=CKEDITOR.htmlParser.fragment.fromHtml(d,a.context,a.fixForBody===false?false:c(a.enterMode,b.config.autoParagraph))},null,null,
5);b.on("toHtml",function(a){a.data.filter.applyTo(a.data.dataValue,true,a.data.dontFilter,a.data.enterMode)&&b.fire("dataFiltered")},null,null,6);b.on("toHtml",function(a){a.data.dataValue.filterChildren(f.dataFilter,true)},null,null,10);b.on("toHtml",function(a){var a=a.data,b=a.dataValue,d=new CKEDITOR.htmlParser.basicWriter;b.writeChildrenHtml(d);b=d.getHtml(true);a.dataValue=s(b)},null,null,15);b.on("toDataFormat",function(a){var d=a.data.dataValue;a.data.enterMode!=CKEDITOR.ENTER_BR&&(d=d.replace(/^<br *\/?>/i,
""));a.data.dataValue=CKEDITOR.htmlParser.fragment.fromHtml(d,a.data.context,c(a.data.enterMode,b.config.autoParagraph))},null,null,5);b.on("toDataFormat",function(a){a.data.dataValue.filterChildren(f.htmlFilter,true)},null,null,10);b.on("toDataFormat",function(a){a.data.filter.applyTo(a.data.dataValue,false,true)},null,null,11);b.on("toDataFormat",function(a){var d=a.data.dataValue,c=f.writer;c.reset();d.writeChildrenHtml(c);d=c.getHtml(true);d=x(d);d=q(d,b);a.data.dataValue=d},null,null,15)};CKEDITOR.htmlDataProcessor.prototype=
{toHtml:function(a,b,d,c){var e=this.editor,f,j,k;if(b&&typeof b=="object"){f=b.context;d=b.fixForBody;c=b.dontFilter;j=b.filter;k=b.enterMode}else f=b;!f&&f!==null&&(f=e.editable().getName());return e.fire("toHtml",{dataValue:a,context:f,fixForBody:d,dontFilter:c,filter:j||e.filter,enterMode:k||e.enterMode}).dataValue},toDataFormat:function(a,b){var d,c,e;if(b){d=b.context;c=b.filter;e=b.enterMode}!d&&d!==null&&(d=this.editor.editable().getName());return this.editor.fire("toDataFormat",{dataValue:a,
filter:c||this.editor.filter,context:d,enterMode:e||this.editor.enterMode}).dataValue}};var u=/(?:&nbsp;|\xa0)$/,A="{cke_protected}",k=CKEDITOR.dtd,l=["caption","colgroup","col","thead","tfoot","tbody"],j=CKEDITOR.tools.extend({},k.$blockLimit,k.$block),v={elements:{input:n,textarea:n}},I={attributeNames:[[/^on/,"data-cke-pa-on"],[/^data-cke-expando$/,""]]},r={elements:{embed:function(a){var b=a.parent;if(b&&b.name=="object"){var d=b.attributes.width,b=b.attributes.height;if(d)a.attributes.width=
d;if(b)a.attributes.height=b}},a:function(a){if(!a.children.length&&!a.attributes.name&&!a.attributes["data-cke-saved-name"])return false}}},O={elementNames:[[/^cke:/,""],[/^\?xml:namespace$/,""]],attributeNames:[[/^data-cke-(saved|pa)-/,""],[/^data-cke-.*/,""],["hidefocus",""]],elements:{$:function(a){var b=a.attributes;if(b){if(b["data-cke-temp"])return false;for(var d=["name","href","src"],c,e=0;e<d.length;e++){c="data-cke-saved-"+d[e];c in b&&delete b[d[e]]}}return a},table:function(a){a.children.slice(0).sort(function(a,
b){var d,c;if(a.type==CKEDITOR.NODE_ELEMENT&&b.type==a.type){d=CKEDITOR.tools.indexOf(l,a.name);c=CKEDITOR.tools.indexOf(l,b.name)}if(!(d>-1&&c>-1&&d!=c)){d=a.parent?a.getIndex():-1;c=b.parent?b.getIndex():-1}return d>c?1:-1})},param:function(a){a.children=[];a.isEmpty=true;return a},span:function(a){a.attributes["class"]=="Apple-style-span"&&delete a.name},html:function(a){delete a.attributes.contenteditable;delete a.attributes["class"]},body:function(a){delete a.attributes.spellcheck;delete a.attributes.contenteditable},
style:function(a){var b=a.children[0];if(b&&b.value)b.value=CKEDITOR.tools.trim(b.value);if(!a.attributes.type)a.attributes.type="text/css"},title:function(a){var b=a.children[0];!b&&g(a,b=new CKEDITOR.htmlParser.text);b.value=a.attributes["data-cke-title"]||""},input:h,textarea:h},attributes:{"class":function(a){return CKEDITOR.tools.ltrim(a.replace(/(?:^|\s+)cke_[^\s]*/g,""))||false}}};if(CKEDITOR.env.ie)O.attributes.style=function(a){return a.replace(/(^|;)([^\:]+)/g,function(a){return a.toLowerCase()})};
var S=/<(a|area|img|input|source)\b([^>]*)>/gi,F=/([\w-]+)\s*=\s*(?:(?:"[^"]*")|(?:'[^']*')|(?:[^ "'>]+))/gi,D=/^(href|src|name)$/i,L=/(?:<style(?=[ >])[^>]*>[\s\S]*?<\/style>)|(?:<(:?link|meta|base)[^>]*>)/gi,J=/(<textarea(?=[ >])[^>]*>)([\s\S]*?)(?:<\/textarea>)/gi,w=/<cke:encoded>([^<]*)<\/cke:encoded>/gi,z=/(<\/?)((?:object|embed|param|html|body|head|title)[^>]*>)/gi,t=/(<\/?)cke:((?:html|body|head|title)[^>]*>)/gi,E=/<cke:(param|embed)([^>]*?)\/?>(?!\s*<\/cke:\1)/gi})();"use strict";
CKEDITOR.htmlParser.element=function(a,c){this.name=a;this.attributes=c||{};this.children=[];var b=a||"",f=b.match(/^cke:(.*)/);f&&(b=f[1]);b=!(!CKEDITOR.dtd.$nonBodyContent[b]&&!CKEDITOR.dtd.$block[b]&&!CKEDITOR.dtd.$listItem[b]&&!CKEDITOR.dtd.$tableContent[b]&&!(CKEDITOR.dtd.$nonEditable[b]||b=="br"));this.isEmpty=!!CKEDITOR.dtd.$empty[a];this.isUnknown=!CKEDITOR.dtd[a];this._={isBlockLike:b,hasInlineStarted:this.isEmpty||!b}};
CKEDITOR.htmlParser.cssStyle=function(a){var c={};((a instanceof CKEDITOR.htmlParser.element?a.attributes.style:a)||"").replace(/&quot;/g,'"').replace(/\s*([^ :;]+)\s*:\s*([^;]+)\s*(?=;|$)/g,function(a,f,d){f=="font-family"&&(d=d.replace(/["']/g,""));c[f.toLowerCase()]=d});return{rules:c,populate:function(a){var c=this.toString();if(c)a instanceof CKEDITOR.dom.element?a.setAttribute("style",c):a instanceof CKEDITOR.htmlParser.element?a.attributes.style=c:a.style=c},toString:function(){var a=[],f;
for(f in c)c[f]&&a.push(f,":",c[f],";");return a.join("")}}};
(function(){function a(a){return function(b){return b.type==CKEDITOR.NODE_ELEMENT&&(typeof a=="string"?b.name==a:b.name in a)}}var c=function(a,b){a=a[0];b=b[0];return a<b?-1:a>b?1:0},b=CKEDITOR.htmlParser.fragment.prototype;CKEDITOR.htmlParser.element.prototype=CKEDITOR.tools.extend(new CKEDITOR.htmlParser.node,{type:CKEDITOR.NODE_ELEMENT,add:b.add,clone:function(){return new CKEDITOR.htmlParser.element(this.name,this.attributes)},filter:function(a,b){var c=this,g,n,b=c.getFilterContext(b);if(b.off)return true;
if(!c.parent)a.onRoot(b,c);for(;;){g=c.name;if(!(n=a.onElementName(b,g))){this.remove();return false}c.name=n;if(!(c=a.onElement(b,c))){this.remove();return false}if(c!==this){this.replaceWith(c);return false}if(c.name==g)break;if(c.type!=CKEDITOR.NODE_ELEMENT){this.replaceWith(c);return false}if(!c.name){this.replaceWithChildren();return false}}g=c.attributes;var h,i;for(h in g){i=h;for(n=g[h];;)if(i=a.onAttributeName(b,h))if(i!=h){delete g[h];h=i}else break;else{delete g[h];break}i&&((n=a.onAttribute(b,
c,i,n))===false?delete g[i]:g[i]=n)}c.isEmpty||this.filterChildren(a,false,b);return true},filterChildren:b.filterChildren,writeHtml:function(a,b){b&&this.filter(b);var e=this.name,g=[],n=this.attributes,h,i;a.openTag(e,n);for(h in n)g.push([h,n[h]]);a.sortAttributes&&g.sort(c);h=0;for(i=g.length;h<i;h++){n=g[h];a.attribute(n[0],n[1])}a.openTagClose(e,this.isEmpty);this.writeChildrenHtml(a);this.isEmpty||a.closeTag(e)},writeChildrenHtml:b.writeChildrenHtml,replaceWithChildren:function(){for(var a=
this.children,b=a.length;b;)a[--b].insertAfter(this);this.remove()},forEach:b.forEach,getFirst:function(b){if(!b)return this.children.length?this.children[0]:null;typeof b!="function"&&(b=a(b));for(var d=0,c=this.children.length;d<c;++d)if(b(this.children[d]))return this.children[d];return null},getHtml:function(){var a=new CKEDITOR.htmlParser.basicWriter;this.writeChildrenHtml(a);return a.getHtml()},setHtml:function(a){for(var a=this.children=CKEDITOR.htmlParser.fragment.fromHtml(a).children,b=0,
c=a.length;b<c;++b)a[b].parent=this},getOuterHtml:function(){var a=new CKEDITOR.htmlParser.basicWriter;this.writeHtml(a);return a.getHtml()},split:function(a){for(var b=this.children.splice(a,this.children.length-a),c=this.clone(),g=0;g<b.length;++g)b[g].parent=c;c.children=b;if(b[0])b[0].previous=null;if(a>0)this.children[a-1].next=null;this.parent.add(c,this.getIndex()+1);return c},addClass:function(a){if(!this.hasClass(a)){var b=this.attributes["class"]||"";this.attributes["class"]=b+(b?" ":"")+
a}},removeClass:function(a){var b=this.attributes["class"];if(b)(b=CKEDITOR.tools.trim(b.replace(RegExp("(?:\\s+|^)"+a+"(?:\\s+|$)")," ")))?this.attributes["class"]=b:delete this.attributes["class"]},hasClass:function(a){var b=this.attributes["class"];return!b?false:RegExp("(?:^|\\s)"+a+"(?=\\s|$)").test(b)},getFilterContext:function(a){var b=[];a||(a={off:false,nonEditable:false,nestedEditable:false});!a.off&&this.attributes["data-cke-processor"]=="off"&&b.push("off",true);!a.nonEditable&&this.attributes.contenteditable==
"false"?b.push("nonEditable",true):a.nonEditable&&(!a.nestedEditable&&this.attributes.contenteditable=="true")&&b.push("nestedEditable",true);if(b.length)for(var a=CKEDITOR.tools.copy(a),c=0;c<b.length;c=c+2)a[b[c]]=b[c+1];return a}},true)})();
(function(){var a={},c=/{([^}]+)}/g,b=/([\\'])/g,f=/\n/g,d=/\r/g;CKEDITOR.template=function(e){if(a[e])this.output=a[e];else{var g=e.replace(b,"\\$1").replace(f,"\\n").replace(d,"\\r").replace(c,function(a,b){return"',data['"+b+"']==undefined?'{"+b+"}':data['"+b+"'],'"});this.output=a[e]=Function("data","buffer","return buffer?buffer.push('"+g+"'):['"+g+"'].join('');")}}})();delete CKEDITOR.loadFullCore;CKEDITOR.instances={};CKEDITOR.document=new CKEDITOR.dom.document(document);
CKEDITOR.add=function(a){CKEDITOR.instances[a.name]=a;a.on("focus",function(){if(CKEDITOR.currentInstance!=a){CKEDITOR.currentInstance=a;CKEDITOR.fire("currentInstance")}});a.on("blur",function(){if(CKEDITOR.currentInstance==a){CKEDITOR.currentInstance=null;CKEDITOR.fire("currentInstance")}});CKEDITOR.fire("instance",null,a)};CKEDITOR.remove=function(a){delete CKEDITOR.instances[a.name]};
(function(){var a={};CKEDITOR.addTemplate=function(c,b){var f=a[c];if(f)return f;f={name:c,source:b};CKEDITOR.fire("template",f);return a[c]=new CKEDITOR.template(f.source)};CKEDITOR.getTemplate=function(c){return a[c]}})();(function(){var a=[];CKEDITOR.addCss=function(c){a.push(c)};CKEDITOR.getCss=function(){return a.join("\n")}})();CKEDITOR.on("instanceDestroyed",function(){CKEDITOR.tools.isEmpty(this.instances)&&CKEDITOR.fire("reset")});CKEDITOR.TRISTATE_ON=1;CKEDITOR.TRISTATE_OFF=2;
CKEDITOR.TRISTATE_DISABLED=0;
(function(){CKEDITOR.inline=function(a,c){if(!CKEDITOR.env.isCompatible)return null;a=CKEDITOR.dom.element.get(a);if(a.getEditor())throw'The editor instance "'+a.getEditor().name+'" is already attached to the provided element.';var b=new CKEDITOR.editor(c,a,CKEDITOR.ELEMENT_MODE_INLINE),f=a.is("textarea")?a:null;if(f){b.setData(f.getValue(),null,true);a=CKEDITOR.dom.element.createFromHtml('<div contenteditable="'+!!b.readOnly+'" class="cke_textarea_inline">'+f.getValue()+"</div>",CKEDITOR.document);
a.insertAfter(f);f.hide();f.$.form&&b._attachToForm()}else b.setData(a.getHtml(),null,true);b.on("loaded",function(){b.fire("uiReady");b.editable(a);b.container=a;b.setData(b.getData(1));b.resetDirty();b.fire("contentDom");b.mode="wysiwyg";b.fire("mode");b.status="ready";b.fireOnce("instanceReady");CKEDITOR.fire("instanceReady",null,b)},null,null,1E4);b.on("destroy",function(){if(f){b.container.clearCustomData();b.container.remove();f.show()}b.element.clearCustomData();delete b.element});return b};
CKEDITOR.inlineAll=function(){var a,c,b;for(b in CKEDITOR.dtd.$editable)for(var f=CKEDITOR.document.getElementsByTag(b),d=0,e=f.count();d<e;d++){a=f.getItem(d);if(a.getAttribute("contenteditable")=="true"){c={element:a,config:{}};CKEDITOR.fire("inline",c)!==false&&CKEDITOR.inline(a,c.config)}}};CKEDITOR.domReady(function(){!CKEDITOR.disableAutoInline&&CKEDITOR.inlineAll()})})();CKEDITOR.replaceClass="ckeditor";
(function(){function a(a,e,f,n){if(!CKEDITOR.env.isCompatible)return null;a=CKEDITOR.dom.element.get(a);if(a.getEditor())throw'The editor instance "'+a.getEditor().name+'" is already attached to the provided element.';var h=new CKEDITOR.editor(e,a,n);if(n==CKEDITOR.ELEMENT_MODE_REPLACE){a.setStyle("visibility","hidden");h._.required=a.hasAttribute("required");a.removeAttribute("required")}f&&h.setData(f,null,true);h.on("loaded",function(){b(h);n==CKEDITOR.ELEMENT_MODE_REPLACE&&(h.config.autoUpdateElement&&
a.$.form)&&h._attachToForm();h.setMode(h.config.startupMode,function(){h.resetDirty();h.status="ready";h.fireOnce("instanceReady");CKEDITOR.fire("instanceReady",null,h)})});h.on("destroy",c);return h}function c(){var a=this.container,b=this.element;if(a){a.clearCustomData();a.remove()}if(b){b.clearCustomData();if(this.elementMode==CKEDITOR.ELEMENT_MODE_REPLACE){b.show();this._.required&&b.setAttribute("required","required")}delete this.element}}function b(a){var b=a.name,c=a.element,n=a.elementMode,
h=a.fire("uiSpace",{space:"top",html:""}).html,i=a.fire("uiSpace",{space:"bottom",html:""}).html;f||(f=CKEDITOR.addTemplate("maincontainer",'<{outerEl} id="cke_{name}" class="{id} cke cke_reset cke_chrome cke_editor_{name} cke_{langDir} '+CKEDITOR.env.cssClass+'"  dir="{langDir}" lang="{langCode}" role="application" aria-labelledby="cke_{name}_arialbl"><span id="cke_{name}_arialbl" class="cke_voice_label">{voiceLabel}</span><{outerEl} class="cke_inner cke_reset" role="presentation">{topHtml}<{outerEl} id="{contentId}" class="cke_contents cke_reset" role="presentation"></{outerEl}>{bottomHtml}</{outerEl}></{outerEl}>'));
b=CKEDITOR.dom.element.createFromHtml(f.output({id:a.id,name:b,langDir:a.lang.dir,langCode:a.langCode,voiceLabel:[a.lang.editor,a.name].join(", "),topHtml:h?'<span id="'+a.ui.spaceId("top")+'" class="cke_top cke_reset_all" role="presentation" style="height:auto">'+h+"</span>":"",contentId:a.ui.spaceId("contents"),bottomHtml:i?'<span id="'+a.ui.spaceId("bottom")+'" class="cke_bottom cke_reset_all" role="presentation">'+i+"</span>":"",outerEl:CKEDITOR.env.ie?"span":"div"}));if(n==CKEDITOR.ELEMENT_MODE_REPLACE){c.hide();
b.insertAfter(c)}else c.append(b);a.container=b;h&&a.ui.space("top").unselectable();i&&a.ui.space("bottom").unselectable();c=a.config.width;n=a.config.height;c&&b.setStyle("width",CKEDITOR.tools.cssLength(c));n&&a.ui.space("contents").setStyle("height",CKEDITOR.tools.cssLength(n));b.disableContextMenu();CKEDITOR.env.webkit&&b.on("focus",function(){a.focus()});a.fireOnce("uiReady")}CKEDITOR.replace=function(b,c){return a(b,c,null,CKEDITOR.ELEMENT_MODE_REPLACE)};CKEDITOR.appendTo=function(b,c,f){return a(b,
c,f,CKEDITOR.ELEMENT_MODE_APPENDTO)};CKEDITOR.replaceAll=function(){for(var a=document.getElementsByTagName("textarea"),b=0;b<a.length;b++){var c=null,f=a[b];if(f.name||f.id){if(typeof arguments[0]=="string"){if(!RegExp("(?:^|\\s)"+arguments[0]+"(?:$|\\s)").test(f.className))continue}else if(typeof arguments[0]=="function"){c={};if(arguments[0](f,c)===false)continue}this.replace(f,c)}}};CKEDITOR.editor.prototype.addMode=function(a,b){(this._.modes||(this._.modes={}))[a]=b};CKEDITOR.editor.prototype.setMode=
function(a,b){var c=this,f=this._.modes;if(!(a==c.mode||!f||!f[a])){c.fire("beforeSetMode",a);if(c.mode){var h=c.checkDirty(),f=c._.previousModeData,i,m=0;c.fire("beforeModeUnload");c.editable(0);c._.previousMode=c.mode;c._.previousModeData=i=c.getData(1);if(c.mode=="source"&&f==i){c.fire("lockSnapshot",{forceUpdate:true});m=1}c.ui.space("contents").setHtml("");c.mode=""}else c._.previousModeData=c.getData(1);this._.modes[a](function(){c.mode=a;h!==void 0&&!h&&c.resetDirty();m?c.fire("unlockSnapshot"):
a=="wysiwyg"&&c.fire("saveSnapshot");setTimeout(function(){c.fire("mode");b&&b.call(c)},0)})}};CKEDITOR.editor.prototype.resize=function(a,b,c,f){var h=this.container,i=this.ui.space("contents"),m=CKEDITOR.env.webkit&&this.document&&this.document.getWindow().$.frameElement,f=f?h.getChild(1):h;f.setSize("width",a,true);m&&(m.style.width="1%");i.setStyle("height",Math.max(b-(c?0:(f.$.offsetHeight||0)-(i.$.clientHeight||0)),0)+"px");m&&(m.style.width="100%");this.fire("resize")};CKEDITOR.editor.prototype.getResizable=
function(a){return a?this.ui.space("contents"):this.container};var f;CKEDITOR.domReady(function(){CKEDITOR.replaceClass&&CKEDITOR.replaceAll(CKEDITOR.replaceClass)})})();CKEDITOR.config.startupMode="wysiwyg";
(function(){function a(a){var b=a.editor,d=a.data.path,e=d.blockLimit,l=a.data.selection,j=l.getRanges()[0],g;if(CKEDITOR.env.gecko||CKEDITOR.env.ie&&CKEDITOR.env.needsBrFiller)if(l=c(l,d)){l.appendBogus();g=CKEDITOR.env.ie}if(b.config.autoParagraph!==false&&b.activeEnterMode!=CKEDITOR.ENTER_BR&&b.editable().equals(e)&&!d.block&&j.collapsed&&!j.getCommonAncestor().isReadOnly()){d=j.clone();d.enlarge(CKEDITOR.ENLARGE_BLOCK_CONTENTS);e=new CKEDITOR.dom.walker(d);e.guard=function(a){return!f(a)||a.type==
CKEDITOR.NODE_COMMENT||a.isReadOnly()};if(!e.checkForward()||d.checkStartOfBlock()&&d.checkEndOfBlock()){b=j.fixBlock(true,b.activeEnterMode==CKEDITOR.ENTER_DIV?"div":"p");if(!CKEDITOR.env.needsBrFiller)(b=b.getFirst(f))&&(b.type==CKEDITOR.NODE_TEXT&&CKEDITOR.tools.trim(b.getText()).match(/^(?:&nbsp;|\xa0)$/))&&b.remove();g=1;a.cancel()}}g&&j.select()}function c(a,b){if(a.isFake)return 0;var c=b.block||b.blockLimit,d=c&&c.getLast(f);if(c&&c.isBlockBoundary()&&(!d||!(d.type==CKEDITOR.NODE_ELEMENT&&
d.isBlockBoundary()))&&!c.is("pre")&&!c.getBogus())return c}function b(a){var b=a.data.getTarget();if(b.is("input")){b=b.getAttribute("type");(b=="submit"||b=="reset")&&a.data.preventDefault()}}function f(a){return p(a)&&s(a)}function d(a,b){return function(c){var d=CKEDITOR.dom.element.get(c.data.$.toElement||c.data.$.fromElement||c.data.$.relatedTarget);(!d||!b.equals(d)&&!b.contains(d))&&a.call(this,c)}}function e(a){var b,c=a.getRanges()[0],d=a.root,e={table:1,ul:1,ol:1,dl:1};if(c.startPath().contains(e)){var a=
function(a){return function(c,d){d&&(c.type==CKEDITOR.NODE_ELEMENT&&c.is(e))&&(b=c);if(!d&&f(c)&&(!a||!i(c)))return false}},j=c.clone();j.collapse(1);j.setStartAt(d,CKEDITOR.POSITION_AFTER_START);d=new CKEDITOR.dom.walker(j);d.guard=a();d.checkBackward();if(b){j=c.clone();j.collapse();j.setEndAt(b,CKEDITOR.POSITION_AFTER_END);d=new CKEDITOR.dom.walker(j);d.guard=a(true);b=false;d.checkForward();return b}}return null}function g(a){a.editor.focus();a.editor.fire("saveSnapshot")}function n(a){var b=
a.editor;b.getSelection().scrollIntoView();setTimeout(function(){b.fire("saveSnapshot")},0)}function h(a,b,c){for(var d=a.getCommonAncestor(b),b=a=c?b:a;(a=a.getParent())&&!d.equals(a)&&a.getChildCount()==1;)b=a;b.remove()}CKEDITOR.editable=CKEDITOR.tools.createClass({base:CKEDITOR.dom.element,$:function(a,b){this.base(b.$||b);this.editor=a;this.status="unloaded";this.hasFocus=false;this.setup()},proto:{focus:function(){var a;if(CKEDITOR.env.webkit&&!this.hasFocus){a=this.editor._.previousActive||
this.getDocument().getActive();if(this.contains(a)){a.focus();return}}try{this.$[CKEDITOR.env.ie&&this.getDocument().equals(CKEDITOR.document)?"setActive":"focus"]()}catch(b){if(!CKEDITOR.env.ie)throw b;}if(CKEDITOR.env.safari&&!this.isInline()){a=CKEDITOR.document.getActive();a.equals(this.getWindow().getFrame())||this.getWindow().focus()}},on:function(a,b){var c=Array.prototype.slice.call(arguments,0);if(CKEDITOR.env.ie&&/^focus|blur$/.exec(a)){a=a=="focus"?"focusin":"focusout";b=d(b,this);c[0]=
a;c[1]=b}return CKEDITOR.dom.element.prototype.on.apply(this,c)},attachListener:function(a,b,c,d,e,f){!this._.listeners&&(this._.listeners=[]);var g=Array.prototype.slice.call(arguments,1),g=a.on.apply(a,g);this._.listeners.push(g);return g},clearListeners:function(){var a=this._.listeners;try{for(;a.length;)a.pop().removeListener()}catch(b){}},restoreAttrs:function(){var a=this._.attrChanges,b,c;for(c in a)if(a.hasOwnProperty(c)){b=a[c];b!==null?this.setAttribute(c,b):this.removeAttribute(c)}},attachClass:function(a){var b=
this.getCustomData("classes");if(!this.hasClass(a)){!b&&(b=[]);b.push(a);this.setCustomData("classes",b);this.addClass(a)}},changeAttr:function(a,b){var c=this.getAttribute(a);if(b!==c){!this._.attrChanges&&(this._.attrChanges={});a in this._.attrChanges||(this._.attrChanges[a]=c);this.setAttribute(a,b)}},insertHtml:function(a,b){g(this);x(this,b||"html",a)},insertText:function(a){g(this);var b=this.editor,c=b.getSelection().getStartElement().hasAscendant("pre",true)?CKEDITOR.ENTER_BR:b.activeEnterMode,
b=c==CKEDITOR.ENTER_BR,d=CKEDITOR.tools,a=d.htmlEncode(a.replace(/\r\n/g,"\n")),a=a.replace(/\t/g,"&nbsp;&nbsp; &nbsp;"),c=c==CKEDITOR.ENTER_P?"p":"div";if(!b){var e=/\n{2}/g;if(e.test(a))var f="<"+c+">",v="</"+c+">",a=f+a.replace(e,function(){return v+f})+v}a=a.replace(/\n/g,"<br>");b||(a=a.replace(RegExp("<br>(?=</"+c+">)"),function(a){return d.repeat(a,2)}));a=a.replace(/^ | $/g,"&nbsp;");a=a.replace(/(>|\s) /g,function(a,b){return b+"&nbsp;"}).replace(/ (?=<)/g,"&nbsp;");x(this,"text",a)},insertElement:function(a,
b){b?this.insertElementIntoRange(a,b):this.insertElementIntoSelection(a)},insertElementIntoRange:function(a,b){var c=this.editor,d=c.config.enterMode,e=a.getName(),f=CKEDITOR.dtd.$block[e];if(b.checkReadOnly())return false;b.deleteContents(1);b.startContainer.type==CKEDITOR.NODE_ELEMENT&&b.startContainer.is({tr:1,table:1,tbody:1,thead:1,tfoot:1})&&q(b);var g,h;if(f)for(;(g=b.getCommonAncestor(0,1))&&(h=CKEDITOR.dtd[g.getName()])&&(!h||!h[e]);)if(g.getName()in CKEDITOR.dtd.span)b.splitElement(g);else if(b.checkStartOfBlock()&&
b.checkEndOfBlock()){b.setStartBefore(g);b.collapse(true);g.remove()}else b.splitBlock(d==CKEDITOR.ENTER_DIV?"div":"p",c.editable());b.insertNode(a);return true},insertElementIntoSelection:function(a){g(this);var b=this.editor,c=b.activeEnterMode,b=b.getSelection(),d=b.getRanges()[0],e=a.getName(),e=CKEDITOR.dtd.$block[e];if(this.insertElementIntoRange(a,d)){d.moveToPosition(a,CKEDITOR.POSITION_AFTER_END);if(e)if((e=a.getNext(function(a){return f(a)&&!i(a)}))&&e.type==CKEDITOR.NODE_ELEMENT&&e.is(CKEDITOR.dtd.$block))e.getDtd()["#"]?
d.moveToElementEditStart(e):d.moveToElementEditEnd(a);else if(!e&&c!=CKEDITOR.ENTER_BR){e=d.fixBlock(true,c==CKEDITOR.ENTER_DIV?"div":"p");d.moveToElementEditStart(e)}}b.selectRanges([d]);n(this)},setData:function(a,b){b||(a=this.editor.dataProcessor.toHtml(a));this.setHtml(a);if(this.status=="unloaded")this.status="ready";this.editor.fire("dataReady")},getData:function(a){var b=this.getHtml();a||(b=this.editor.dataProcessor.toDataFormat(b));return b},setReadOnly:function(a){this.setAttribute("contenteditable",
!a)},detach:function(){this.removeClass("cke_editable");this.status="detached";var a=this.editor;this._.detach();delete a.document;delete a.window},isInline:function(){return this.getDocument().equals(CKEDITOR.document)},setup:function(){var a=this.editor;this.attachListener(a,"beforeGetData",function(){var b=this.getData();this.is("textarea")||a.config.ignoreEmptyParagraph!==false&&(b=b.replace(m,function(a,b){return b}));a.setData(b,null,1)},this);this.attachListener(a,"getSnapshot",function(a){a.data=
this.getData(1)},this);this.attachListener(a,"afterSetData",function(){this.setData(a.getData(1))},this);this.attachListener(a,"loadSnapshot",function(a){this.setData(a.data,1)},this);this.attachListener(a,"beforeFocus",function(){var b=a.getSelection();(b=b&&b.getNative())&&b.type=="Control"||this.focus()},this);this.attachListener(a,"insertHtml",function(a){this.insertHtml(a.data.dataValue,a.data.mode)},this);this.attachListener(a,"insertElement",function(a){this.insertElement(a.data)},this);this.attachListener(a,
"insertText",function(a){this.insertText(a.data)},this);this.setReadOnly(a.readOnly);this.attachClass("cke_editable");this.attachClass(a.elementMode==CKEDITOR.ELEMENT_MODE_INLINE?"cke_editable_inline":a.elementMode==CKEDITOR.ELEMENT_MODE_REPLACE||a.elementMode==CKEDITOR.ELEMENT_MODE_APPENDTO?"cke_editable_themed":"");this.attachClass("cke_contents_"+a.config.contentsLangDirection);a.keystrokeHandler.blockedKeystrokes[8]=+a.readOnly;a.keystrokeHandler.attach(this);this.on("blur",function(){this.hasFocus=
false},null,null,-1);this.on("focus",function(){this.hasFocus=true},null,null,-1);a.focusManager.add(this);if(this.equals(CKEDITOR.document.getActive())){this.hasFocus=true;a.once("contentDom",function(){a.focusManager.focus()})}this.isInline()&&this.changeAttr("tabindex",a.tabIndex);if(!this.is("textarea")){a.document=this.getDocument();a.window=this.getWindow();var c=a.document;this.changeAttr("spellcheck",!a.config.disableNativeSpellChecker);var d=a.config.contentsLangDirection;this.getDirection(1)!=
d&&this.changeAttr("dir",d);var k=CKEDITOR.getCss();if(k){d=c.getHead();if(!d.getCustomData("stylesheet")){k=c.appendStyleText(k);k=new CKEDITOR.dom.element(k.ownerNode||k.owningElement);d.setCustomData("stylesheet",k);k.data("cke-temp",1)}}d=c.getCustomData("stylesheet_ref")||0;c.setCustomData("stylesheet_ref",d+1);this.setCustomData("cke_includeReadonly",!a.config.disableReadonlyStyling);this.attachListener(this,"click",function(a){var a=a.data,b=(new CKEDITOR.dom.elementPath(a.getTarget(),this)).contains("a");
b&&(a.$.button!=2&&b.isReadOnly())&&a.preventDefault()});var l={8:1,46:1};this.attachListener(a,"key",function(b){if(a.readOnly)return true;var c=b.data.domEvent.getKey(),d;if(c in l){var b=a.getSelection(),f,k=b.getRanges()[0],g=k.startPath(),h,i,m,c=c==8;if(CKEDITOR.env.ie&&CKEDITOR.env.version<11&&(f=b.getSelectedElement())||(f=e(b))){a.fire("saveSnapshot");k.moveToPosition(f,CKEDITOR.POSITION_BEFORE_START);f.remove();k.select();a.fire("saveSnapshot");d=1}else if(k.collapsed)if((h=g.block)&&(m=
h[c?"getPrevious":"getNext"](p))&&m.type==CKEDITOR.NODE_ELEMENT&&m.is("table")&&k[c?"checkStartOfBlock":"checkEndOfBlock"]()){a.fire("saveSnapshot");k[c?"checkEndOfBlock":"checkStartOfBlock"]()&&h.remove();k["moveToElementEdit"+(c?"End":"Start")](m);k.select();a.fire("saveSnapshot");d=1}else if(g.blockLimit&&g.blockLimit.is("td")&&(i=g.blockLimit.getAscendant("table"))&&k.checkBoundaryOfElement(i,c?CKEDITOR.START:CKEDITOR.END)&&(m=i[c?"getPrevious":"getNext"](p))){a.fire("saveSnapshot");k["moveToElementEdit"+
(c?"End":"Start")](m);k.checkStartOfBlock()&&k.checkEndOfBlock()?m.remove():k.select();a.fire("saveSnapshot");d=1}else if((i=g.contains(["td","th","caption"]))&&k.checkBoundaryOfElement(i,c?CKEDITOR.START:CKEDITOR.END))d=1}return!d});a.blockless&&(CKEDITOR.env.ie&&CKEDITOR.env.needsBrFiller)&&this.attachListener(this,"keyup",function(b){if(b.data.getKeystroke()in l&&!this.getFirst(f)){this.appendBogus();b=a.createRange();b.moveToPosition(this,CKEDITOR.POSITION_AFTER_START);b.select()}});this.attachListener(this,
"dblclick",function(b){if(a.readOnly)return false;b={element:b.data.getTarget()};a.fire("doubleclick",b)});CKEDITOR.env.ie&&this.attachListener(this,"click",b);CKEDITOR.env.ie||this.attachListener(this,"mousedown",function(b){var c=b.data.getTarget();if(c.is("img","hr","input","textarea","select")&&!c.isReadOnly()){a.getSelection().selectElement(c);c.is("input","textarea","select")&&b.data.preventDefault()}});CKEDITOR.env.gecko&&this.attachListener(this,"mouseup",function(b){if(b.data.$.button==2){b=
b.data.getTarget();if(!b.getOuterHtml().replace(m,"")){var c=a.createRange();c.moveToElementEditStart(b);c.select(true)}}});if(CKEDITOR.env.webkit){this.attachListener(this,"click",function(a){a.data.getTarget().is("input","select")&&a.data.preventDefault()});this.attachListener(this,"mouseup",function(a){a.data.getTarget().is("input","textarea")&&a.data.preventDefault()})}CKEDITOR.env.webkit&&this.attachListener(a,"key",function(b){b=b.data.domEvent.getKey();if(b in l){var c=b==8,d=a.getSelection().getRanges()[0],
b=d.startPath();if(d.collapsed){var e;a:{var f=b.block;if(f)if(d[c?"checkStartOfBlock":"checkEndOfBlock"]())if(!d.moveToClosestEditablePosition(f,!c)||!d.collapsed)e=false;else{if(d.startContainer.type==CKEDITOR.NODE_ELEMENT){var k=d.startContainer.getChild(d.startOffset-(c?1:0));if(k&&k.type==CKEDITOR.NODE_ELEMENT&&k.is("hr")){a.fire("saveSnapshot");k.remove();e=true;break a}}if((d=d.startPath().block)&&(!d||!d.contains(f))){a.fire("saveSnapshot");var g;(g=(c?d:f).getBogus())&&g.remove();e=a.getSelection();
g=e.createBookmarks();(c?f:d).moveChildren(c?d:f,false);b.lastElement.mergeSiblings();h(f,d,!c);e.selectBookmarks(g);e=true}}else e=false;else e=false}if(!e)return}else{c=d;e=b.block;g=c.endPath().block;if(!e||!g||e.equals(g))b=false;else{a.fire("saveSnapshot");(f=e.getBogus())&&f.remove();c.deleteContents();if(g.getParent()){g.moveChildren(e,false);b.lastElement.mergeSiblings();h(e,g,true)}c=a.getSelection().getRanges()[0];c.collapse(1);c.select();b=true}if(!b)return}a.getSelection().scrollIntoView();
a.fire("saveSnapshot");return false}},this,null,100)}}},_:{detach:function(){this.editor.setData(this.editor.getData(),0,1);this.clearListeners();this.restoreAttrs();var a;if(a=this.removeCustomData("classes"))for(;a.length;)this.removeClass(a.pop());if(!this.is("textarea")){a=this.getDocument();var b=a.getHead();if(b.getCustomData("stylesheet")){var c=a.getCustomData("stylesheet_ref");if(--c)a.setCustomData("stylesheet_ref",c);else{a.removeCustomData("stylesheet_ref");b.removeCustomData("stylesheet").remove()}}}this.editor.fire("contentDomUnload");
delete this.editor}}});CKEDITOR.editor.prototype.editable=function(a){var b=this._.editable;if(b&&a)return 0;if(arguments.length)b=this._.editable=a?a instanceof CKEDITOR.editable?a:new CKEDITOR.editable(this,a):(b&&b.detach(),null);return b};var i=CKEDITOR.dom.walker.bogus(),m=/(^|<body\b[^>]*>)\s*<(p|div|address|h\d|center|pre)[^>]*>\s*(?:<br[^>]*>|&nbsp;|\u00A0|&#160;)?\s*(:?<\/\2>)?\s*(?=$|<\/body>)/gi,p=CKEDITOR.dom.walker.whitespaces(true),s=CKEDITOR.dom.walker.bookmark(false,true);CKEDITOR.on("instanceLoaded",
function(b){var c=b.editor;c.on("insertElement",function(a){a=a.data;if(a.type==CKEDITOR.NODE_ELEMENT&&(a.is("input")||a.is("textarea"))){a.getAttribute("contentEditable")!="false"&&a.data("cke-editable",a.hasAttribute("contenteditable")?"true":"1");a.setAttribute("contentEditable",false)}});c.on("selectionChange",function(b){if(!c.readOnly){var d=c.getSelection();if(d&&!d.isLocked){d=c.checkDirty();c.fire("lockSnapshot");a(b);c.fire("unlockSnapshot");!d&&c.resetDirty()}}})});CKEDITOR.on("instanceCreated",
function(a){var b=a.editor;b.on("mode",function(){var a=b.editable();if(a&&a.isInline()){var c=b.title;a.changeAttr("role","textbox");a.changeAttr("aria-label",c);c&&a.changeAttr("title",c);if(c=this.ui.space(this.elementMode==CKEDITOR.ELEMENT_MODE_INLINE?"top":"contents")){var d=CKEDITOR.tools.getNextId(),e=CKEDITOR.dom.element.createFromHtml('<span id="'+d+'" class="cke_voice_label">'+this.lang.common.editorHelp+"</span>");c.append(e);a.changeAttr("aria-describedby",d)}}})});CKEDITOR.addCss(".cke_editable{cursor:text}.cke_editable img,.cke_editable input,.cke_editable textarea{cursor:default}");
var x=function(){function a(b){return b.type==CKEDITOR.NODE_ELEMENT}function b(c,d){var e,f,j,k,l=[],r=d.range.startContainer;e=d.range.startPath();for(var r=g[r.getName()],h=0,i=c.getChildren(),m=i.count(),n=-1,q=-1,p=0,s=e.contains(g.$list);h<m;++h){e=i.getItem(h);if(a(e)){j=e.getName();if(s&&j in CKEDITOR.dtd.$list)l=l.concat(b(e,d));else{k=!!r[j];if(j=="br"&&e.data("cke-eol")&&(!h||h==m-1)){p=(f=h?l[h-1].node:i.getItem(h+1))&&(!a(f)||!f.is("br"));f=f&&a(f)&&g.$block[f.getName()]}n==-1&&!k&&(n=
h);k||(q=h);l.push({isElement:1,isLineBreak:p,isBlock:e.isBlockBoundary(),hasBlockSibling:f,node:e,name:j,allowed:k});f=p=0}}else l.push({isElement:0,node:e,allowed:1})}if(n>-1)l[n].firstNotAllowed=1;if(q>-1)l[q].lastNotAllowed=1;return l}function c(b,d){var e=[],f=b.getChildren(),j=f.count(),k,l=0,r=g[d],h=!b.is(g.$inline)||b.is("br");for(h&&e.push(" ");l<j;l++){k=f.getItem(l);a(k)&&!k.is(r)?e=e.concat(c(k,d)):e.push(k)}h&&e.push(" ");return e}function d(b){return b&&a(b)&&(b.is(g.$removeEmpty)||
b.is("a")&&!b.isBlockBoundary())}function e(b,c,d,f){var j=b.clone(),k,g;j.setEndAt(c,CKEDITOR.POSITION_BEFORE_END);if((k=(new CKEDITOR.dom.walker(j)).next())&&a(k)&&h[k.getName()]&&(g=k.getPrevious())&&a(g)&&!g.getParent().equals(b.startContainer)&&d.contains(g)&&f.contains(k)&&k.isIdentical(g)){k.moveChildren(g);k.remove();e(b,c,d,f)}}function j(b,c){function d(b,c){if(c.isBlock&&c.isElement&&!c.node.is("br")&&a(b)&&b.is("br")){b.remove();return 1}}var e=c.endContainer.getChild(c.endOffset),f=c.endContainer.getChild(c.endOffset-
1);e&&d(e,b[b.length-1]);if(f&&d(f,b[0])){c.setEnd(c.endContainer,c.endOffset-1);c.collapse()}}var g=CKEDITOR.dtd,h={p:1,div:1,h1:1,h2:1,h3:1,h4:1,h5:1,h6:1,ul:1,ol:1,li:1,pre:1,dl:1,blockquote:1},r={p:1,div:1,h1:1,h2:1,h3:1,h4:1,h5:1,h6:1},i=CKEDITOR.tools.extend({},g.$inline);delete i.br;return function(h,m,q){var p=h.editor;h.getDocument();var s=p.getSelection().getRanges()[0],w=false;if(m=="unfiltered_html"){m="html";w=true}if(!s.checkReadOnly()){var z=(new CKEDITOR.dom.elementPath(s.startContainer,
s.root)).blockLimit||s.root,m={type:m,dontFilter:w,editable:h,editor:p,range:s,blockLimit:z,mergeCandidates:[],zombies:[]},p=m.range,w=m.mergeCandidates,t,E,y,C;if(m.type=="text"&&p.shrink(CKEDITOR.SHRINK_ELEMENT,true,false)){t=CKEDITOR.dom.element.createFromHtml("<span>&nbsp;</span>",p.document);p.insertNode(t);p.setStartAfter(t)}E=new CKEDITOR.dom.elementPath(p.startContainer);m.endPath=y=new CKEDITOR.dom.elementPath(p.endContainer);if(!p.collapsed){var z=y.block||y.blockLimit,I=p.getCommonAncestor();
z&&(!z.equals(I)&&!z.contains(I)&&p.checkEndOfBlock())&&m.zombies.push(z);p.deleteContents()}for(;(C=a(p.startContainer)&&p.startContainer.getChild(p.startOffset-1))&&a(C)&&C.isBlockBoundary()&&E.contains(C);)p.moveToPosition(C,CKEDITOR.POSITION_BEFORE_END);e(p,m.blockLimit,E,y);if(t){p.setEndBefore(t);p.collapse();t.remove()}t=p.startPath();if(z=t.contains(d,false,1)){p.splitElement(z);m.inlineStylesRoot=z;m.inlineStylesPeak=t.lastElement}t=p.createBookmark();(z=t.startNode.getPrevious(f))&&a(z)&&
d(z)&&w.push(z);(z=t.startNode.getNext(f))&&a(z)&&d(z)&&w.push(z);for(z=t.startNode;(z=z.getParent())&&d(z);)w.push(z);p.moveToBookmark(t);if(t=q){t=m.range;if(m.type=="text"&&m.inlineStylesRoot){C=m.inlineStylesPeak;p=C.getDocument().createText("{cke-peak}");for(w=m.inlineStylesRoot.getParent();!C.equals(w);){p=p.appendTo(C.clone());C=C.getParent()}q=p.getOuterHtml().split("{cke-peak}").join(q)}C=m.blockLimit.getName();if(/^\s+|\s+$/.test(q)&&"span"in CKEDITOR.dtd[C])var x='<span data-cke-marker="1">&nbsp;</span>',
q=x+q+x;q=m.editor.dataProcessor.toHtml(q,{context:null,fixForBody:false,dontFilter:m.dontFilter,filter:m.editor.activeFilter,enterMode:m.editor.activeEnterMode});C=t.document.createElement("body");C.setHtml(q);if(x){C.getFirst().remove();C.getLast().remove()}if((x=t.startPath().block)&&!(x.getChildCount()==1&&x.getBogus()))a:{var G;if(C.getChildCount()==1&&a(G=C.getFirst())&&G.is(r)){x=G.getElementsByTag("*");t=0;for(w=x.count();t<w;t++){p=x.getItem(t);if(!p.is(i))break a}G.moveChildren(G.getParent(1));
G.remove()}}m.dataWrapper=C;t=q}if(t){G=m.range;var x=G.document,B,q=m.blockLimit;t=0;var K;C=[];var H,Q,w=p=0,M,T;E=G.startContainer;var z=m.endPath.elements[0],U;y=z.getPosition(E);I=!!z.getCommonAncestor(E)&&y!=CKEDITOR.POSITION_IDENTICAL&&!(y&CKEDITOR.POSITION_CONTAINS+CKEDITOR.POSITION_IS_CONTAINED);E=b(m.dataWrapper,m);for(j(E,G);t<E.length;t++){y=E[t];if(B=y.isLineBreak){B=G;M=q;var N=void 0,W=void 0;if(y.hasBlockSibling)B=1;else{N=B.startContainer.getAscendant(g.$block,1);if(!N||!N.is({div:1,
p:1}))B=0;else{W=N.getPosition(M);if(W==CKEDITOR.POSITION_IDENTICAL||W==CKEDITOR.POSITION_CONTAINS)B=0;else{M=B.splitElement(N);B.moveToPosition(M,CKEDITOR.POSITION_AFTER_START);B=1}}}}if(B)w=t>0;else{B=G.startPath();if(!y.isBlock&&m.editor.config.autoParagraph!==false&&(m.editor.activeEnterMode!=CKEDITOR.ENTER_BR&&m.editor.editable().equals(B.blockLimit)&&!B.block)&&(Q=m.editor.activeEnterMode!=CKEDITOR.ENTER_BR&&m.editor.config.autoParagraph!==false?m.editor.activeEnterMode==CKEDITOR.ENTER_DIV?
"div":"p":false)){Q=x.createElement(Q);Q.appendBogus();G.insertNode(Q);CKEDITOR.env.needsBrFiller&&(K=Q.getBogus())&&K.remove();G.moveToPosition(Q,CKEDITOR.POSITION_BEFORE_END)}if((B=G.startPath().block)&&!B.equals(H)){if(K=B.getBogus()){K.remove();C.push(B)}H=B}y.firstNotAllowed&&(p=1);if(p&&y.isElement){B=G.startContainer;for(M=null;B&&!g[B.getName()][y.name];){if(B.equals(q)){B=null;break}M=B;B=B.getParent()}if(B){if(M){T=G.splitElement(M);m.zombies.push(T);m.zombies.push(M)}}else{M=q.getName();
U=!t;B=t==E.length-1;M=c(y.node,M);for(var N=[],W=M.length,X=0,Z=void 0,$=0,aa=-1;X<W;X++){Z=M[X];if(Z==" "){if(!$&&(!U||X)){N.push(new CKEDITOR.dom.text(" "));aa=N.length}$=1}else{N.push(Z);$=0}}B&&aa==N.length&&N.pop();U=N}}if(U){for(;B=U.pop();)G.insertNode(B);U=0}else G.insertNode(y.node);if(y.lastNotAllowed&&t<E.length-1){(T=I?z:T)&&G.setEndAt(T,CKEDITOR.POSITION_AFTER_START);p=0}G.collapse()}}m.dontMoveCaret=w;m.bogusNeededBlocks=C}K=m.range;var P;T=m.bogusNeededBlocks;for(U=K.createBookmark();H=
m.zombies.pop();)if(H.getParent()){Q=K.clone();Q.moveToElementEditStart(H);Q.removeEmptyBlocksAtEnd()}if(T)for(;H=T.pop();)CKEDITOR.env.needsBrFiller?H.appendBogus():H.append(K.document.createText(" "));for(;H=m.mergeCandidates.pop();)H.mergeSiblings();K.moveToBookmark(U);if(!m.dontMoveCaret){for(H=a(K.startContainer)&&K.startContainer.getChild(K.startOffset-1);H&&a(H)&&!H.is(g.$empty);){if(H.isBlockBoundary())K.moveToPosition(H,CKEDITOR.POSITION_BEFORE_END);else{if(d(H)&&H.getHtml().match(/(\s|&nbsp;)$/g)){P=
null;break}P=K.clone();P.moveToPosition(H,CKEDITOR.POSITION_BEFORE_END)}H=H.getLast(f)}P&&K.moveToRange(P)}s.select();n(h)}}}(),q=function(){function a(b){b=new CKEDITOR.dom.walker(b);b.guard=function(a,b){if(b)return false;if(a.type==CKEDITOR.NODE_ELEMENT)return a.is(CKEDITOR.dtd.$tableContent)};b.evaluator=function(a){return a.type==CKEDITOR.NODE_ELEMENT};return b}function b(a,c,d){c=a.getDocument().createElement(c);a.append(c,d);return c}function c(a){var b=a.count(),d;for(b;b-- >0;){d=a.getItem(b);
if(!CKEDITOR.tools.trim(d.getHtml())){d.appendBogus();CKEDITOR.env.ie&&(CKEDITOR.env.version<9&&d.getChildCount())&&d.getFirst().remove()}}}return function(d){var e=d.startContainer,f=e.getAscendant("table",1),g=false;c(f.getElementsByTag("td"));c(f.getElementsByTag("th"));f=d.clone();f.setStart(e,0);f=a(f).lastBackward();if(!f){f=d.clone();f.setEndAt(e,CKEDITOR.POSITION_BEFORE_END);f=a(f).lastForward();g=true}f||(f=e);if(f.is("table")){d.setStartAt(f,CKEDITOR.POSITION_BEFORE_START);d.collapse(true);
f.remove()}else{f.is({tbody:1,thead:1,tfoot:1})&&(f=b(f,"tr",g));f.is("tr")&&(f=b(f,f.getParent().is("thead")?"th":"td",g));(e=f.getBogus())&&e.remove();d.moveToPosition(f,g?CKEDITOR.POSITION_AFTER_START:CKEDITOR.POSITION_BEFORE_END)}}}()})();
(function(){function a(){var a=this._.fakeSelection,b;if(a){b=this.getSelection(1);if(!b||!b.isHidden()){a.reset();a=0}}if(!a){a=b||this.getSelection(1);if(!a||a.getType()==CKEDITOR.SELECTION_NONE)return}this.fire("selectionCheck",a);b=this.elementPath();if(!b.compare(this._.selectionPreviousPath)){if(CKEDITOR.env.webkit)this._.previousActive=this.document.getActive();this._.selectionPreviousPath=b;this.fire("selectionChange",{selection:a,path:b})}}function c(){s=true;if(!p){b.call(this);p=CKEDITOR.tools.setTimeout(b,
200,this)}}function b(){p=null;if(s){CKEDITOR.tools.setTimeout(a,0,this);s=false}}function f(a){function b(c,d){return!c||c.type==CKEDITOR.NODE_TEXT?false:a.clone()["moveToElementEdit"+(d?"End":"Start")](c)}if(!(a.root instanceof CKEDITOR.editable))return false;var c=a.startContainer,d=a.getPreviousNode(x,null,c),e=a.getNextNode(x,null,c);return b(d)||b(e,1)||!d&&!e&&!(c.type==CKEDITOR.NODE_ELEMENT&&c.isBlockBoundary()&&c.getBogus())?true:false}function d(a){return a.getCustomData("cke-fillingChar")}
function e(a,b){var c=a&&a.removeCustomData("cke-fillingChar");if(c){if(b!==false){var d,e=a.getDocument().getSelection().getNative(),f=e&&e.type!="None"&&e.getRangeAt(0);if(c.getLength()>1&&f&&f.intersectsNode(c.$)){d=[e.anchorOffset,e.focusOffset];f=e.focusNode==c.$&&e.focusOffset>0;e.anchorNode==c.$&&e.anchorOffset>0&&d[0]--;f&&d[1]--;var h;f=e;if(!f.isCollapsed){h=f.getRangeAt(0);h.setStart(f.anchorNode,f.anchorOffset);h.setEnd(f.focusNode,f.focusOffset);h=h.collapsed}h&&d.unshift(d.pop())}}c.setText(g(c.getText()));
if(d){c=e.getRangeAt(0);c.setStart(c.startContainer,d[0]);c.setEnd(c.startContainer,d[1]);e.removeAllRanges();e.addRange(c)}}}function g(a){return a.replace(/\u200B( )?/g,function(a){return a[1]?" ":""})}function n(a,b,c){var d=a.on("focus",function(a){a.cancel()},null,null,-100);if(CKEDITOR.env.ie)var e=a.getDocument().on("selectionchange",function(a){a.cancel()},null,null,-100);else{var f=new CKEDITOR.dom.range(a);f.moveToElementEditStart(a);var g=a.getDocument().$.createRange();g.setStart(f.startContainer.$,
f.startOffset);g.collapse(1);b.removeAllRanges();b.addRange(g)}c&&a.focus();d.removeListener();e&&e.removeListener()}function h(a){var b=CKEDITOR.dom.element.createFromHtml('<div data-cke-hidden-sel="1" data-cke-temp="1" style="'+(CKEDITOR.env.ie?"display:none":"position:fixed;top:0;left:-1000px")+'">&nbsp;</div>',a.document);a.fire("lockSnapshot");a.editable().append(b);var c=a.getSelection(1),d=a.createRange(),e=c.root.on("selectionchange",function(a){a.cancel()},null,null,0);d.setStartAt(b,CKEDITOR.POSITION_AFTER_START);
d.setEndAt(b,CKEDITOR.POSITION_BEFORE_END);c.selectRanges([d]);e.removeListener();a.fire("unlockSnapshot");a._.hiddenSelectionContainer=b}function i(a){var b={37:1,39:1,8:1,46:1};return function(c){var d=c.data.getKeystroke();if(b[d]){var e=a.getSelection().getRanges(),f=e[0];if(e.length==1&&f.collapsed)if((d=f[d<38?"getPreviousEditableNode":"getNextEditableNode"]())&&d.type==CKEDITOR.NODE_ELEMENT&&d.getAttribute("contenteditable")=="false"){a.getSelection().fake(d);c.data.preventDefault();c.cancel()}}}}
function m(a){for(var b=0;b<a.length;b++){var c=a[b];c.getCommonAncestor().isReadOnly()&&a.splice(b,1);if(!c.collapsed){if(c.startContainer.isReadOnly())for(var d=c.startContainer,e;d;){if((e=d.type==CKEDITOR.NODE_ELEMENT)&&d.is("body")||!d.isReadOnly())break;e&&d.getAttribute("contentEditable")=="false"&&c.setStartAfter(d);d=d.getParent()}d=c.startContainer;e=c.endContainer;var f=c.startOffset,g=c.endOffset,h=c.clone();d&&d.type==CKEDITOR.NODE_TEXT&&(f>=d.getLength()?h.setStartAfter(d):h.setStartBefore(d));
e&&e.type==CKEDITOR.NODE_TEXT&&(g?h.setEndAfter(e):h.setEndBefore(e));d=new CKEDITOR.dom.walker(h);d.evaluator=function(d){if(d.type==CKEDITOR.NODE_ELEMENT&&d.isReadOnly()){var e=c.clone();c.setEndBefore(d);c.collapsed&&a.splice(b--,1);if(!(d.getPosition(h.endContainer)&CKEDITOR.POSITION_CONTAINS)){e.setStartAfter(d);e.collapsed||a.splice(b+1,0,e)}return true}return false};d.next()}}return a}var p,s,x=CKEDITOR.dom.walker.invisible(1),q=function(){function a(b){return function(a){var c=a.editor.createRange();
c.moveToClosestEditablePosition(a.selected,b)&&a.editor.getSelection().selectRanges([c]);return false}}function b(a){return function(b){var c=b.editor,d=c.createRange(),e;if(!(e=d.moveToClosestEditablePosition(b.selected,a)))e=d.moveToClosestEditablePosition(b.selected,!a);e&&c.getSelection().selectRanges([d]);c.fire("saveSnapshot");b.selected.remove();if(!e){d.moveToElementEditablePosition(c.editable());c.getSelection().selectRanges([d])}c.fire("saveSnapshot");return false}}var c=a(),d=a(1);return{37:c,
38:c,39:d,40:d,8:b(),46:b(1)}}();CKEDITOR.on("instanceCreated",function(b){function d(){var a=f.getSelection();a&&a.removeAllRanges()}var f=b.editor;f.on("contentDom",function(){var b=f.document,d=CKEDITOR.document,g=f.editable(),k=b.getBody(),l=b.getDocumentElement(),h=g.isInline(),m,n;CKEDITOR.env.gecko&&g.attachListener(g,"focus",function(a){a.removeListener();if(m!==0)if((a=f.getSelection().getNative())&&a.isCollapsed&&a.anchorNode==g.$){a=f.createRange();a.moveToElementEditStart(g);a.select()}},
null,null,-2);g.attachListener(g,CKEDITOR.env.webkit?"DOMFocusIn":"focus",function(){m&&CKEDITOR.env.webkit&&(m=f._.previousActive&&f._.previousActive.equals(b.getActive()));f.unlockSelection(m);m=0},null,null,-1);g.attachListener(g,"mousedown",function(){m=0});if(CKEDITOR.env.ie||h){var q=function(){n=new CKEDITOR.dom.selection(f.getSelection());n.lock()};o?g.attachListener(g,"beforedeactivate",q,null,null,-1):g.attachListener(f,"selectionCheck",q,null,null,-1);g.attachListener(g,CKEDITOR.env.webkit?
"DOMFocusOut":"blur",function(){f.lockSelection(n);m=1},null,null,-1);g.attachListener(g,"mousedown",function(){m=0})}if(CKEDITOR.env.ie&&!h){var w;g.attachListener(g,"mousedown",function(a){if(a.data.$.button==2){a=f.document.getSelection();if(!a||a.getType()==CKEDITOR.SELECTION_NONE)w=f.window.getScrollPosition()}});g.attachListener(g,"mouseup",function(a){if(a.data.$.button==2&&w){f.document.$.documentElement.scrollLeft=w.x;f.document.$.documentElement.scrollTop=w.y}w=null});if(b.$.compatMode!=
"BackCompat"){if(CKEDITOR.env.ie7Compat||CKEDITOR.env.ie6Compat)l.on("mousedown",function(a){function b(a){a=a.data.$;if(e){var c=k.$.createTextRange();try{c.moveToPoint(a.x,a.y)}catch(d){}e.setEndPoint(g.compareEndPoints("StartToStart",c)<0?"EndToEnd":"StartToStart",c);e.select()}}function c(){l.removeListener("mousemove",b);d.removeListener("mouseup",c);l.removeListener("mouseup",c);e.select()}a=a.data;if(a.getTarget().is("html")&&a.$.y<l.$.clientHeight&&a.$.x<l.$.clientWidth){var e=k.$.createTextRange();
try{e.moveToPoint(a.$.x,a.$.y)}catch(f){}var g=e.duplicate();l.on("mousemove",b);d.on("mouseup",c);l.on("mouseup",c)}});if(CKEDITOR.env.version>7&&CKEDITOR.env.version<11){l.on("mousedown",function(a){if(a.data.getTarget().is("html")){d.on("mouseup",z);l.on("mouseup",z)}});var z=function(){d.removeListener("mouseup",z);l.removeListener("mouseup",z);var a=CKEDITOR.document.$.selection,c=a.createRange();a.type!="None"&&c.parentElement().ownerDocument==b.$&&c.select()}}}}g.attachListener(g,"selectionchange",
a,f);g.attachListener(g,"keyup",c,f);g.attachListener(g,CKEDITOR.env.webkit?"DOMFocusIn":"focus",function(){f.forceNextSelectionCheck();f.selectionChange(1)});if(h&&(CKEDITOR.env.webkit||CKEDITOR.env.gecko)){var t;g.attachListener(g,"mousedown",function(){t=1});g.attachListener(b.getDocumentElement(),"mouseup",function(){t&&c.call(f);t=0})}else g.attachListener(CKEDITOR.env.ie?g:b.getDocumentElement(),"mouseup",c,f);CKEDITOR.env.webkit&&g.attachListener(b,"keydown",function(a){switch(a.data.getKey()){case 13:case 33:case 34:case 35:case 36:case 37:case 39:case 8:case 45:case 46:e(g)}},
null,null,-1);g.attachListener(g,"keydown",i(f),null,null,-1)});f.on("setData",function(){f.unlockSelection();CKEDITOR.env.webkit&&d()});f.on("contentDomUnload",function(){f.unlockSelection()});if(CKEDITOR.env.ie9Compat)f.on("beforeDestroy",d,null,null,9);f.on("dataReady",function(){delete f._.fakeSelection;delete f._.hiddenSelectionContainer;f.selectionChange(1)});f.on("loadSnapshot",function(){var a=f.editable().getLast(function(a){return a.type==CKEDITOR.NODE_ELEMENT});a&&a.hasAttribute("data-cke-hidden-sel")&&
a.remove()},null,null,100);f.on("key",function(a){if(f.mode=="wysiwyg"){var b=f.getSelection();if(b.isFake){var c=q[a.data.keyCode];if(c)return c({editor:f,selected:b.getSelectedElement(),selection:b,keyEvent:a})}}})});CKEDITOR.on("instanceReady",function(a){var b=a.editor;if(CKEDITOR.env.webkit){b.on("selectionChange",function(){var a=b.editable(),c=d(a);c&&(c.getCustomData("ready")?e(a):c.setCustomData("ready",1))},null,null,-1);b.on("beforeSetMode",function(){e(b.editable())},null,null,-1);var c,
f,a=function(){var a=b.editable();if(a)if(a=d(a)){var e=b.document.$.defaultView.getSelection();e.type=="Caret"&&e.anchorNode==a.$&&(f=1);c=a.getText();a.setText(g(c))}},h=function(){var a=b.editable();if(a)if(a=d(a)){a.setText(c);if(f){b.document.$.defaultView.getSelection().setPosition(a.$,a.getLength());f=0}}};b.on("beforeUndoImage",a);b.on("afterUndoImage",h);b.on("beforeGetData",a,null,null,0);b.on("getData",h)}});CKEDITOR.editor.prototype.selectionChange=function(b){(b?a:c).call(this)};CKEDITOR.editor.prototype.getSelection=
function(a){if((this._.savedSelection||this._.fakeSelection)&&!a)return this._.savedSelection||this._.fakeSelection;return(a=this.editable())&&this.mode=="wysiwyg"?new CKEDITOR.dom.selection(a):null};CKEDITOR.editor.prototype.lockSelection=function(a){a=a||this.getSelection(1);if(a.getType()!=CKEDITOR.SELECTION_NONE){!a.isLocked&&a.lock();this._.savedSelection=a;return true}return false};CKEDITOR.editor.prototype.unlockSelection=function(a){var b=this._.savedSelection;if(b){b.unlock(a);delete this._.savedSelection;
return true}return false};CKEDITOR.editor.prototype.forceNextSelectionCheck=function(){delete this._.selectionPreviousPath};CKEDITOR.dom.document.prototype.getSelection=function(){return new CKEDITOR.dom.selection(this)};CKEDITOR.dom.range.prototype.select=function(){var a=this.root instanceof CKEDITOR.editable?this.root.editor.getSelection():new CKEDITOR.dom.selection(this.root);a.selectRanges([this]);return a};CKEDITOR.SELECTION_NONE=1;CKEDITOR.SELECTION_TEXT=2;CKEDITOR.SELECTION_ELEMENT=3;var o=
typeof window.getSelection!="function",u=1;CKEDITOR.dom.selection=function(a){if(a instanceof CKEDITOR.dom.selection)var b=a,a=a.root;var c=a instanceof CKEDITOR.dom.element;this.rev=b?b.rev:u++;this.document=a instanceof CKEDITOR.dom.document?a:a.getDocument();this.root=a=c?a:this.document.getBody();this.isLocked=0;this._={cache:{}};if(b){CKEDITOR.tools.extend(this._.cache,b._.cache);this.isFake=b.isFake;this.isLocked=b.isLocked;return this}b=o?this.document.$.selection:this.document.getWindow().$.getSelection();
if(CKEDITOR.env.webkit)(b.type=="None"&&this.document.getActive().equals(a)||b.type=="Caret"&&b.anchorNode.nodeType==CKEDITOR.NODE_DOCUMENT)&&n(a,b);else if(CKEDITOR.env.gecko)b&&(this.document.getActive().equals(a)&&b.anchorNode&&b.anchorNode.nodeType==CKEDITOR.NODE_DOCUMENT)&&n(a,b,true);else if(CKEDITOR.env.ie){var d;try{d=this.document.getActive()}catch(e){}if(o)b.type=="None"&&(d&&d.equals(this.document.getDocumentElement()))&&n(a,null,true);else{(b=b&&b.anchorNode)&&(b=new CKEDITOR.dom.node(b));
d&&(d.equals(this.document.getDocumentElement())&&b&&(a.equals(b)||a.contains(b)))&&n(a,null,true)}}d=this.getNative();var f,g;if(d)if(d.getRangeAt)f=(g=d.rangeCount&&d.getRangeAt(0))&&new CKEDITOR.dom.node(g.commonAncestorContainer);else{try{g=d.createRange()}catch(h){}f=g&&CKEDITOR.dom.element.get(g.item&&g.item(0)||g.parentElement())}if(!f||!(f.type==CKEDITOR.NODE_ELEMENT||f.type==CKEDITOR.NODE_TEXT)||!this.root.equals(f)&&!this.root.contains(f)){this._.cache.type=CKEDITOR.SELECTION_NONE;this._.cache.startElement=
null;this._.cache.selectedElement=null;this._.cache.selectedText="";this._.cache.ranges=new CKEDITOR.dom.rangeList}return this};var A={img:1,hr:1,li:1,table:1,tr:1,td:1,th:1,embed:1,object:1,ol:1,ul:1,a:1,input:1,form:1,select:1,textarea:1,button:1,fieldset:1,thead:1,tfoot:1};CKEDITOR.dom.selection.prototype={getNative:function(){return this._.cache.nativeSel!==void 0?this._.cache.nativeSel:this._.cache.nativeSel=o?this.document.$.selection:this.document.getWindow().$.getSelection()},getType:o?function(){var a=
this._.cache;if(a.type)return a.type;var b=CKEDITOR.SELECTION_NONE;try{var c=this.getNative(),d=c.type;if(d=="Text")b=CKEDITOR.SELECTION_TEXT;if(d=="Control")b=CKEDITOR.SELECTION_ELEMENT;if(c.createRange().parentElement())b=CKEDITOR.SELECTION_TEXT}catch(e){}return a.type=b}:function(){var a=this._.cache;if(a.type)return a.type;var b=CKEDITOR.SELECTION_TEXT,c=this.getNative();if(!c||!c.rangeCount)b=CKEDITOR.SELECTION_NONE;else if(c.rangeCount==1){var c=c.getRangeAt(0),d=c.startContainer;if(d==c.endContainer&&
d.nodeType==1&&c.endOffset-c.startOffset==1&&A[d.childNodes[c.startOffset].nodeName.toLowerCase()])b=CKEDITOR.SELECTION_ELEMENT}return a.type=b},getRanges:function(){var a=o?function(){function a(b){return(new CKEDITOR.dom.node(b)).getIndex()}var b=function(b,c){b=b.duplicate();b.collapse(c);var d=b.parentElement();if(!d.hasChildNodes())return{container:d,offset:0};for(var e=d.children,f,g,k=b.duplicate(),j=0,h=e.length-1,w=-1,i,t;j<=h;){w=Math.floor((j+h)/2);f=e[w];k.moveToElementText(f);i=k.compareEndPoints("StartToStart",
b);if(i>0)h=w-1;else if(i<0)j=w+1;else return{container:d,offset:a(f)}}if(w==-1||w==e.length-1&&i<0){k.moveToElementText(d);k.setEndPoint("StartToStart",b);k=k.text.replace(/(\r\n|\r)/g,"\n").length;e=d.childNodes;if(!k){f=e[e.length-1];return f.nodeType!=CKEDITOR.NODE_TEXT?{container:d,offset:e.length}:{container:f,offset:f.nodeValue.length}}for(d=e.length;k>0&&d>0;){g=e[--d];if(g.nodeType==CKEDITOR.NODE_TEXT){t=g;k=k-g.nodeValue.length}}return{container:t,offset:-k}}k.collapse(i>0?true:false);k.setEndPoint(i>
0?"StartToStart":"EndToStart",b);k=k.text.replace(/(\r\n|\r)/g,"\n").length;if(!k)return{container:d,offset:a(f)+(i>0?0:1)};for(;k>0;)try{g=f[i>0?"previousSibling":"nextSibling"];if(g.nodeType==CKEDITOR.NODE_TEXT){k=k-g.nodeValue.length;t=g}f=g}catch(m){return{container:d,offset:a(f)}}return{container:t,offset:i>0?-k:t.nodeValue.length+k}};return function(){var a=this.getNative(),c=a&&a.createRange(),d=this.getType();if(!a)return[];if(d==CKEDITOR.SELECTION_TEXT){a=new CKEDITOR.dom.range(this.root);
d=b(c,true);a.setStart(new CKEDITOR.dom.node(d.container),d.offset);d=b(c);a.setEnd(new CKEDITOR.dom.node(d.container),d.offset);a.endContainer.getPosition(a.startContainer)&CKEDITOR.POSITION_PRECEDING&&a.endOffset<=a.startContainer.getIndex()&&a.collapse();return[a]}if(d==CKEDITOR.SELECTION_ELEMENT){for(var d=[],e=0;e<c.length;e++){for(var f=c.item(e),g=f.parentNode,k=0,a=new CKEDITOR.dom.range(this.root);k<g.childNodes.length&&g.childNodes[k]!=f;k++);a.setStart(new CKEDITOR.dom.node(g),k);a.setEnd(new CKEDITOR.dom.node(g),
k+1);d.push(a)}return d}return[]}}():function(){var a=[],b,c=this.getNative();if(!c)return a;for(var d=0;d<c.rangeCount;d++){var e=c.getRangeAt(d);b=new CKEDITOR.dom.range(this.root);b.setStart(new CKEDITOR.dom.node(e.startContainer),e.startOffset);b.setEnd(new CKEDITOR.dom.node(e.endContainer),e.endOffset);a.push(b)}return a};return function(b){var c=this._.cache,d=c.ranges;if(!d)c.ranges=d=new CKEDITOR.dom.rangeList(a.call(this));return!b?d:m(new CKEDITOR.dom.rangeList(d.slice()))}}(),getStartElement:function(){var a=
this._.cache;if(a.startElement!==void 0)return a.startElement;var b;switch(this.getType()){case CKEDITOR.SELECTION_ELEMENT:return this.getSelectedElement();case CKEDITOR.SELECTION_TEXT:var c=this.getRanges()[0];if(c){if(c.collapsed){b=c.startContainer;b.type!=CKEDITOR.NODE_ELEMENT&&(b=b.getParent())}else{for(c.optimize();;){b=c.startContainer;if(c.startOffset==(b.getChildCount?b.getChildCount():b.getLength())&&!b.isBlockBoundary())c.setStartAfter(b);else break}b=c.startContainer;if(b.type!=CKEDITOR.NODE_ELEMENT)return b.getParent();
b=b.getChild(c.startOffset);if(!b||b.type!=CKEDITOR.NODE_ELEMENT)b=c.startContainer;else for(c=b.getFirst();c&&c.type==CKEDITOR.NODE_ELEMENT;){b=c;c=c.getFirst()}}b=b.$}}return a.startElement=b?new CKEDITOR.dom.element(b):null},getSelectedElement:function(){var a=this._.cache;if(a.selectedElement!==void 0)return a.selectedElement;var b=this,c=CKEDITOR.tools.tryThese(function(){return b.getNative().createRange().item(0)},function(){for(var a=b.getRanges()[0].clone(),c,d,e=2;e&&(!(c=a.getEnclosedNode())||
!(c.type==CKEDITOR.NODE_ELEMENT&&A[c.getName()]&&(d=c)));e--)a.shrink(CKEDITOR.SHRINK_ELEMENT);return d&&d.$});return a.selectedElement=c?new CKEDITOR.dom.element(c):null},getSelectedText:function(){var a=this._.cache;if(a.selectedText!==void 0)return a.selectedText;var b=this.getNative(),b=o?b.type=="Control"?"":b.createRange().text:b.toString();return a.selectedText=b},lock:function(){this.getRanges();this.getStartElement();this.getSelectedElement();this.getSelectedText();this._.cache.nativeSel=
null;this.isLocked=1},unlock:function(a){if(this.isLocked){if(a)var b=this.getSelectedElement(),c=!b&&this.getRanges(),d=this.isFake;this.isLocked=0;this.reset();if(a)(a=b||c[0]&&c[0].getCommonAncestor())&&a.getAscendant("body",1)&&(d?this.fake(b):b?this.selectElement(b):this.selectRanges(c))}},reset:function(){this._.cache={};this.isFake=0;var a=this.root.editor;if(a&&a._.fakeSelection&&this.rev==a._.fakeSelection.rev){delete a._.fakeSelection;var b=a._.hiddenSelectionContainer;if(b){var c=a.checkDirty();
a.fire("lockSnapshot");b.remove();a.fire("unlockSnapshot");!c&&a.resetDirty()}delete a._.hiddenSelectionContainer}this.rev=u++},selectElement:function(a){var b=new CKEDITOR.dom.range(this.root);b.setStartBefore(a);b.setEndAfter(a);this.selectRanges([b])},selectRanges:function(a){var b=this.root.editor,b=b&&b._.hiddenSelectionContainer;this.reset();if(b)for(var b=this.root,c,d=0;d<a.length;++d){c=a[d];if(c.endContainer.equals(b))c.endOffset=Math.min(c.endOffset,b.getChildCount())}if(a.length)if(this.isLocked){var g=
CKEDITOR.document.getActive();this.unlock();this.selectRanges(a);this.lock();!g.equals(this.root)&&g.focus()}else{var h;a:{var i,m;if(a.length==1&&!(m=a[0]).collapsed&&(h=m.getEnclosedNode())&&h.type==CKEDITOR.NODE_ELEMENT){m=m.clone();m.shrink(CKEDITOR.SHRINK_ELEMENT,true);if((i=m.getEnclosedNode())&&i.type==CKEDITOR.NODE_ELEMENT)h=i;if(h.getAttribute("contenteditable")=="false")break a}h=void 0}if(h)this.fake(h);else{if(o){m=CKEDITOR.dom.walker.whitespaces(true);i=/\ufeff|\u00a0/;b={table:1,tbody:1,
tr:1};if(a.length>1){h=a[a.length-1];a[0].setEnd(h.endContainer,h.endOffset)}h=a[0];var a=h.collapsed,n,q,p;if((c=h.getEnclosedNode())&&c.type==CKEDITOR.NODE_ELEMENT&&c.getName()in A&&(!c.is("a")||!c.getText()))try{p=c.$.createControlRange();p.addElement(c.$);p.select();return}catch(s){}if(h.startContainer.type==CKEDITOR.NODE_ELEMENT&&h.startContainer.getName()in b||h.endContainer.type==CKEDITOR.NODE_ELEMENT&&h.endContainer.getName()in b){h.shrink(CKEDITOR.NODE_ELEMENT,true);a=h.collapsed}p=h.createBookmark();
b=p.startNode;if(!a)g=p.endNode;p=h.document.$.body.createTextRange();p.moveToElementText(b.$);p.moveStart("character",1);if(g){i=h.document.$.body.createTextRange();i.moveToElementText(g.$);p.setEndPoint("EndToEnd",i);p.moveEnd("character",-1)}else{n=b.getNext(m);q=b.hasAscendant("pre");n=!(n&&n.getText&&n.getText().match(i))&&(q||!b.hasPrevious()||b.getPrevious().is&&b.getPrevious().is("br"));q=h.document.createElement("span");q.setHtml("&#65279;");q.insertBefore(b);n&&h.document.createText("﻿").insertBefore(b)}h.setStartBefore(b);
b.remove();if(a){if(n){p.moveStart("character",-1);p.select();h.document.$.selection.clear()}else p.select();h.moveToPosition(q,CKEDITOR.POSITION_BEFORE_START);q.remove()}else{h.setEndBefore(g);g.remove();p.select()}}else{g=this.getNative();if(!g)return;this.removeAllRanges();for(p=0;p<a.length;p++){if(p<a.length-1){n=a[p];q=a[p+1];i=n.clone();i.setStart(n.endContainer,n.endOffset);i.setEnd(q.startContainer,q.startOffset);if(!i.collapsed){i.shrink(CKEDITOR.NODE_ELEMENT,true);h=i.getCommonAncestor();
i=i.getEnclosedNode();if(h.isReadOnly()||i&&i.isReadOnly()){q.setStart(n.startContainer,n.startOffset);a.splice(p--,1);continue}}}h=a[p];q=this.document.$.createRange();if(h.collapsed&&CKEDITOR.env.webkit&&f(h)){n=this.root;e(n,false);i=n.getDocument().createText("​");n.setCustomData("cke-fillingChar",i);h.insertNode(i);if((n=i.getNext())&&!i.getPrevious()&&n.type==CKEDITOR.NODE_ELEMENT&&n.getName()=="br"){e(this.root);h.moveToPosition(n,CKEDITOR.POSITION_BEFORE_START)}else h.moveToPosition(i,CKEDITOR.POSITION_AFTER_END)}q.setStart(h.startContainer.$,
h.startOffset);try{q.setEnd(h.endContainer.$,h.endOffset)}catch(w){if(w.toString().indexOf("NS_ERROR_ILLEGAL_VALUE")>=0){h.collapse(1);q.setEnd(h.endContainer.$,h.endOffset)}else throw w;}g.addRange(q)}}this.reset();this.root.fire("selectionchange")}}},fake:function(a){var b=this.root.editor;this.reset();h(b);var c=this._.cache,d=new CKEDITOR.dom.range(this.root);d.setStartBefore(a);d.setEndAfter(a);c.ranges=new CKEDITOR.dom.rangeList(d);c.selectedElement=c.startElement=a;c.type=CKEDITOR.SELECTION_ELEMENT;
c.selectedText=c.nativeSel=null;this.isFake=1;this.rev=u++;b._.fakeSelection=this;this.root.fire("selectionchange")},isHidden:function(){var a=this.getCommonAncestor();a&&a.type==CKEDITOR.NODE_TEXT&&(a=a.getParent());return!(!a||!a.data("cke-hidden-sel"))},createBookmarks:function(a){a=this.getRanges().createBookmarks(a);this.isFake&&(a.isFake=1);return a},createBookmarks2:function(a){a=this.getRanges().createBookmarks2(a);this.isFake&&(a.isFake=1);return a},selectBookmarks:function(a){for(var b=
[],c=0;c<a.length;c++){var d=new CKEDITOR.dom.range(this.root);d.moveToBookmark(a[c]);b.push(d)}a.isFake?this.fake(b[0].getEnclosedNode()):this.selectRanges(b);return this},getCommonAncestor:function(){var a=this.getRanges();return!a.length?null:a[0].startContainer.getCommonAncestor(a[a.length-1].endContainer)},scrollIntoView:function(){this.type!=CKEDITOR.SELECTION_NONE&&this.getRanges()[0].scrollIntoView()},removeAllRanges:function(){if(this.getType()!=CKEDITOR.SELECTION_NONE){var a=this.getNative();
try{a&&a[o?"empty":"removeAllRanges"]()}catch(b){}this.reset()}}}})();"use strict";CKEDITOR.STYLE_BLOCK=1;CKEDITOR.STYLE_INLINE=2;CKEDITOR.STYLE_OBJECT=3;
(function(){function a(a,b){for(var c,d;a=a.getParent();){if(a.equals(b))break;if(a.getAttribute("data-nostyle"))c=a;else if(!d){var e=a.getAttribute("contentEditable");e=="false"?c=a:e=="true"&&(d=1)}}return c}function c(b){var d=b.document;if(b.collapsed){d=u(this,d);b.insertNode(d);b.moveToPosition(d,CKEDITOR.POSITION_BEFORE_END)}else{var e=this.element,g=this._.definition,h,i=g.ignoreReadonly,j=i||g.includeReadonly;j==void 0&&(j=b.root.getCustomData("cke_includeReadonly"));var k=CKEDITOR.dtd[e];
if(!k){h=true;k=CKEDITOR.dtd.span}b.enlarge(CKEDITOR.ENLARGE_INLINE,1);b.trim();var m=b.createBookmark(),l=m.startNode,n=m.endNode,p=l,q;if(!i){var o=b.getCommonAncestor(),i=a(l,o),o=a(n,o);i&&(p=i.getNextSourceNode(true));o&&(n=o)}for(p.getPosition(n)==CKEDITOR.POSITION_FOLLOWING&&(p=0);p;){i=false;if(p.equals(n)){p=null;i=true}else{var s=p.type==CKEDITOR.NODE_ELEMENT?p.getName():null,o=s&&p.getAttribute("contentEditable")=="false",r=s&&p.getAttribute("data-nostyle");if(s&&p.data("cke-bookmark")){p=
p.getNextSourceNode(true);continue}if(o&&j&&CKEDITOR.dtd.$block[s])for(var v=p,A=f(v),D=void 0,I=A.length,O=0,v=I&&new CKEDITOR.dom.range(v.getDocument());O<I;++O){var D=A[O],S=CKEDITOR.filter.instances[D.data("cke-filter")];if(S?S.check(this):1){v.selectNodeContents(D);c.call(this,v)}}A=s?!k[s]||r?0:o&&!j?0:(p.getPosition(n)|L)==L&&(!g.childRule||g.childRule(p)):1;if(A)if((A=p.getParent())&&((A.getDtd()||CKEDITOR.dtd.span)[e]||h)&&(!g.parentRule||g.parentRule(A))){if(!q&&(!s||!CKEDITOR.dtd.$removeEmpty[s]||
(p.getPosition(n)|L)==L)){q=b.clone();q.setStartBefore(p)}s=p.type;if(s==CKEDITOR.NODE_TEXT||o||s==CKEDITOR.NODE_ELEMENT&&!p.getChildCount()){for(var s=p,P;(i=!s.getNext(F))&&(P=s.getParent(),k[P.getName()])&&(P.getPosition(l)|J)==J&&(!g.childRule||g.childRule(P));)s=P;q.setEndAfter(s)}}else i=true;else i=true;p=p.getNextSourceNode(r||o)}if(i&&q&&!q.collapsed){for(var i=u(this,d),o=i.hasAttributes(),r=q.getCommonAncestor(),s={},A={},D={},I={},V,R,Y;i&&r;){if(r.getName()==e){for(V in g.attributes)if(!I[V]&&
(Y=r.getAttribute(R)))i.getAttribute(V)==Y?A[V]=1:I[V]=1;for(R in g.styles)if(!D[R]&&(Y=r.getStyle(R)))i.getStyle(R)==Y?s[R]=1:D[R]=1}r=r.getParent()}for(V in A)i.removeAttribute(V);for(R in s)i.removeStyle(R);o&&!i.hasAttributes()&&(i=null);if(i){q.extractContents().appendTo(i);q.insertNode(i);x.call(this,i);i.mergeSiblings();CKEDITOR.env.ie||i.$.normalize()}else{i=new CKEDITOR.dom.element("span");q.extractContents().appendTo(i);q.insertNode(i);x.call(this,i);i.remove(true)}q=null}}b.moveToBookmark(m);
b.shrink(CKEDITOR.SHRINK_TEXT);b.shrink(CKEDITOR.NODE_ELEMENT,true)}}function b(a){function b(){for(var a=new CKEDITOR.dom.elementPath(d.getParent()),c=new CKEDITOR.dom.elementPath(j.getParent()),e=null,f=null,g=0;g<a.elements.length;g++){var h=a.elements[g];if(h==a.block||h==a.blockLimit)break;k.checkElementRemovable(h)&&(e=h)}for(g=0;g<c.elements.length;g++){h=c.elements[g];if(h==c.block||h==c.blockLimit)break;k.checkElementRemovable(h)&&(f=h)}f&&j.breakParent(f);e&&d.breakParent(e)}a.enlarge(CKEDITOR.ENLARGE_INLINE,
1);var c=a.createBookmark(),d=c.startNode;if(a.collapsed){for(var e=new CKEDITOR.dom.elementPath(d.getParent(),a.root),f,g=0,h;g<e.elements.length&&(h=e.elements[g]);g++){if(h==e.block||h==e.blockLimit)break;if(this.checkElementRemovable(h)){var i;if(a.collapsed&&(a.checkBoundaryOfElement(h,CKEDITOR.END)||(i=a.checkBoundaryOfElement(h,CKEDITOR.START)))){f=h;f.match=i?"start":"end"}else{h.mergeSiblings();h.is(this.element)?s.call(this,h):q(h,l(this)[h.getName()])}}}if(f){h=d;for(g=0;;g++){i=e.elements[g];
if(i.equals(f))break;else if(i.match)continue;else i=i.clone();i.append(h);h=i}h[f.match=="start"?"insertBefore":"insertAfter"](f)}}else{var j=c.endNode,k=this;b();for(e=d;!e.equals(j);){f=e.getNextSourceNode();if(e.type==CKEDITOR.NODE_ELEMENT&&this.checkElementRemovable(e)){e.getName()==this.element?s.call(this,e):q(e,l(this)[e.getName()]);if(f.type==CKEDITOR.NODE_ELEMENT&&f.contains(d)){b();f=d.getNext()}}e=f}}a.moveToBookmark(c);a.shrink(CKEDITOR.NODE_ELEMENT,true)}function f(a){var b=[];a.forEach(function(a){if(a.getAttribute("contenteditable")==
"true"){b.push(a);return false}},CKEDITOR.NODE_ELEMENT,true);return b}function d(a){var b=a.getEnclosedNode()||a.getCommonAncestor(false,true);(a=(new CKEDITOR.dom.elementPath(b,a.root)).contains(this.element,1))&&!a.isReadOnly()&&A(a,this)}function e(a){var b=a.getCommonAncestor(true,true);if(a=(new CKEDITOR.dom.elementPath(b,a.root)).contains(this.element,1)){var b=this._.definition,c=b.attributes;if(c)for(var d in c)a.removeAttribute(d,c[d]);if(b.styles)for(var e in b.styles)b.styles.hasOwnProperty(e)&&
a.removeStyle(e)}}function g(a){var b=a.createBookmark(true),c=a.createIterator();c.enforceRealBlocks=true;if(this._.enterMode)c.enlargeBr=this._.enterMode!=CKEDITOR.ENTER_BR;for(var d,e=a.document,f;d=c.getNextParagraph();)if(!d.isReadOnly()&&(c.activeFilter?c.activeFilter.check(this):1)){f=u(this,e,d);h(d,f)}a.moveToBookmark(b)}function n(a){var b=a.createBookmark(1),c=a.createIterator();c.enforceRealBlocks=true;c.enlargeBr=this._.enterMode!=CKEDITOR.ENTER_BR;for(var d,e;d=c.getNextParagraph();)if(this.checkElementRemovable(d))if(d.is("pre")){(e=
this._.enterMode==CKEDITOR.ENTER_BR?null:a.document.createElement(this._.enterMode==CKEDITOR.ENTER_P?"p":"div"))&&d.copyAttributes(e);h(d,e)}else s.call(this,d);a.moveToBookmark(b)}function h(a,b){var c=!b;if(c){b=a.getDocument().createElement("div");a.copyAttributes(b)}var d=b&&b.is("pre"),e=a.is("pre"),f=!d&&e;if(d&&!e){e=b;(f=a.getBogus())&&f.remove();f=a.getHtml();f=m(f,/(?:^[ \t\n\r]+)|(?:[ \t\n\r]+$)/g,"");f=f.replace(/[ \t\r\n]*(<br[^>]*>)[ \t\r\n]*/gi,"$1");f=f.replace(/([ \t\n\r]+|&nbsp;)/g,
" ");f=f.replace(/<br\b[^>]*>/gi,"\n");if(CKEDITOR.env.ie){var g=a.getDocument().createElement("div");g.append(e);e.$.outerHTML="<pre>"+f+"</pre>";e.copyAttributes(g.getFirst());e=g.getFirst().remove()}else e.setHtml(f);b=e}else f?b=p(c?[a.getHtml()]:i(a),b):a.moveChildren(b);b.replace(a);if(d){var c=b,h;if((h=c.getPrevious(D))&&h.type==CKEDITOR.NODE_ELEMENT&&h.is("pre")){d=m(h.getHtml(),/\n$/,"")+"\n\n"+m(c.getHtml(),/^\n/,"");CKEDITOR.env.ie?c.$.outerHTML="<pre>"+d+"</pre>":c.setHtml(d);h.remove()}}else c&&
o(b)}function i(a){a.getName();var b=[];m(a.getOuterHtml(),/(\S\s*)\n(?:\s|(<span[^>]+data-cke-bookmark.*?\/span>))*\n(?!$)/gi,function(a,b,c){return b+"</pre>"+c+"<pre>"}).replace(/<pre\b.*?>([\s\S]*?)<\/pre>/gi,function(a,c){b.push(c)});return b}function m(a,b,c){var d="",e="",a=a.replace(/(^<span[^>]+data-cke-bookmark.*?\/span>)|(<span[^>]+data-cke-bookmark.*?\/span>$)/gi,function(a,b,c){b&&(d=b);c&&(e=c);return""});return d+a.replace(b,c)+e}function p(a,b){var c;a.length>1&&(c=new CKEDITOR.dom.documentFragment(b.getDocument()));
for(var d=0;d<a.length;d++){var e=a[d],e=e.replace(/(\r\n|\r)/g,"\n"),e=m(e,/^[ \t]*\n/,""),e=m(e,/\n$/,""),e=m(e,/^[ \t]+|[ \t]+$/g,function(a,b){return a.length==1?"&nbsp;":b?" "+CKEDITOR.tools.repeat("&nbsp;",a.length-1):CKEDITOR.tools.repeat("&nbsp;",a.length-1)+" "}),e=e.replace(/\n/g,"<br>"),e=e.replace(/[ \t]{2,}/g,function(a){return CKEDITOR.tools.repeat("&nbsp;",a.length-1)+" "});if(c){var f=b.clone();f.setHtml(e);c.append(f)}else b.setHtml(e)}return c||b}function s(a,b){var c=this._.definition,
d=c.attributes,c=c.styles,e=l(this)[a.getName()],f=CKEDITOR.tools.isEmpty(d)&&CKEDITOR.tools.isEmpty(c),g;for(g in d)if(!((g=="class"||this._.definition.fullMatch)&&a.getAttribute(g)!=j(g,d[g]))&&!(b&&g.slice(0,5)=="data-")){f=a.hasAttribute(g);a.removeAttribute(g)}for(var h in c)if(!(this._.definition.fullMatch&&a.getStyle(h)!=j(h,c[h],true))){f=f||!!a.getStyle(h);a.removeStyle(h)}q(a,e,I[a.getName()]);f&&(this._.definition.alwaysRemoveElement?o(a,1):!CKEDITOR.dtd.$block[a.getName()]||this._.enterMode==
CKEDITOR.ENTER_BR&&!a.hasAttributes()?o(a):a.renameNode(this._.enterMode==CKEDITOR.ENTER_P?"p":"div"))}function x(a){for(var b=l(this),c=a.getElementsByTag(this.element),d,e=c.count();--e>=0;){d=c.getItem(e);d.isReadOnly()||s.call(this,d,true)}for(var f in b)if(f!=this.element){c=a.getElementsByTag(f);for(e=c.count()-1;e>=0;e--){d=c.getItem(e);d.isReadOnly()||q(d,b[f])}}}function q(a,b,c){if(b=b&&b.attributes)for(var d=0;d<b.length;d++){var e=b[d][0],f;if(f=a.getAttribute(e)){var g=b[d][1];(g===null||
g.test&&g.test(f)||typeof g=="string"&&f==g)&&a.removeAttribute(e)}}c||o(a)}function o(a,b){if(!a.hasAttributes()||b)if(CKEDITOR.dtd.$block[a.getName()]){var c=a.getPrevious(D),d=a.getNext(D);c&&(c.type==CKEDITOR.NODE_TEXT||!c.isBlockBoundary({br:1}))&&a.append("br",1);d&&(d.type==CKEDITOR.NODE_TEXT||!d.isBlockBoundary({br:1}))&&a.append("br");a.remove(true)}else{c=a.getFirst();d=a.getLast();a.remove(true);if(c){c.type==CKEDITOR.NODE_ELEMENT&&c.mergeSiblings();d&&(!c.equals(d)&&d.type==CKEDITOR.NODE_ELEMENT)&&
d.mergeSiblings()}}}function u(a,b,c){var d;d=a.element;d=="*"&&(d="span");d=new CKEDITOR.dom.element(d,b);c&&c.copyAttributes(d);d=A(d,a);b.getCustomData("doc_processing_style")&&d.hasAttribute("id")?d.removeAttribute("id"):b.setCustomData("doc_processing_style",1);return d}function A(a,b){var c=b._.definition,d=c.attributes,c=CKEDITOR.style.getStyleText(c);if(d)for(var e in d)a.setAttribute(e,d[e]);c&&a.setAttribute("style",c);return a}function k(a,b){for(var c in a)a[c]=a[c].replace(S,function(a,
c){return b[c]})}function l(a){if(a._.overrides)return a._.overrides;var b=a._.overrides={},c=a._.definition.overrides;if(c){CKEDITOR.tools.isArray(c)||(c=[c]);for(var d=0;d<c.length;d++){var e=c[d],f,g;if(typeof e=="string")f=e.toLowerCase();else{f=e.element?e.element.toLowerCase():a.element;g=e.attributes}e=b[f]||(b[f]={});if(g){var e=e.attributes=e.attributes||[],h;for(h in g)e.push([h.toLowerCase(),g[h]])}}}return b}function j(a,b,c){var d=new CKEDITOR.dom.element("span");d[c?"setStyle":"setAttribute"](a,
b);return d[c?"getStyle":"getAttribute"](a)}function v(a,b,c){for(var d=a.document,e=a.getRanges(),b=b?this.removeFromRange:this.applyToRange,f,g=e.createIterator();f=g.getNextRange();)b.call(this,f,c);a.selectRanges(e);d.removeCustomData("doc_processing_style")}var I={address:1,div:1,h1:1,h2:1,h3:1,h4:1,h5:1,h6:1,p:1,pre:1,section:1,header:1,footer:1,nav:1,article:1,aside:1,figure:1,dialog:1,hgroup:1,time:1,meter:1,menu:1,command:1,keygen:1,output:1,progress:1,details:1,datagrid:1,datalist:1},r=
{a:1,blockquote:1,embed:1,hr:1,img:1,li:1,object:1,ol:1,table:1,td:1,tr:1,th:1,ul:1,dl:1,dt:1,dd:1,form:1,audio:1,video:1},O=/\s*(?:;\s*|$)/,S=/#\((.+?)\)/g,F=CKEDITOR.dom.walker.bookmark(0,1),D=CKEDITOR.dom.walker.whitespaces(1);CKEDITOR.style=function(a,b){if(typeof a.type=="string")return new CKEDITOR.style.customHandlers[a.type](a);var c=a.attributes;if(c&&c.style){a.styles=CKEDITOR.tools.extend({},a.styles,CKEDITOR.tools.parseCssText(c.style));delete c.style}if(b){a=CKEDITOR.tools.clone(a);k(a.attributes,
b);k(a.styles,b)}c=this.element=a.element?typeof a.element=="string"?a.element.toLowerCase():a.element:"*";this.type=a.type||(I[c]?CKEDITOR.STYLE_BLOCK:r[c]?CKEDITOR.STYLE_OBJECT:CKEDITOR.STYLE_INLINE);if(typeof this.element=="object")this.type=CKEDITOR.STYLE_OBJECT;this._={definition:a}};CKEDITOR.style.prototype={apply:function(a){if(a instanceof CKEDITOR.dom.document)return v.call(this,a.getSelection());if(this.checkApplicable(a.elementPath(),a)){var b=this._.enterMode;if(!b)this._.enterMode=a.activeEnterMode;
v.call(this,a.getSelection(),0,a);this._.enterMode=b}},remove:function(a){if(a instanceof CKEDITOR.dom.document)return v.call(this,a.getSelection(),1);if(this.checkApplicable(a.elementPath(),a)){var b=this._.enterMode;if(!b)this._.enterMode=a.activeEnterMode;v.call(this,a.getSelection(),1,a);this._.enterMode=b}},applyToRange:function(a){this.applyToRange=this.type==CKEDITOR.STYLE_INLINE?c:this.type==CKEDITOR.STYLE_BLOCK?g:this.type==CKEDITOR.STYLE_OBJECT?d:null;return this.applyToRange(a)},removeFromRange:function(a){this.removeFromRange=
this.type==CKEDITOR.STYLE_INLINE?b:this.type==CKEDITOR.STYLE_BLOCK?n:this.type==CKEDITOR.STYLE_OBJECT?e:null;return this.removeFromRange(a)},applyToObject:function(a){A(a,this)},checkActive:function(a,b){switch(this.type){case CKEDITOR.STYLE_BLOCK:return this.checkElementRemovable(a.block||a.blockLimit,true,b);case CKEDITOR.STYLE_OBJECT:case CKEDITOR.STYLE_INLINE:for(var c=a.elements,d=0,e;d<c.length;d++){e=c[d];if(!(this.type==CKEDITOR.STYLE_INLINE&&(e==a.block||e==a.blockLimit))){if(this.type==
CKEDITOR.STYLE_OBJECT){var f=e.getName();if(!(typeof this.element=="string"?f==this.element:f in this.element))continue}if(this.checkElementRemovable(e,true,b))return true}}}return false},checkApplicable:function(a,b,c){b&&b instanceof CKEDITOR.filter&&(c=b);if(c&&!c.check(this))return false;switch(this.type){case CKEDITOR.STYLE_OBJECT:return!!a.contains(this.element);case CKEDITOR.STYLE_BLOCK:return!!a.blockLimit.getDtd()[this.element]}return true},checkElementMatch:function(a,b){var c=this._.definition;
if(!a||!c.ignoreReadonly&&a.isReadOnly())return false;var d=a.getName();if(typeof this.element=="string"?d==this.element:d in this.element){if(!b&&!a.hasAttributes())return true;if(d=c._AC)c=d;else{var d={},e=0,f=c.attributes;if(f)for(var g in f){e++;d[g]=f[g]}if(g=CKEDITOR.style.getStyleText(c)){d.style||e++;d.style=g}d._length=e;c=c._AC=d}if(c._length){for(var h in c)if(h!="_length"){e=a.getAttribute(h)||"";if(h=="style")a:{d=c[h];typeof d=="string"&&(d=CKEDITOR.tools.parseCssText(d));typeof e==
"string"&&(e=CKEDITOR.tools.parseCssText(e,true));g=void 0;for(g in d)if(!(g in e&&(e[g]==d[g]||d[g]=="inherit"||e[g]=="inherit"))){d=false;break a}d=true}else d=c[h]==e;if(d){if(!b)return true}else if(b)return false}if(b)return true}else return true}return false},checkElementRemovable:function(a,b,c){if(this.checkElementMatch(a,b,c))return true;if(b=l(this)[a.getName()]){var d;if(!(b=b.attributes))return true;for(c=0;c<b.length;c++){d=b[c][0];if(d=a.getAttribute(d)){var e=b[c][1];if(e===null||typeof e==
"string"&&d==e||e.test(d))return true}}}return false},buildPreview:function(a){var b=this._.definition,c=[],d=b.element;d=="bdo"&&(d="span");var c=["<",d],e=b.attributes;if(e)for(var f in e)c.push(" ",f,'="',e[f],'"');(e=CKEDITOR.style.getStyleText(b))&&c.push(' style="',e,'"');c.push(">",a||b.name,"</",d,">");return c.join("")},getDefinition:function(){return this._.definition}};CKEDITOR.style.getStyleText=function(a){var b=a._ST;if(b)return b;var b=a.styles,c=a.attributes&&a.attributes.style||"",
d="";c.length&&(c=c.replace(O,";"));for(var e in b){var f=b[e],g=(e+":"+f).replace(O,";");f=="inherit"?d=d+g:c=c+g}c.length&&(c=CKEDITOR.tools.normalizeCssText(c,true));return a._ST=c+d};CKEDITOR.style.customHandlers={};CKEDITOR.style.addCustomHandler=function(a){var b=function(a){this._={definition:a};this.setup&&this.setup(a)};b.prototype=CKEDITOR.tools.extend(CKEDITOR.tools.prototypedCopy(CKEDITOR.style.prototype),{assignedTo:CKEDITOR.STYLE_OBJECT},a,true);return this.customHandlers[a.type]=b};
var L=CKEDITOR.POSITION_PRECEDING|CKEDITOR.POSITION_IDENTICAL|CKEDITOR.POSITION_IS_CONTAINED,J=CKEDITOR.POSITION_FOLLOWING|CKEDITOR.POSITION_IDENTICAL|CKEDITOR.POSITION_IS_CONTAINED})();CKEDITOR.styleCommand=function(a,c){this.requiredContent=this.allowedContent=this.style=a;CKEDITOR.tools.extend(this,c,true)};CKEDITOR.styleCommand.prototype.exec=function(a){a.focus();this.state==CKEDITOR.TRISTATE_OFF?a.applyStyle(this.style):this.state==CKEDITOR.TRISTATE_ON&&a.removeStyle(this.style)};
CKEDITOR.stylesSet=new CKEDITOR.resourceManager("","stylesSet");CKEDITOR.addStylesSet=CKEDITOR.tools.bind(CKEDITOR.stylesSet.add,CKEDITOR.stylesSet);CKEDITOR.loadStylesSet=function(a,c,b){CKEDITOR.stylesSet.addExternal(a,c,"");CKEDITOR.stylesSet.load(a,b)};
CKEDITOR.tools.extend(CKEDITOR.editor.prototype,{attachStyleStateChange:function(a,c){var b=this._.styleStateChangeCallbacks;if(!b){b=this._.styleStateChangeCallbacks=[];this.on("selectionChange",function(a){for(var c=0;c<b.length;c++){var e=b[c],g=e.style.checkActive(a.data.path,this)?CKEDITOR.TRISTATE_ON:CKEDITOR.TRISTATE_OFF;e.fn.call(this,g)}})}b.push({style:a,fn:c})},applyStyle:function(a){a.apply(this)},removeStyle:function(a){a.remove(this)},getStylesSet:function(a){if(this._.stylesDefinitions)a(this._.stylesDefinitions);
else{var c=this,b=c.config.stylesCombo_stylesSet||c.config.stylesSet;if(b===false)a(null);else if(b instanceof Array){c._.stylesDefinitions=b;a(b)}else{b||(b="default");var b=b.split(":"),f=b[0];CKEDITOR.stylesSet.addExternal(f,b[1]?b.slice(1).join(":"):CKEDITOR.getUrl("styles.js"),"");CKEDITOR.stylesSet.load(f,function(b){c._.stylesDefinitions=b[f];a(c._.stylesDefinitions)})}}}});
CKEDITOR.dom.comment=function(a,c){typeof a=="string"&&(a=(c?c.$:document).createComment(a));CKEDITOR.dom.domObject.call(this,a)};CKEDITOR.dom.comment.prototype=new CKEDITOR.dom.node;CKEDITOR.tools.extend(CKEDITOR.dom.comment.prototype,{type:CKEDITOR.NODE_COMMENT,getOuterHtml:function(){return"<\!--"+this.$.nodeValue+"--\>"}});"use strict";
(function(){var a={},c={},b;for(b in CKEDITOR.dtd.$blockLimit)b in CKEDITOR.dtd.$list||(a[b]=1);for(b in CKEDITOR.dtd.$block)b in CKEDITOR.dtd.$blockLimit||b in CKEDITOR.dtd.$empty||(c[b]=1);CKEDITOR.dom.elementPath=function(b,d){var e=null,g=null,n=[],h=b,i,d=d||b.getDocument().getBody();do if(h.type==CKEDITOR.NODE_ELEMENT){n.push(h);if(!this.lastElement){this.lastElement=h;if(h.is(CKEDITOR.dtd.$object)||h.getAttribute("contenteditable")=="false")continue}if(h.equals(d))break;if(!g){i=h.getName();
h.getAttribute("contenteditable")=="true"?g=h:!e&&c[i]&&(e=h);if(a[i]){var m;if(m=!e){if(i=i=="div"){a:{i=h.getChildren();m=0;for(var p=i.count();m<p;m++){var s=i.getItem(m);if(s.type==CKEDITOR.NODE_ELEMENT&&CKEDITOR.dtd.$block[s.getName()]){i=true;break a}}i=false}i=!i}m=i}m?e=h:g=h}}}while(h=h.getParent());g||(g=d);this.block=e;this.blockLimit=g;this.root=d;this.elements=n}})();
CKEDITOR.dom.elementPath.prototype={compare:function(a){var c=this.elements,a=a&&a.elements;if(!a||c.length!=a.length)return false;for(var b=0;b<c.length;b++)if(!c[b].equals(a[b]))return false;return true},contains:function(a,c,b){var f;typeof a=="string"&&(f=function(b){return b.getName()==a});a instanceof CKEDITOR.dom.element?f=function(b){return b.equals(a)}:CKEDITOR.tools.isArray(a)?f=function(b){return CKEDITOR.tools.indexOf(a,b.getName())>-1}:typeof a=="function"?f=a:typeof a=="object"&&(f=
function(b){return b.getName()in a});var d=this.elements,e=d.length;c&&e--;if(b){d=Array.prototype.slice.call(d,0);d.reverse()}for(c=0;c<e;c++)if(f(d[c]))return d[c];return null},isContextFor:function(a){var c;if(a in CKEDITOR.dtd.$block){c=this.contains(CKEDITOR.dtd.$intermediate)||this.root.equals(this.block)&&this.block||this.blockLimit;return!!c.getDtd()[a]}return true},direction:function(){return(this.block||this.blockLimit||this.root).getDirection(1)}};
CKEDITOR.dom.text=function(a,c){typeof a=="string"&&(a=(c?c.$:document).createTextNode(a));this.$=a};CKEDITOR.dom.text.prototype=new CKEDITOR.dom.node;
CKEDITOR.tools.extend(CKEDITOR.dom.text.prototype,{type:CKEDITOR.NODE_TEXT,getLength:function(){return this.$.nodeValue.length},getText:function(){return this.$.nodeValue},setText:function(a){this.$.nodeValue=a},split:function(a){var c=this.$.parentNode,b=c.childNodes.length,f=this.getLength(),d=this.getDocument(),e=new CKEDITOR.dom.text(this.$.splitText(a),d);if(c.childNodes.length==b)if(a>=f){e=d.createText("");e.insertAfter(this)}else{a=d.createText("");a.insertAfter(e);a.remove()}return e},substring:function(a,
c){return typeof c!="number"?this.$.nodeValue.substr(a):this.$.nodeValue.substring(a,c)}});
(function(){function a(a,c,d){var e=a.serializable,g=c[d?"endContainer":"startContainer"],n=d?"endOffset":"startOffset",h=e?c.document.getById(a.startNode):a.startNode,a=e?c.document.getById(a.endNode):a.endNode;if(g.equals(h.getPrevious())){c.startOffset=c.startOffset-g.getLength()-a.getPrevious().getLength();g=a.getNext()}else if(g.equals(a.getPrevious())){c.startOffset=c.startOffset-g.getLength();g=a.getNext()}g.equals(h.getParent())&&c[n]++;g.equals(a.getParent())&&c[n]++;c[d?"endContainer":"startContainer"]=
g;return c}CKEDITOR.dom.rangeList=function(a){if(a instanceof CKEDITOR.dom.rangeList)return a;a?a instanceof CKEDITOR.dom.range&&(a=[a]):a=[];return CKEDITOR.tools.extend(a,c)};var c={createIterator:function(){var a=this,c=CKEDITOR.dom.walker.bookmark(),d=[],e;return{getNextRange:function(g){e=e==void 0?0:e+1;var n=a[e];if(n&&a.length>1){if(!e)for(var h=a.length-1;h>=0;h--)d.unshift(a[h].createBookmark(true));if(g)for(var i=0;a[e+i+1];){for(var m=n.document,g=0,h=m.getById(d[i].endNode),m=m.getById(d[i+
1].startNode);;){h=h.getNextSourceNode(false);if(m.equals(h))g=1;else if(c(h)||h.type==CKEDITOR.NODE_ELEMENT&&h.isBlockBoundary())continue;break}if(!g)break;i++}for(n.moveToBookmark(d.shift());i--;){h=a[++e];h.moveToBookmark(d.shift());n.setEnd(h.endContainer,h.endOffset)}}return n}}},createBookmarks:function(b){for(var c=[],d,e=0;e<this.length;e++){c.push(d=this[e].createBookmark(b,true));for(var g=e+1;g<this.length;g++){this[g]=a(d,this[g]);this[g]=a(d,this[g],true)}}return c},createBookmarks2:function(a){for(var c=
[],d=0;d<this.length;d++)c.push(this[d].createBookmark2(a));return c},moveToBookmarks:function(a){for(var c=0;c<this.length;c++)this[c].moveToBookmark(a[c])}}})();
(function(){function a(){return CKEDITOR.getUrl(CKEDITOR.skinName.split(",")[1]||"skins/"+CKEDITOR.skinName.split(",")[0]+"/")}function c(b){var c=CKEDITOR.skin["ua_"+b],d=CKEDITOR.env;if(c)for(var c=c.split(",").sort(function(a,b){return a>b?-1:1}),e=0,f;e<c.length;e++){f=c[e];if(d.ie&&(f.replace(/^ie/,"")==d.version||d.quirks&&f=="iequirks"))f="ie";if(d[f]){b=b+("_"+c[e]);break}}return CKEDITOR.getUrl(a()+b+".css")}function b(a,b){if(!e[a]){CKEDITOR.document.appendStyleSheet(c(a));e[a]=1}b&&b()}
function f(a){var b=a.getById(g);if(!b){b=a.getHead().append("style");b.setAttribute("id",g);b.setAttribute("type","text/css")}return b}function d(a,b,c){var d,e,f;if(CKEDITOR.env.webkit){b=b.split("}").slice(0,-1);for(e=0;e<b.length;e++)b[e]=b[e].split("{")}for(var g=0;g<a.length;g++)if(CKEDITOR.env.webkit)for(e=0;e<b.length;e++){f=b[e][1];for(d=0;d<c.length;d++)f=f.replace(c[d][0],c[d][1]);a[g].$.sheet.addRule(b[e][0],f)}else{f=b;for(d=0;d<c.length;d++)f=f.replace(c[d][0],c[d][1]);CKEDITOR.env.ie&&
CKEDITOR.env.version<11?a[g].$.styleSheet.cssText=a[g].$.styleSheet.cssText+f:a[g].$.innerHTML=a[g].$.innerHTML+f}}var e={};CKEDITOR.skin={path:a,loadPart:function(c,d){CKEDITOR.skin.name!=CKEDITOR.skinName.split(",")[0]?CKEDITOR.scriptLoader.load(CKEDITOR.getUrl(a()+"skin.js"),function(){b(c,d)}):b(c,d)},getPath:function(a){return CKEDITOR.getUrl(c(a))},icons:{},addIcon:function(a,b,c,d){a=a.toLowerCase();this.icons[a]||(this.icons[a]={path:b,offset:c||0,bgsize:d||"16px"})},getIconStyle:function(a,
b,c,d,e){var f;if(a){a=a.toLowerCase();b&&(f=this.icons[a+"-rtl"]);f||(f=this.icons[a])}a=c||f&&f.path||"";d=d||f&&f.offset;e=e||f&&f.bgsize||"16px";return a&&"background-image:url("+CKEDITOR.getUrl(a)+");background-position:0 "+d+"px;background-size:"+e+";"}};CKEDITOR.tools.extend(CKEDITOR.editor.prototype,{getUiColor:function(){return this.uiColor},setUiColor:function(a){var b=f(CKEDITOR.document);return(this.setUiColor=function(a){var c=CKEDITOR.skin.chameleon,e=[[h,a]];this.uiColor=a;d([b],c(this,
"editor"),e);d(n,c(this,"panel"),e)}).call(this,a)}});var g="cke_ui_color",n=[],h=/\$color/g;CKEDITOR.on("instanceLoaded",function(a){if(!CKEDITOR.env.ie||!CKEDITOR.env.quirks){var b=a.editor,a=function(a){a=(a.data[0]||a.data).element.getElementsByTag("iframe").getItem(0).getFrameDocument();if(!a.getById("cke_ui_color")){a=f(a);n.push(a);var c=b.getUiColor();c&&d([a],CKEDITOR.skin.chameleon(b,"panel"),[[h,c]])}};b.on("panelShow",a);b.on("menuShow",a);b.config.uiColor&&b.setUiColor(b.config.uiColor)}})})();
(function(){if(CKEDITOR.env.webkit)CKEDITOR.env.hc=false;else{var a=CKEDITOR.dom.element.createFromHtml('<div style="width:0;height:0;position:absolute;left:-10000px;border:1px solid;border-color:red blue"></div>',CKEDITOR.document);a.appendTo(CKEDITOR.document.getHead());try{var c=a.getComputedStyle("border-top-color"),b=a.getComputedStyle("border-right-color");CKEDITOR.env.hc=!!(c&&c==b)}catch(f){CKEDITOR.env.hc=false}a.remove()}if(CKEDITOR.env.hc)CKEDITOR.env.cssClass=CKEDITOR.env.cssClass+" cke_hc";
CKEDITOR.document.appendStyleText(".cke{visibility:hidden;}");CKEDITOR.status="loaded";CKEDITOR.fireOnce("loaded");if(a=CKEDITOR._.pending){delete CKEDITOR._.pending;for(c=0;c<a.length;c++){CKEDITOR.editor.prototype.constructor.apply(a[c][0],a[c][1]);CKEDITOR.add(a[c][0])}}})();/*
 Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.skin.name="moono";CKEDITOR.skin.ua_editor="ie,iequirks,ie7,ie8,gecko";CKEDITOR.skin.ua_dialog="ie,iequirks,ie7,ie8";
CKEDITOR.skin.chameleon=function(){var b=function(){return function(b,e){for(var a=b.match(/[^#]./g),c=0;3>c;c++){var f=a,h=c,d;d=parseInt(a[c],16);d=("0"+(0>e?0|d*(1+e):0|d+(255-d)*e).toString(16)).slice(-2);f[h]=d}return"#"+a.join("")}}(),c=function(){var b=new CKEDITOR.template("background:#{to};background-image:-webkit-gradient(linear,lefttop,leftbottom,from({from}),to({to}));background-image:-moz-linear-gradient(top,{from},{to});background-image:-webkit-linear-gradient(top,{from},{to});background-image:-o-linear-gradient(top,{from},{to});background-image:-ms-linear-gradient(top,{from},{to});background-image:linear-gradient(top,{from},{to});filter:progid:DXImageTransform.Microsoft.gradient(gradientType=0,startColorstr='{from}',endColorstr='{to}');");return function(c,
a){return b.output({from:c,to:a})}}(),f={editor:new CKEDITOR.template("{id}.cke_chrome [border-color:{defaultBorder};] {id} .cke_top [ {defaultGradient}border-bottom-color:{defaultBorder};] {id} .cke_bottom [{defaultGradient}border-top-color:{defaultBorder};] {id} .cke_resizer [border-right-color:{ckeResizer}] {id} .cke_dialog_title [{defaultGradient}border-bottom-color:{defaultBorder};] {id} .cke_dialog_footer [{defaultGradient}outline-color:{defaultBorder};border-top-color:{defaultBorder};] {id} .cke_dialog_tab [{lightGradient}border-color:{defaultBorder};] {id} .cke_dialog_tab:hover [{mediumGradient}] {id} .cke_dialog_contents [border-top-color:{defaultBorder};] {id} .cke_dialog_tab_selected, {id} .cke_dialog_tab_selected:hover [background:{dialogTabSelected};border-bottom-color:{dialogTabSelectedBorder};] {id} .cke_dialog_body [background:{dialogBody};border-color:{defaultBorder};] {id} .cke_toolgroup [{lightGradient}border-color:{defaultBorder};] {id} a.cke_button_off:hover, {id} a.cke_button_off:focus, {id} a.cke_button_off:active [{mediumGradient}] {id} .cke_button_on [{ckeButtonOn}] {id} .cke_toolbar_separator [background-color: {ckeToolbarSeparator};] {id} .cke_combo_button [border-color:{defaultBorder};{lightGradient}] {id} a.cke_combo_button:hover, {id} a.cke_combo_button:focus, {id} .cke_combo_on a.cke_combo_button [border-color:{defaultBorder};{mediumGradient}] {id} .cke_path_item [color:{elementsPathColor};] {id} a.cke_path_item:hover, {id} a.cke_path_item:focus, {id} a.cke_path_item:active [background-color:{elementsPathBg};] {id}.cke_panel [border-color:{defaultBorder};] "),
panel:new CKEDITOR.template(".cke_panel_grouptitle [{lightGradient}border-color:{defaultBorder};] .cke_menubutton_icon [background-color:{menubuttonIcon};] .cke_menubutton:hover .cke_menubutton_icon, .cke_menubutton:focus .cke_menubutton_icon, .cke_menubutton:active .cke_menubutton_icon [background-color:{menubuttonIconHover};] .cke_menuseparator [background-color:{menubuttonIcon};] a:hover.cke_colorbox, a:focus.cke_colorbox, a:active.cke_colorbox [border-color:{defaultBorder};] a:hover.cke_colorauto, a:hover.cke_colormore, a:focus.cke_colorauto, a:focus.cke_colormore, a:active.cke_colorauto, a:active.cke_colormore [background-color:{ckeColorauto};border-color:{defaultBorder};] ")};
return function(g,e){var a=g.uiColor,a={id:"."+g.id,defaultBorder:b(a,-0.1),defaultGradient:c(b(a,0.9),a),lightGradient:c(b(a,1),b(a,0.7)),mediumGradient:c(b(a,0.8),b(a,0.5)),ckeButtonOn:c(b(a,0.6),b(a,0.7)),ckeResizer:b(a,-0.4),ckeToolbarSeparator:b(a,0.5),ckeColorauto:b(a,0.8),dialogBody:b(a,0.7),dialogTabSelected:c("#FFFFFF","#FFFFFF"),dialogTabSelectedBorder:"#FFF",elementsPathColor:b(a,-0.6),elementsPathBg:a,menubuttonIcon:b(a,0.5),menubuttonIconHover:b(a,0.3)};return f[e].output(a).replace(/\[/g,
"{").replace(/\]/g,"}")}}();CKEDITOR.plugins.add("basicstyles",{init:function(c){var e=0,d=function(g,d,b,a){if(a){var a=new CKEDITOR.style(a),f=h[b];f.unshift(a);c.attachStyleStateChange(a,function(a){!c.readOnly&&c.getCommand(b).setState(a)});c.addCommand(b,new CKEDITOR.styleCommand(a,{contentForms:f}));c.ui.addButton&&c.ui.addButton(g,{label:d,command:b,toolbar:"basicstyles,"+(e+=10)})}},h={bold:["strong","b",["span",function(a){a=a.styles["font-weight"];return"bold"==a||700<=+a}]],italic:["em","i",["span",function(a){return"italic"==
a.styles["font-style"]}]],underline:["u",["span",function(a){return"underline"==a.styles["text-decoration"]}]],strike:["s","strike",["span",function(a){return"line-through"==a.styles["text-decoration"]}]],subscript:["sub"],superscript:["sup"]},b=c.config,a=c.lang.basicstyles;d("Bold",a.bold,"bold",b.coreStyles_bold);d("Italic",a.italic,"italic",b.coreStyles_italic);d("Underline",a.underline,"underline",b.coreStyles_underline);d("Strike",a.strike,"strike",b.coreStyles_strike);d("Subscript",a.subscript,
"subscript",b.coreStyles_subscript);d("Superscript",a.superscript,"superscript",b.coreStyles_superscript);c.setKeystroke([[CKEDITOR.CTRL+66,"bold"],[CKEDITOR.CTRL+73,"italic"],[CKEDITOR.CTRL+85,"underline"]])}});CKEDITOR.config.coreStyles_bold={element:"strong",overrides:"b"};CKEDITOR.config.coreStyles_italic={element:"em",overrides:"i"};CKEDITOR.config.coreStyles_underline={element:"u"};CKEDITOR.config.coreStyles_strike={element:"s",overrides:"strike"};CKEDITOR.config.coreStyles_subscript={element:"sub"};
CKEDITOR.config.coreStyles_superscript={element:"sup"};(function(){function l(c,e,b){b=c.config.forceEnterMode||b;"wysiwyg"==c.mode&&(e||(e=c.activeEnterMode),c.elementPath().isContextFor("p")||(e=CKEDITOR.ENTER_BR,b=1),c.fire("saveSnapshot"),e==CKEDITOR.ENTER_BR?o(c,e,null,b):p(c,e,null,b),c.fire("saveSnapshot"))}function q(c){for(var c=c.getSelection().getRanges(!0),e=c.length-1;0<e;e--)c[e].deleteContents();return c[0]}CKEDITOR.plugins.add("enterkey",{init:function(c){c.addCommand("enter",{modes:{wysiwyg:1},editorFocus:!1,exec:function(c){l(c)}});
c.addCommand("shiftEnter",{modes:{wysiwyg:1},editorFocus:!1,exec:function(c){l(c,c.activeShiftEnterMode,1)}});c.setKeystroke([[13,"enter"],[CKEDITOR.SHIFT+13,"shiftEnter"]])}});var t=CKEDITOR.dom.walker.whitespaces(),u=CKEDITOR.dom.walker.bookmark();CKEDITOR.plugins.enterkey={enterBlock:function(c,e,b,h){if(b=b||q(c)){var f=b.document,j=b.checkStartOfBlock(),i=b.checkEndOfBlock(),a=c.elementPath(b.startContainer).block,k=e==CKEDITOR.ENTER_DIV?"div":"p",d;if(j&&i){if(a&&(a.is("li")||a.getParent().is("li"))){b=
a.getParent();d=b.getParent();var h=!a.hasPrevious(),m=!a.hasNext(),k=c.getSelection(),g=k.createBookmarks(),j=a.getDirection(1),i=a.getAttribute("class"),n=a.getAttribute("style"),l=d.getDirection(1)!=j,c=c.enterMode!=CKEDITOR.ENTER_BR||l||n||i;if(d.is("li"))if(h||m)a[h?"insertBefore":"insertAfter"](d);else a.breakParent(d);else{if(c)if(d=f.createElement(e==CKEDITOR.ENTER_P?"p":"div"),l&&d.setAttribute("dir",j),n&&d.setAttribute("style",n),i&&d.setAttribute("class",i),a.moveChildren(d),h||m)d[h?
"insertBefore":"insertAfter"](b);else a.breakParent(b),d.insertAfter(b);else if(a.appendBogus(!0),h||m)for(;f=a[h?"getFirst":"getLast"]();)f[h?"insertBefore":"insertAfter"](b);else for(a.breakParent(b);f=a.getLast();)f.insertAfter(b);a.remove()}k.selectBookmarks(g);return}if(a&&a.getParent().is("blockquote")){a.breakParent(a.getParent());a.getPrevious().getFirst(CKEDITOR.dom.walker.invisible(1))||a.getPrevious().remove();a.getNext().getFirst(CKEDITOR.dom.walker.invisible(1))||a.getNext().remove();
b.moveToElementEditStart(a);b.select();return}}else if(a&&a.is("pre")&&!i){o(c,e,b,h);return}if(i=b.splitBlock(k)){e=i.previousBlock;a=i.nextBlock;c=i.wasStartOfBlock;j=i.wasEndOfBlock;if(a)g=a.getParent(),g.is("li")&&(a.breakParent(g),a.move(a.getNext(),1));else if(e&&(g=e.getParent())&&g.is("li"))e.breakParent(g),g=e.getNext(),b.moveToElementEditStart(g),e.move(e.getPrevious());if(!c&&!j)a.is("li")&&(d=b.clone(),d.selectNodeContents(a),d=new CKEDITOR.dom.walker(d),d.evaluator=function(a){return!(u(a)||
t(a)||a.type==CKEDITOR.NODE_ELEMENT&&a.getName()in CKEDITOR.dtd.$inline&&!(a.getName()in CKEDITOR.dtd.$empty))},(g=d.next())&&(g.type==CKEDITOR.NODE_ELEMENT&&g.is("ul","ol"))&&(CKEDITOR.env.needsBrFiller?f.createElement("br"):f.createText(" ")).insertBefore(g)),a&&b.moveToElementEditStart(a);else{if(e){if(e.is("li")||!r.test(e.getName())&&!e.is("pre"))d=e.clone()}else a&&(d=a.clone());d?h&&!d.is("li")&&d.renameNode(k):g&&g.is("li")?d=g:(d=f.createElement(k),e&&(m=e.getDirection())&&d.setAttribute("dir",
m));if(f=i.elementPath){h=0;for(k=f.elements.length;h<k;h++){g=f.elements[h];if(g.equals(f.block)||g.equals(f.blockLimit))break;CKEDITOR.dtd.$removeEmpty[g.getName()]&&(g=g.clone(),d.moveChildren(g),d.append(g))}}d.appendBogus();d.getParent()||b.insertNode(d);d.is("li")&&d.removeAttribute("value");if(CKEDITOR.env.ie&&c&&(!j||!e.getChildCount()))b.moveToElementEditStart(j?e:d),b.select();b.moveToElementEditStart(c&&!j?a:d)}b.select();b.scrollIntoView()}}},enterBr:function(c,e,b,h){if(b=b||q(c)){var f=
b.document,j=b.checkEndOfBlock(),i=new CKEDITOR.dom.elementPath(c.getSelection().getStartElement()),a=i.block,k=a&&i.block.getName();!h&&"li"==k?p(c,e,b,h):(!h&&j&&r.test(k)?(j=a.getDirection())?(f=f.createElement("div"),f.setAttribute("dir",j),f.insertAfter(a),b.setStart(f,0)):(f.createElement("br").insertAfter(a),CKEDITOR.env.gecko&&f.createText("").insertAfter(a),b.setStartAt(a.getNext(),CKEDITOR.env.ie?CKEDITOR.POSITION_BEFORE_START:CKEDITOR.POSITION_AFTER_START)):(c="pre"==k&&CKEDITOR.env.ie&&
8>CKEDITOR.env.version?f.createText("\r"):f.createElement("br"),b.deleteContents(),b.insertNode(c),CKEDITOR.env.needsBrFiller?(f.createText("﻿").insertAfter(c),j&&(a||i.blockLimit).appendBogus(),c.getNext().$.nodeValue="",b.setStartAt(c.getNext(),CKEDITOR.POSITION_AFTER_START)):b.setStartAt(c,CKEDITOR.POSITION_AFTER_END)),b.collapse(!0),b.select(),b.scrollIntoView())}}};var s=CKEDITOR.plugins.enterkey,o=s.enterBr,p=s.enterBlock,r=/^h[1-6]$/})();(function(){function j(a,b){var d={},e=[],f={nbsp:" ",shy:"­",gt:">",lt:"<",amp:"&",apos:"'",quot:'"'},a=a.replace(/\b(nbsp|shy|gt|lt|amp|apos|quot)(?:,|$)/g,function(a,h){var c=b?"&"+h+";":f[h];d[c]=b?f[h]:"&"+h+";";e.push(c);return""});if(!b&&a){var a=a.split(","),c=document.createElement("div"),g;c.innerHTML="&"+a.join(";&")+";";g=c.innerHTML;c=null;for(c=0;c<g.length;c++){var i=g.charAt(c);d[i]="&"+a[c]+";";e.push(i)}}d.regex=e.join(b?"|":"");return d}CKEDITOR.plugins.add("entities",{afterInit:function(a){var b=
a.config;if(a=(a=a.dataProcessor)&&a.htmlFilter){var d=[];!1!==b.basicEntities&&d.push("nbsp,gt,lt,amp");b.entities&&(d.length&&d.push("quot,iexcl,cent,pound,curren,yen,brvbar,sect,uml,copy,ordf,laquo,not,shy,reg,macr,deg,plusmn,sup2,sup3,acute,micro,para,middot,cedil,sup1,ordm,raquo,frac14,frac12,frac34,iquest,times,divide,fnof,bull,hellip,prime,Prime,oline,frasl,weierp,image,real,trade,alefsym,larr,uarr,rarr,darr,harr,crarr,lArr,uArr,rArr,dArr,hArr,forall,part,exist,empty,nabla,isin,notin,ni,prod,sum,minus,lowast,radic,prop,infin,ang,and,or,cap,cup,int,there4,sim,cong,asymp,ne,equiv,le,ge,sub,sup,nsub,sube,supe,oplus,otimes,perp,sdot,lceil,rceil,lfloor,rfloor,lang,rang,loz,spades,clubs,hearts,diams,circ,tilde,ensp,emsp,thinsp,zwnj,zwj,lrm,rlm,ndash,mdash,lsquo,rsquo,sbquo,ldquo,rdquo,bdquo,dagger,Dagger,permil,lsaquo,rsaquo,euro"),
b.entities_latin&&d.push("Agrave,Aacute,Acirc,Atilde,Auml,Aring,AElig,Ccedil,Egrave,Eacute,Ecirc,Euml,Igrave,Iacute,Icirc,Iuml,ETH,Ntilde,Ograve,Oacute,Ocirc,Otilde,Ouml,Oslash,Ugrave,Uacute,Ucirc,Uuml,Yacute,THORN,szlig,agrave,aacute,acirc,atilde,auml,aring,aelig,ccedil,egrave,eacute,ecirc,euml,igrave,iacute,icirc,iuml,eth,ntilde,ograve,oacute,ocirc,otilde,ouml,oslash,ugrave,uacute,ucirc,uuml,yacute,thorn,yuml,OElig,oelig,Scaron,scaron,Yuml"),b.entities_greek&&d.push("Alpha,Beta,Gamma,Delta,Epsilon,Zeta,Eta,Theta,Iota,Kappa,Lambda,Mu,Nu,Xi,Omicron,Pi,Rho,Sigma,Tau,Upsilon,Phi,Chi,Psi,Omega,alpha,beta,gamma,delta,epsilon,zeta,eta,theta,iota,kappa,lambda,mu,nu,xi,omicron,pi,rho,sigmaf,sigma,tau,upsilon,phi,chi,psi,omega,thetasym,upsih,piv"),
b.entities_additional&&d.push(b.entities_additional));var e=j(d.join(",")),f=e.regex?"["+e.regex+"]":"a^";delete e.regex;b.entities&&b.entities_processNumerical&&(f="[^ -~]|"+f);var f=RegExp(f,"g"),c=function(a){return b.entities_processNumerical=="force"||!e[a]?"&#"+a.charCodeAt(0)+";":e[a]},g=j("nbsp,gt,lt,amp,shy",!0),i=RegExp(g.regex,"g"),k=function(a){return g[a]};a.addRules({text:function(a){return a.replace(i,k).replace(f,c)}},{applyToAll:!0,excludeNestedEditable:!0})}}})})();
CKEDITOR.config.basicEntities=!0;CKEDITOR.config.entities=!0;CKEDITOR.config.entities_latin=!0;CKEDITOR.config.entities_greek=!0;CKEDITOR.config.entities_additional="#39";(function(){function k(a,b){var e,f;b.on("refresh",function(a){var b=[i],c;for(c in a.data.states)b.push(a.data.states[c]);this.setState(CKEDITOR.tools.search(b,m)?m:i)},b,null,100);b.on("exec",function(b){e=a.getSelection();f=e.createBookmarks(1);b.data||(b.data={});b.data.done=!1},b,null,0);b.on("exec",function(){a.forceNextSelectionCheck();e.selectBookmarks(f)},b,null,100)}var i=CKEDITOR.TRISTATE_DISABLED,m=CKEDITOR.TRISTATE_OFF;CKEDITOR.plugins.add("indent",{init:function(a){var b=CKEDITOR.plugins.indent.genericDefinition;
k(a,a.addCommand("indent",new b(!0)));k(a,a.addCommand("outdent",new b));a.ui.addButton&&(a.ui.addButton("Indent",{label:a.lang.indent.indent,command:"indent",directional:!0,toolbar:"indent,20"}),a.ui.addButton("Outdent",{label:a.lang.indent.outdent,command:"outdent",directional:!0,toolbar:"indent,10"}));a.on("dirChanged",function(b){var f=a.createRange(),j=b.data.node;f.setStartBefore(j);f.setEndAfter(j);for(var l=new CKEDITOR.dom.walker(f),c;c=l.next();)if(c.type==CKEDITOR.NODE_ELEMENT)if(!c.equals(j)&&
c.getDirection()){f.setStartAfter(c);l=new CKEDITOR.dom.walker(f)}else{var d=a.config.indentClasses;if(d)for(var g=b.data.dir=="ltr"?["_rtl",""]:["","_rtl"],h=0;h<d.length;h++)if(c.hasClass(d[h]+g[0])){c.removeClass(d[h]+g[0]);c.addClass(d[h]+g[1])}d=c.getStyle("margin-right");g=c.getStyle("margin-left");d?c.setStyle("margin-left",d):c.removeStyle("margin-left");g?c.setStyle("margin-right",g):c.removeStyle("margin-right")}})}});CKEDITOR.plugins.indent={genericDefinition:function(a){this.isIndent=
!!a;this.startDisabled=!this.isIndent},specificDefinition:function(a,b,e){this.name=b;this.editor=a;this.jobs={};this.enterBr=a.config.enterMode==CKEDITOR.ENTER_BR;this.isIndent=!!e;this.relatedGlobal=e?"indent":"outdent";this.indentKey=e?9:CKEDITOR.SHIFT+9;this.database={}},registerCommands:function(a,b){a.on("pluginsLoaded",function(){for(var a in b)(function(a,b){var e=a.getCommand(b.relatedGlobal),c;for(c in b.jobs)e.on("exec",function(d){d.data.done||(a.fire("lockSnapshot"),b.execJob(a,c)&&(d.data.done=
!0),a.fire("unlockSnapshot"),CKEDITOR.dom.element.clearAllMarkers(b.database))},this,null,c),e.on("refresh",function(d){d.data.states||(d.data.states={});d.data.states[b.name+"@"+c]=b.refreshJob(a,c,d.data.path)},this,null,c);a.addFeature(b)})(this,b[a])})}};CKEDITOR.plugins.indent.genericDefinition.prototype={context:"p",exec:function(){}};CKEDITOR.plugins.indent.specificDefinition.prototype={execJob:function(a,b){var e=this.jobs[b];if(e.state!=i)return e.exec.call(this,a)},refreshJob:function(a,
b,e){b=this.jobs[b];b.state=a.activeFilter.checkFeature(this)?b.refresh.call(this,a,e):i;return b.state},getContext:function(a){return a.contains(this.context)}}})();(function(){function s(e){function g(b){for(var f=d.startContainer,a=d.endContainer;f&&!f.getParent().equals(b);)f=f.getParent();for(;a&&!a.getParent().equals(b);)a=a.getParent();if(!f||!a)return!1;for(var h=f,f=[],c=!1;!c;)h.equals(a)&&(c=!0),f.push(h),h=h.getNext();if(1>f.length)return!1;h=b.getParents(!0);for(a=0;a<h.length;a++)if(h[a].getName&&k[h[a].getName()]){b=h[a];break}for(var h=n.isIndent?1:-1,a=f[0],f=f[f.length-1],c=CKEDITOR.plugins.list.listToArray(b,o),g=c[f.getCustomData("listarray_index")].indent,
a=a.getCustomData("listarray_index");a<=f.getCustomData("listarray_index");a++)if(c[a].indent+=h,0<h){var l=c[a].parent;c[a].parent=new CKEDITOR.dom.element(l.getName(),l.getDocument())}for(a=f.getCustomData("listarray_index")+1;a<c.length&&c[a].indent>g;a++)c[a].indent+=h;f=CKEDITOR.plugins.list.arrayToList(c,o,null,e.config.enterMode,b.getDirection());if(!n.isIndent){var i;if((i=b.getParent())&&i.is("li"))for(var h=f.listNode.getChildren(),m=[],j,a=h.count()-1;0<=a;a--)(j=h.getItem(a))&&(j.is&&
j.is("li"))&&m.push(j)}f&&f.listNode.replace(b);if(m&&m.length)for(a=0;a<m.length;a++){for(j=b=m[a];(j=j.getNext())&&j.is&&j.getName()in k;)CKEDITOR.env.needsNbspFiller&&!b.getFirst(t)&&b.append(d.document.createText(" ")),b.append(j);b.insertAfter(i)}f&&e.fire("contentDomInvalidated");return!0}for(var n=this,o=this.database,k=this.context,l=e.getSelection(),l=(l&&l.getRanges()).createIterator(),d;d=l.getNextRange();){for(var b=d.getCommonAncestor();b&&!(b.type==CKEDITOR.NODE_ELEMENT&&k[b.getName()]);)b=
b.getParent();b||(b=d.startPath().contains(k))&&d.setEndAt(b,CKEDITOR.POSITION_BEFORE_END);if(!b){var c=d.getEnclosedNode();c&&(c.type==CKEDITOR.NODE_ELEMENT&&c.getName()in k)&&(d.setStartAt(c,CKEDITOR.POSITION_AFTER_START),d.setEndAt(c,CKEDITOR.POSITION_BEFORE_END),b=c)}b&&(d.startContainer.type==CKEDITOR.NODE_ELEMENT&&d.startContainer.getName()in k)&&(c=new CKEDITOR.dom.walker(d),c.evaluator=i,d.startContainer=c.next());b&&(d.endContainer.type==CKEDITOR.NODE_ELEMENT&&d.endContainer.getName()in k)&&
(c=new CKEDITOR.dom.walker(d),c.evaluator=i,d.endContainer=c.previous());if(b)return g(b)}return 0}function p(e,g){g||(g=e.contains(this.context));return g&&e.block&&e.block.equals(g.getFirst(i))}function i(e){return e.type==CKEDITOR.NODE_ELEMENT&&e.is("li")}function t(e){return u(e)&&v(e)}var u=CKEDITOR.dom.walker.whitespaces(!0),v=CKEDITOR.dom.walker.bookmark(!1,!0),q=CKEDITOR.TRISTATE_DISABLED,r=CKEDITOR.TRISTATE_OFF;CKEDITOR.plugins.add("indentlist",{requires:"indent",init:function(e){function g(e,
g){i.specificDefinition.apply(this,arguments);this.requiredContent=["ul","ol"];e.on("key",function(g){if("wysiwyg"==e.mode&&g.data.keyCode==this.indentKey){var d=this.getContext(e.elementPath());if(d&&(!this.isIndent||!p.call(this,e.elementPath(),d)))e.execCommand(this.relatedGlobal),g.cancel()}},this);this.jobs[this.isIndent?10:30]={refresh:this.isIndent?function(e,d){var b=this.getContext(d),c=p.call(this,d,b);return!b||!this.isIndent||c?q:r}:function(e,d){return!this.getContext(d)||this.isIndent?
q:r},exec:CKEDITOR.tools.bind(s,this)}}var i=CKEDITOR.plugins.indent;i.registerCommands(e,{indentlist:new g(e,"indentlist",!0),outdentlist:new g(e,"outdentlist")});CKEDITOR.tools.extend(g.prototype,i.specificDefinition.prototype,{context:{ol:1,ul:1}})}})})();(function(){function g(a){this.editor=a;this.reset()}CKEDITOR.plugins.add("undo",{init:function(a){function c(a){b.enabled&&!1!==a.data.command.canUndo&&b.save()}function d(){b.enabled=a.readOnly?!1:"wysiwyg"==a.mode;b.onChange()}var b=a.undoManager=new g(a),e=a.addCommand("undo",{exec:function(){b.undo()&&(a.selectionChange(),this.fire("afterUndo"))},startDisabled:!0,canUndo:!1}),f=a.addCommand("redo",{exec:function(){b.redo()&&(a.selectionChange(),this.fire("afterRedo"))},startDisabled:!0,canUndo:!1}),
h=[CKEDITOR.CTRL+90,CKEDITOR.CTRL+89,CKEDITOR.CTRL+CKEDITOR.SHIFT+90];a.setKeystroke([[h[0],"undo"],[h[1],"redo"],[h[2],"redo"]]);a.on("contentDom",function(){var b=a.editable();b.attachListener(b,"keydown",function(a){-1<CKEDITOR.tools.indexOf(h,a.data.getKeystroke())&&a.data.preventDefault()})});b.onChange=function(){e.setState(b.undoable()?CKEDITOR.TRISTATE_OFF:CKEDITOR.TRISTATE_DISABLED);f.setState(b.redoable()?CKEDITOR.TRISTATE_OFF:CKEDITOR.TRISTATE_DISABLED)};a.on("beforeCommandExec",c);a.on("afterCommandExec",
c);a.on("saveSnapshot",function(a){b.save(a.data&&a.data.contentOnly)});a.on("contentDom",function(){a.editable().on("keydown",function(a){a=a.data.getKey();(8==a||46==a)&&b.type(a,0)});a.editable().on("keypress",function(a){b.type(a.data.getKey(),1)})});a.on("beforeModeUnload",function(){"wysiwyg"==a.mode&&b.save(!0)});a.on("mode",d);a.on("readOnly",d);a.ui.addButton&&(a.ui.addButton("Undo",{label:a.lang.undo.undo,command:"undo",toolbar:"undo,10"}),a.ui.addButton("Redo",{label:a.lang.undo.redo,command:"redo",
toolbar:"undo,20"}));a.resetUndo=function(){b.reset();a.fire("saveSnapshot")};a.on("updateSnapshot",function(){b.currentImage&&b.update()});a.on("lockSnapshot",function(a){a=a.data;b.lock(a&&a.dontUpdate,a&&a.forceUpdate)});a.on("unlockSnapshot",b.unlock,b)}});CKEDITOR.plugins.undo={};var f=CKEDITOR.plugins.undo.Image=function(a,c){this.editor=a;a.fire("beforeUndoImage");var d=a.getSnapshot();CKEDITOR.env.ie&&d&&(d=d.replace(/\s+data-cke-expando=".*?"/g,""));this.contents=d;c||(this.bookmarks=(d=
d&&a.getSelection())&&d.createBookmarks2(!0));a.fire("afterUndoImage")},i=/\b(?:href|src|name)="[^"]*?"/gi;f.prototype={equalsContent:function(a){var c=this.contents,a=a.contents;if(CKEDITOR.env.ie&&(CKEDITOR.env.ie7Compat||CKEDITOR.env.quirks))c=c.replace(i,""),a=a.replace(i,"");return c!=a?!1:!0},equalsSelection:function(a){var c=this.bookmarks,a=a.bookmarks;if(c||a){if(!c||!a||c.length!=a.length)return!1;for(var d=0;d<c.length;d++){var b=c[d],e=a[d];if(b.startOffset!=e.startOffset||b.endOffset!=
e.endOffset||!CKEDITOR.tools.arrayCompare(b.start,e.start)||!CKEDITOR.tools.arrayCompare(b.end,e.end))return!1}}return!0}};g.prototype={type:function(a,c){var d=!c&&a!=this.lastKeystroke,b=this.editor;if(!this.typing||c&&!this.wasCharacter||d){var e=new f(b),g=this.snapshots.length;CKEDITOR.tools.setTimeout(function(){var a=b.getSnapshot();CKEDITOR.env.ie&&(a=a.replace(/\s+data-cke-expando=".*?"/g,""));e.contents!=a&&g==this.snapshots.length&&(this.typing=!0,this.save(!1,e,!1)||this.snapshots.splice(this.index+
1,this.snapshots.length-this.index-1),this.hasUndo=!0,this.hasRedo=!1,this.modifiersCount=this.typesCount=1,this.onChange())},0,this)}this.lastKeystroke=a;(this.wasCharacter=c)?(this.modifiersCount=0,this.typesCount++,25<this.typesCount?(this.save(!1,null,!1),this.typesCount=1):setTimeout(function(){b.fire("change")},0)):(this.typesCount=0,this.modifiersCount++,25<this.modifiersCount?(this.save(!1,null,!1),this.modifiersCount=1):setTimeout(function(){b.fire("change")},0))},reset:function(){this.lastKeystroke=
0;this.snapshots=[];this.index=-1;this.limit=this.editor.config.undoStackSize||20;this.currentImage=null;this.hasRedo=this.hasUndo=!1;this.locked=null;this.resetType()},resetType:function(){this.typing=!1;delete this.lastKeystroke;this.modifiersCount=this.typesCount=0},fireChange:function(){this.hasUndo=!!this.getNextImage(!0);this.hasRedo=!!this.getNextImage(!1);this.resetType();this.onChange()},save:function(a,c,d){var b=this.editor;if(this.locked||"ready"!=b.status||"wysiwyg"!=b.mode)return!1;
var e=b.editable();if(!e||"ready"!=e.status)return!1;e=this.snapshots;c||(c=new f(b));if(!1===c.contents)return!1;if(this.currentImage)if(c.equalsContent(this.currentImage)){if(a||c.equalsSelection(this.currentImage))return!1}else b.fire("change");e.splice(this.index+1,e.length-this.index-1);e.length==this.limit&&e.shift();this.index=e.push(c)-1;this.currentImage=c;!1!==d&&this.fireChange();return!0},restoreImage:function(a){var c=this.editor,d;a.bookmarks&&(c.focus(),d=c.getSelection());this.locked=
1;this.editor.loadSnapshot(a.contents);a.bookmarks?d.selectBookmarks(a.bookmarks):CKEDITOR.env.ie&&(d=this.editor.document.getBody().$.createTextRange(),d.collapse(!0),d.select());this.locked=0;this.index=a.index;this.currentImage=this.snapshots[this.index];this.update();this.fireChange();c.fire("change")},getNextImage:function(a){var c=this.snapshots,d=this.currentImage,b;if(d)if(a)for(b=this.index-1;0<=b;b--){if(a=c[b],!d.equalsContent(a))return a.index=b,a}else for(b=this.index+1;b<c.length;b++)if(a=
c[b],!d.equalsContent(a))return a.index=b,a;return null},redoable:function(){return this.enabled&&this.hasRedo},undoable:function(){return this.enabled&&this.hasUndo},undo:function(){if(this.undoable()){this.save(!0);var a=this.getNextImage(!0);if(a)return this.restoreImage(a),!0}return!1},redo:function(){if(this.redoable()&&(this.save(!0),this.redoable())){var a=this.getNextImage(!1);if(a)return this.restoreImage(a),!0}return!1},update:function(a){if(!this.locked){a||(a=new f(this.editor));for(var c=
this.index,d=this.snapshots;0<c&&this.currentImage.equalsContent(d[c-1]);)c-=1;d.splice(c,this.index-c+1,a);this.index=c;this.currentImage=a}},lock:function(a,c){if(this.locked)this.locked.level++;else if(a)this.locked={level:1};else{var d=null;if(c)d=!0;else{var b=new f(this.editor,!0);this.currentImage&&this.currentImage.equalsContent(b)&&(d=b)}this.locked={update:d,level:1}}},unlock:function(){if(this.locked&&!--this.locked.level){var a=this.locked.update;this.locked=null;if(!0===a)this.update();
else if(a){var c=new f(this.editor,!0);a.equalsContent(c)||this.update()}}}}})();CKEDITOR.config.plugins='basicstyles,enterkey,entities,indent,indentlist,undo';CKEDITOR.config.skin='moono';(function() {var setIcons = function(icons, strip) {var path = CKEDITOR.getUrl( 'plugins/' + strip );icons = icons.split( ',' );for ( var i = 0; i < icons.length; i++ )CKEDITOR.skin.icons[ icons[ i ] ] = { path: path, offset: -icons[ ++i ], bgsize : icons[ ++i ] };};if (CKEDITOR.env.hidpi) setIcons('bold,0,,italic,24,,strike,48,,subscript,72,,superscript,96,,underline,120,,indent-rtl,144,,indent,168,,outdent-rtl,192,,outdent,216,,redo-rtl,240,,redo,264,,undo-rtl,288,,undo,312,','icons_hidpi.png');else setIcons('bold,0,auto,italic,24,auto,strike,48,auto,subscript,72,auto,superscript,96,auto,underline,120,auto,indent-rtl,144,auto,indent,168,auto,outdent-rtl,192,auto,outdent,216,auto,redo-rtl,240,auto,redo,264,auto,undo-rtl,288,auto,undo,312,auto','icons.png');})();CKEDITOR.lang.languages={"af":1,"sq":1,"ar":1,"eu":1,"bn":1,"bs":1,"bg":1,"ca":1,"zh-cn":1,"zh":1,"hr":1,"cs":1,"da":1,"nl":1,"en":1,"en-au":1,"en-ca":1,"en-gb":1,"eo":1,"et":1,"fo":1,"fi":1,"fr":1,"fr-ca":1,"gl":1,"ka":1,"de":1,"el":1,"gu":1,"he":1,"hi":1,"hu":1,"is":1,"id":1,"it":1,"ja":1,"km":1,"ko":1,"ku":1,"lv":1,"lt":1,"mk":1,"ms":1,"mn":1,"no":1,"nb":1,"fa":1,"pl":1,"pt-br":1,"pt":1,"ro":1,"ru":1,"sr":1,"sr-latn":1,"si":1,"sk":1,"sl":1,"es":1,"sv":1,"tt":1,"th":1,"tr":1,"ug":1,"uk":1,"vi":1,"cy":1};}());
(function() {
    'use strict';

    /**
     * CKEDITOR.tools class utility which adds additional methods to those of CKEditor.
     *
     * @class CKEDITOR.tools
     */

    /**
     * Debounce util function. If a function execution is expensive, it might be debounced. This means
     * that it will be executed after some amount of time after its last call. For example, if we attach a
     * a function on scroll event, it might be called hundreds times per second. In this case it may be
     * debounced with, let's say 100ms. The real execution of this function will happen 100ms after last
     * scroll event.
     *
     * @method debounce
     * @param {Function} callback The callback which has to be called after given timeout.
     * @param {Number} timeout Timeout in milliseconds after which the callback will be called.
     * @param {Object} context The context in which the callback will be called. This argument is optional.
     * @param {Array} args An array of arguments which the callback will receive.
     */
    CKEDITOR.tools.debounce = CKEDITOR.tools.debounce || function(callback, timeout, context, args) {
        var callFn,
            debounceHandle;

        callFn = function() {
            var callArgs,
                callContext,
                len,
                result = [],
                startIndex = 0;

            callContext = context || this;

            for (len = arguments.length; startIndex < len; ++startIndex) {
                result.push(arguments[startIndex]);
            }

            callArgs = result.concat(args || []);

            clearTimeout(debounceHandle);

            debounceHandle = setTimeout(function() {
                callback.apply(callContext, callArgs);
            }, timeout);
        };

        callFn.cancel = function() {
            clearTimeout(debounceHandle);
        };

        return callFn;
    };
}());
(function() {
    'use strict';

    /**
     * Link class utility. Provides methods for create, delete and update links.
     *
     * @class CKEDITOR.Link
     * @constructor
     * @param {Object} The CKEditor instance.
     */

    function Link(editor) {
        this._editor = editor;
    }

    Link.prototype = {
        constructor: Link,

        /**
         * Create a link with given URI as href.
         *
         * @method create
         * @param {String} URI The URI of the link.
         * @param {Object} attrs A config object with link attributes. These might be arbitrary DOM attributes.
         */
        create: function(URI, attrs) {
            var linkAttrs,
                range,
                selection,
                style,
                text;

            selection = this._editor.getSelection();

            range = selection.getRanges()[0];

            if (range.collapsed) {
                text = new CKEDITOR.dom.text(URI, this._editor.document);
                range.insertNode(text);
                range.selectNodeContents(text);
            }

            linkAttrs = CKEDITOR.tools.merge({
                'data-cke-saved-href': URI,
                href: URI
            }, attrs);

            style = new CKEDITOR.style({
                attributes: linkAttrs,
                element: 'a'
            });

            style.type = CKEDITOR.STYLE_INLINE;
            style.applyToRange(range, this._editor);
            range.select();
        },

        /**
         * Retrieves a link from the current selection.
         *
         * @method getFromSelection
         * @return {CKEDITOR.dom.element} The retrieved link or null if not found.
         */
        getFromSelection: function() {
            var range,
                selection,
                selectedElement;

            selection = this._editor.getSelection();

            selectedElement = selection.getSelectedElement();

            if (selectedElement && selectedElement.is('a')) {
                return selectedElement;
            }

            range = selection.getRanges()[0];

            if (range) {
                range.shrink(CKEDITOR.SHRINK_TEXT);

                return this._editor.elementPath(range.getCommonAncestor()).contains('a', 1);
            }

            return null;
        },

        /**
         * Removes a link from the editor.
         *
         * @param {CKEDITOR.dom.element} link The link element which link style should be removed.
         * @method remove
         */
        remove: function(link) {
            var style;

            if (link) {
                link.remove(this._editor);
            } else {
                style = link || new CKEDITOR.style({
                    alwaysRemoveElement: 1,
                    element: 'a',
                    type: CKEDITOR.STYLE_INLINE
                });

                this._editor.removeStyle(style);
            }
        },

        /**
         * Updates the href of an already existing link.
         *
         * @param {String} URI The new URI of the link.
         * @param {CKEDITOR.dom.element} link The link element which href should be removed.
         * @method update
         */
        update: function(URI, link) {
            var style;

            style = link || this.getFromSelection();

            style.setAttributes({
                'data-cke-saved-href': URI,
                href: URI
            });
        }
    };

    CKEDITOR.Link = CKEDITOR.Link || Link;
}());
(function() {
    'use strict';

    if (CKEDITOR.plugins.get('selectionregion')) {
        return;
    }

    CKEDITOR.SELECTION_TOP_TO_BOTTOM = 0;
    CKEDITOR.SELECTION_BOTTOM_TO_TOP = 1;
    CKEDITOR.SELECTION_LEFT_TO_RIGHT = 2;
    CKEDITOR.SELECTION_RIGHT_TO_LEFT = 3;

    /**
     * SelectionRegion utility class which provides metadata about the selection. The metadata may be the start and end
     * rectangles, caret region, etc. **This class is not intended to be used standalone. Its functions will
     * be merged into each editor instance, so the developer may use them directly via the editor, without making
     * an instance of this class**.
     *
     * @class CKEDITOR.plugins.selectionregion
     * @constructor
     */
    function SelectionRegion() {}

    SelectionRegion.prototype = {
        constructor: SelectionRegion,

        /**
         * Creates selection from two points in page coordinates.
         *
         * @method createSelectionFromPoint
         * @param {Number} x X point in page coordinates.
         * @param {Number} y Y point in page coordinates.
         */
        createSelectionFromPoint: function(x, y) {
            this.createSelectionFromRange(x, y, x, y);
        },

        /**
         * Creates selection from range. A range consists from two points in page coordinates.
         *
         * @method createSelectionFromRange
         * @param {Number} startX X coordinate of the first point.
         * @param {Number} startY Y coordinate of the first point.
         * @param {Number} endX X coordinate of the second point.
         * @param {Number} endY Y coordinate of the second point.
         */
        createSelectionFromRange: function(startX, startY, endX, endY) {
            var editor,
                end,
                endContainer,
                endOffset,
                endRange,
                range,
                selection,
                start,
                startContainer,
                startOffset;

            editor = this.editor;

            if (typeof document.caretPositionFromPoint == 'function') {
                start = document.caretPositionFromPoint(startX, startY);
                end = document.caretPositionFromPoint(endX, endY);

                startContainer = start.offsetNode;
                endContainer = end.offsetNode;

                startOffset = start.offset;
                endOffset = end.offset;

                range = this.createRange();
            } else if (typeof document.caretRangeFromPoint == 'function') {
                start = document.caretRangeFromPoint(startX, startY);
                end = document.caretRangeFromPoint(endX, endY);

                startContainer = start.startContainer;
                endContainer = end.startContainer;

                startOffset = start.startOffset;
                endOffset = end.startOffset;

                range = this.createRange();
            }

            if (range && document.getSelection) {
                range.setStart(new CKEDITOR.dom.node(startContainer), startOffset);
                range.setEnd(new CKEDITOR.dom.node(endContainer), endOffset);

                this.getSelection().selectRanges([range]);
            } else if (typeof document.body.createTextRange == 'function') {
                selection = this.getSelection();

                selection.unlock();

                range = document.body.createTextRange();
                range.moveToPoint(startX, startY);

                endRange = range.duplicate();
                endRange.moveToPoint(endX, endY);

                range.setEndPoint('EndToEnd', endRange);
                range.select();

                this.getSelection().lock();
            }
        },

        /**
         * Returns the region of the current position of the caret. The points are in page coordinates.
         *
         * @method getCaretRegion
         * @return {Object} Returns object with the following properties:
         * - bottom
         * - left
         * - right
         * - top
         */
        getCaretRegion: function() {
            var bookmarkNodeEl,
                bookmarks,
                region,
                selection,
                scrollPos;

            selection = this.getSelection();

            bookmarks = selection.createBookmarks();
            bookmarkNodeEl = bookmarks[0].startNode.$;

            bookmarkNodeEl.style.display = 'inline-block';

            region = new CKEDITOR.dom.element(bookmarkNodeEl).getClientRect();

            bookmarkNodeEl.parentNode.removeChild(bookmarkNodeEl);

            scrollPos = new CKEDITOR.dom.window(window).getScrollPosition();

            return {
                bottom: scrollPos.y + region.bottom,
                left: scrollPos.x + region.left,
                right: scrollPos.x + region.right,
                top: scrollPos.y + region.top
            };
        },

        /**
         * Returns data for the current selection.
         *
         * @method getSelectionData
         * @return {Object} Returns object with the following data:
         * - element - The currently selected element, if any
         * - text - The selected text
         * - region - The data, returned from {{#crossLink "CKEDITOR.plugins.selectionregion/getSelectionRegion:method"}}{{/crossLink}}
         */
        getSelectionData: function() {
            var result,
                selection;

            selection = this.getSelection();

            result = {
                element: selection.getSelectedElement(),
                text: selection.getSelectedText()
            };

            result.region = this.getSelectionRegion(selection);

            return result;
        },

        /**
         * Returns the region of the current selection.
         *
         * @method getSelectionRegion
         * @return {Object} Returns object which is being returned from
         * {{#crossLink "CKEDITOR.plugins.selectionregion/getClientRectsRegion:method"}}{{/crossLink}} with three more properties:
         * - direction - the direction of the selection. Can be one of these:
         *   1. CKEDITOR.SELECTION_TOP_TO_BOTTOM
         *   2. CKEDITOR.SELECTION_BOTTOM_TO_TOP
         * - height - The height of the selection region
         * - width - The width of the selection region
         */
        getSelectionRegion: function() {
            var direction,
                region;

            direction = CKEDITOR.SELECTION_TOP_TO_BOTTOM;

            region = this.getClientRectsRegion();

            region.direction = this._getSelectionDirection();

            region.height = region.bottom - region.top;
            region.width = region.right - region.left;

            return region;
        },

        /**
         * Returns true if the current selection is empty, false otherwise.
         *
         * @method isSelectionEmpty
         * @return {Boolean} Returns true if the current selection is empty, false otherwise.
         */
        isSelectionEmpty: function() {
            var ranges,
                selection = this.getSelection();

            return (selection.getType() === CKEDITOR.SELECTION_NONE) ||
                ((ranges = selection.getRanges()) && ranges.length === 1 && ranges[0].collapsed);
        },

        /**
         * Returns object with data about the [client rectangles](https://developer.mozilla.org/en-US/docs/Web/API/Element.getClientRects) of the selection,
         * normalized across browses. All offsets below are in page coordinates.
         *
         * @method getClientRectsRegion
         * @return {Object} Returns object with the following data:
         * - bottom - bottom offset of all client rectangles
         * - left - left offset of all client rectangles
         * - right - right offset of all client rectangles
         * - top - top offset of all client rectangles
         * - startRect - An Object, which contains the following information:
         *     + bottom - bottom offset
         *     + height - the height of the rectangle
         *     + left - left offset of the selection
         *     + right - right offset of the selection
         *     + top - top offset of the selection
         *     + width - the width of the rectangle
         * - endRect - An Object, which contains the following information:
         *     + bottom - bottom offset
         *     + height - the height of the rectangle
         *     + left - left offset of the selection
         *     + right - right offset of the selection
         *     + top - top offset of the selection
         *     + width - the width of the rectangle
         */
        getClientRectsRegion: function() {
            var bottom,
                clientRects,
                endRect,
                i,
                item,
                left,
                length,
                nativeSelection,
                range,
                rangeCount,
                region,
                right,
                selection,
                scrollPos,
                startRect,
                top;

            selection = this.getSelection();
            nativeSelection = selection.getNative();

            if (nativeSelection.createRange) {
                range = nativeSelection.createRange();
                clientRects = range.getClientRects();
            } else {
                rangeCount = nativeSelection.rangeCount;
                clientRects = (nativeSelection.rangeCount > 0) ? nativeSelection.getRangeAt(0).getClientRects() : [];
            }

            bottom = 0;
            left = Infinity;
            right = -Infinity;
            top = Infinity;

            if (clientRects.length === 0) {
                region = this.getCaretRegion();
            } else {
                for (i = 0, length = clientRects.length; i < length; i++) {
                    item = clientRects[i];

                    if (item.left < left) {
                        left = item.left;
                    }

                    if (item.right > right) {
                        right = item.right;
                    }

                    if (item.top < top) {
                        top = item.top;
                    }

                    if (item.bottom > bottom) {
                        bottom = item.bottom;
                    }
                }

                scrollPos = new CKEDITOR.dom.window(window).getScrollPosition();

                region = {
                    bottom: scrollPos.y + bottom,
                    left: scrollPos.x + left,
                    right: scrollPos.x + right,
                    top: scrollPos.y + top
                };

                if (clientRects.length) {
                    endRect = clientRects[clientRects.length - 1];
                    startRect = clientRects[0];

                    region.endRect = {
                        bottom: scrollPos.y + endRect.bottom,
                        height: endRect.height,
                        left: scrollPos.x + endRect.left,
                        right: scrollPos.x + endRect.right,
                        top: scrollPos.y + endRect.top,
                        width: endRect.width
                    };

                    region.startRect = {
                        bottom: scrollPos.y + startRect.bottom,
                        height: startRect.height,
                        left: scrollPos.x + startRect.left,
                        right: scrollPos.x + startRect.right,
                        top: scrollPos.y + startRect.top,
                        width: startRect.width
                    };
                }
            }

            return region;
        },

        /**
         * Retrieves the direction of the selection. The direction is from top to bottom or from bottom to top.
         * For IE < 9 it is not possible, so the direction for these browsers will be always CKEDITOR.SELECTION_TOP_TO_BOTTOM.
         *
         * @method _getSelectionDirection
         * @protected
         * @return {Number} Returns a number which represents selection direction. It might be one of these:
         * - CKEDITOR.SELECTION_TOP_TO_BOTTOM;
         * - CKEDITOR.SELECTION_BOTTOM_TO_TOP;
         */
        _getSelectionDirection: function() {
            var anchorNode,
                direction,
                nativeSelection,
                position,
                selection;

            selection = this.getSelection();
            nativeSelection = selection.getNative();

            direction = CKEDITOR.SELECTION_TOP_TO_BOTTOM;

            if ((anchorNode = nativeSelection.anchorNode) && anchorNode.compareDocumentPosition) {
                position = anchorNode.compareDocumentPosition(nativeSelection.focusNode);

                if (!position && nativeSelection.anchorOffset > nativeSelection.focusOffset || position === Node.DOCUMENT_POSITION_PRECEDING) {
                    direction = CKEDITOR.SELECTION_BOTTOM_TO_TOP;
                }
            }

            return direction;
        }
    };

    CKEDITOR.plugins.add(
        'selectionregion', {
            /**
             * Initializer lifecycle implementation for the SelectionRegion plugin.
             *
             * @method init
             * @protected
             * @param {Object} editor The current CKEditor instance.
             */
            init: function(editor) {
                var attr,
                    hasOwnProperty;

                hasOwnProperty = Object.prototype.hasOwnProperty;

                for (attr in SelectionRegion.prototype) {
                    if (hasOwnProperty.call(SelectionRegion.prototype, attr) && typeof editor[attr] == 'undefined') {
                        editor[attr] = SelectionRegion.prototype[attr];
                    }
                }
            }
        }
    );
}());
(function() {
    'use strict';

    /**
     * CKEDITOR.tools class utility which adds additional methods to those of CKEditor.
     *
     * @class CKEDITOR.tools
     */

    /**
     * Returns a new object containing all of the properties of all the supplied
     * objects. The properties from later objects will overwrite those in earlier
     * objects.
     *
     * Passing in a single object will create a shallow copy of it.
     *
     * @method merge
     * @param {Object} objects* One or more objects to merge.
     * @return {Object} A new merged object.
     */
    CKEDITOR.tools.merge = CKEDITOR.tools.merge || function() {
        var i = 0,
            key,
            len = arguments.length,
            obj,
            result = {};

        for (; i < len; ++i) {
            obj = arguments[i];

            for (key in obj) {
                if (hasOwnProperty.call(obj, key)) {
                    result[key] = obj[key];
                }
            }
        }

        return result;
    };
}());
(function() {
    'use strict';

    if (CKEDITOR.plugins.get('uicore')) {
        return;
    }

    /**
     * UICore class which will handle user interactions with the editor. These interactions
     * might be triggered via mouse, keyboard or touch devices. The class fill fire an event via
     * CKEditor's event system - "editorInteraction". The UI may listen to this event and
     * execute some actions - for example to show/hide toolbars.
     *
     * By default if user presses the Esc key, 'editorInteraction' event won't be fired. However, this behaviour can be changed
     * by setting {{#crossLink "CKEDITOR.plugins.uicore/allowEsc:attribute"}}{{/crossLink}} config property in editor's configuration to true.
     *
     * @class CKEDITOR.plugins.uicore
     */

    /**
     * Fired when user interacts somehow with the browser. This may be clicking with the mouse, pressing keyboard button,
     * or touching screen. This even will be not fired after each interaction. It will be debounced. By default the timeout
     * is 50ms. This value can be overwritten via {{#crossLink "CKEDITOR.plugins.uicore/timeout:attribute"}}{{/crossLink}}
     * property of editor's configuration, like: editor.config.uicore.timeout = 100
     *
     * @event editorInteraction
     * @param {Object} data An object which contains the following properties:
     * - nativeEvent - The event as received from CKEditor.
     * - selectionData - The data, returned from {{#crossLink "CKEDITOR.plugins.selectionregion/getSelectionData:method"}}{{/crossLink}}
     */

     /**
      * Fired by UI elements like Toolbars or Buttons when their state changes. The listener updates the live region with the provided data.
      *
      * @event ariaUpdate
      * @param {Object} data An object which contains the following properties:
      * - message - The provided message from the UI element.
      */

    /**
     * If set to true, the editor will still fire {{#crossLink "CKEDITOR.plugins.uicore/editorInteraction:event"}}{{/crossLink}} event,
     * if user presses Esc key.
     *
     * @attribute allowEsc
     * @default false
     * @type Boolean
     */

    /**
     * Specifies the default timeout after which the {{#crossLink "CKEDITOR.plugins.uicore/editorInteraction:event"}}{{/crossLink}} event
     * will be fired.
     *
     * @attribute timeout
     * @default 50 (ms)
     * @type Number
     */

    CKEDITOR.plugins.add(
        'uicore', {
            /**
             * Initializer lifecycle implementation for the UICore plugin.
             *
             * @method init
             * @protected
             * @param {Object} editor The current CKEditor instance.
             */
            init: function(editor) {
                var ariaElement,
                    ariaState = [],
                    handleAria,
                    handleUI,
                    uiTasksTimeout;

                ariaElement = this._createAriaElement(editor.id);

                uiTasksTimeout = editor.config.uicore ? editor.config.uicore.timeout : 50;

                handleAria = CKEDITOR.tools.debounce(
                    function(event) {
                        ariaElement.innerHTML = ariaState.join('. ');
                    },
                    uiTasksTimeout
                );

                handleUI = CKEDITOR.tools.debounce(
                    function(event) {
                        ariaState = [];

                        if (event.name !== 'keyup' || event.data.$.keyCode !== 27 || editor.config.allowEsc) {
                            editor.fire('editorInteraction', {
                                nativeEvent: event.data.$,
                                selectionData: editor.getSelectionData()
                            });
                        }
                    },
                    uiTasksTimeout
                );

                editor.on('ariaUpdate', function(event) {
                    // handleAria is debounced function, so if it is being called multiple times, it will
                    // be canceled until some time passes.
                    // For that reason here we explicitly append the current message to the list of messages
                    // and call handleAria. Since it is debounced, when some timeout passes,
                    // all the messages will be applied to the live region and not only the last one.

                    ariaState.push(event.data.message);

                    handleAria();
                });

                editor.on('contentDom', function() {
                    var editable = editor.editable();

                    editable.attachListener(editable, 'mouseup', handleUI);
                    editable.attachListener(editable, 'keyup', handleUI);
                });
            },

            /**
             * Creates and applies an HTML element to the body of the document which will contain ARIA messages.
             *
             * @method _createAriaElement
             * @protected
             * @param {String} id The provided id of the element. It will be used as prefix for the final element Id.
             * @return {HTMLElement} The created and applied to DOM element.
             */
            _createAriaElement: function(id) {
                var statusElement;

                statusElement = document.createElement('div');

                statusElement.className = 'sr-only';

                statusElement.setAttribute('aria-live', 'polite');
                statusElement.setAttribute('role', 'status');
                statusElement.setAttribute('id', id + 'LiveRegion');

                document.body.appendChild(statusElement);

                return statusElement;
            }
        }
    );
}());
CKEDITOR.disableAutoInline = true;

YUI.add('alloy-editor', function(Y) {
    'use strict';

    var Lang = Y.Lang,
        AlloyEditor,

        KEY_ESC = 27,
        KEY_F10 = 121,
        KEY_TAB = 9;

    /**
     * YUI3 Adapter for CKEditor. This class provides YUI3 like way of creating instances of
     * CKEditor and passing configuration paramters to it.
     *
     * @class AlloyEditor
     * @constructor
     */
    AlloyEditor = Y.Base.create('alloyEditor', Y.Base, [], {

        /**
         * Initializer lifecycle implementation for the AlloyEditor class. Creates a CKEditor
         * instace, passing it the provided configuration attributes.
         *
         * @method initializer
         * @protected
         * @param config {Object} Configuration object literal for the editor.
         */
        initializer: function(config) {
            var editor,
                eventsDelay,
                node;

            node = this.get('srcNode');

            editor = CKEDITOR.inline(node.getDOMNode());

            editor.config.allowedContent = this.get('allowedContent');

            editor.config.toolbars = this.get('toolbars');

            editor.config.removePlugins = this.get('removePlugins');
            editor.config.extraPlugins = this.get('extraPlugins');
            editor.config.placeholderClass = this.get('placeholderClass');

            Y.mix(editor.config, config);

            this._editor = editor;

            eventsDelay = this.get('eventsDelay');

            this._eventHandles = [
                Y.one(Y.config.doc).on(['click', 'keydown'],
                    CKEDITOR.tools.debounce(this._onDocInteract, eventsDelay, this)),
                node.on('keydown',
                    CKEDITOR.tools.debounce(this._onEditorKey, eventsDelay, this))
            ];

            // Custom events will be attached automatically, there is no need to put them in to the list
            // with event handles
            editor.on('toolbarKey', this._onToolbarKey, this);

            editor.on('toolbarActive', this._onToolbarActive, this);
        },

        /**
         * Destructor lifecycle implementation for the AlloyEdtor class. Destroys the CKEditor
         * instance and destroys all created toolbars.
         *
         * @method destructor
         * @protected
         */
        destructor: function() {
            var editorInstance;

            editorInstance = CKEDITOR.instances[this.get('srcNode').get('id')];

            if (editorInstance) {
                Y.Object.each(editorInstance.config.toolbars, function(value) {
                    value.destroy();
                });

                editorInstance.destroy();
            }

            (new Y.EventHandle(this._eventHandles)).detach();
        },

        /**
         * Searches among toolbars to find the next toolbar that should be focused.
         *
         * @method _focusNextToolbar
         * @protected
         */
        _focusNextToolbar: function() {
            var activeToolbar,
                currentToolbarIndex,
                lastPart,
                toolbars;

            activeToolbar = this._activeToolbar;

            toolbars = this._editor.config.toolbars;

            //We need to convert toolbars to an array so we can reorder them.
            toolbars = Y.Object.keys(toolbars).map(function(item) {
                return toolbars[item];
            });

            currentToolbarIndex = Y.Array.indexOf(toolbars, activeToolbar);

            lastPart = toolbars.splice(currentToolbarIndex);

            toolbars = lastPart.concat(toolbars);

            Y.Array.some(toolbars, function(toolbar) {
                if (toolbar !== activeToolbar && toolbar.focus()) {
                    this._activeToolbar = toolbar;

                    return true;
                }
            }, this);
        },

        /**
         * Focuses the first visible toolbar in editor or if there is not any, focuses the last of the other
         * toolbars which accept the request for focusing.
         *
         * @method _focusVisibleToolbar
         * @protected
         */
        _focusVisibleToolbar: function() {
            Y.Object.some(this._editor.config.toolbars, function(toolbar) {
                if (toolbar != this._activeToolbar && toolbar.focus()) {
                    this._activeToolbar = toolbar;

                    return toolbar.get('visible');
                }
            }, this);
        },

        /**
         * Retrieves the native CKEditor instance. Having this, the developer may use the API of CKEditor OOTB.
         *
         * @method _getNativeEditor
         * @protected
         * @return {Object} The current instance of CKEditor.
         */
        _getNativeEditor: function() {
            return this._editor;
        },

        /**
         * Hide all visible toolbars in editor
         *
         * @method _hideToolbars
         * @protected
         */
        _hideToolbars: function() {
            Y.Object.each(this._editor.config.toolbars, function(toolbar) {
                toolbar.hide();
            });
        },

        /**
         * Fires <code>toolbarsHide</code> event if none of the toolbars or their child nodes is the element user is
         * currently interacting.
         *
         * @method _onDocInteract
         * @protected
         * @param {EventFacade} event EventFacade object
         */
        _onDocInteract: function(event) {
            var editorInstance,
                result,
                srcNode;

            srcNode = this.get('srcNode');

            result = (srcNode === event.target) || (srcNode.contains(event.target));

            editorInstance = CKEDITOR.instances[srcNode.get('id')];

            result = result || Y.some(editorInstance.config.toolbars, function(toolbar) {
                return toolbar.ownsNode(event.target);
            });

            if (!result) {
                this._editor.fire('toolbarsHide');
            }
        },

        /**
         * Handles key events in the editor:
         *  - ALT + F10: focus the toolbar
         *  - ESC: hide visible toolbars
         *
         * @method _onEditorKey
         * @param {EventFacade} event Event that triggered when user pressed a key inside the editor.
         * @protected
         */
        _onEditorKey: function(event) {
            if (event.altKey && event.keyCode === KEY_F10) {
                this._focusVisibleToolbar();

            } else if (event.keyCode === KEY_ESC) {
                this._hideToolbars();
            }
        },

        /**
         * Handles activating a toolbar.
         *
         * @method _onToolbarActive
         * @protected
         */
        _onToolbarActive: function(event) {
            this._activeToolbar = event.data;
        },

        /**
         * Handles key events in the toolbar:
         *  - TAB: focus next toolbar
         *  - ESC: focus the editor
         *
         * @method _onToolbarKey
         * @param {Event} event keyboard event
         * @protected
         */
        _onToolbarKey: function(event) {
            if (event.data.keyCode === KEY_TAB) {
                event.data.preventDefault();
                this._focusNextToolbar();

            } else if (event.data.keyCode === KEY_ESC) {
                this._activeToolbar.blur();
                this._activeToolbar = null;

                this._hideToolbars();
            }
        },

        /**
         * Validates the allowed content attribute. Look
         * [here](http://docs.ckeditor.com/#!/api/CKEDITOR.config-cfg-allowedContent) for more information about the
         * supported values.
         *
         * @method _validateAllowedContent
         * @protected
         * @return {Boolean} True if the value was accepted, false otherwise.
         */
        _validateAllowedContent: function(value) {
            return Lang.isString(value) || Lang.isObject(value) || Lang.isBoolean(value);
        },

        /**
         * Validates toolbars attribute. May be empty string or null, which means the current instance of AlloyEdtor
         * shouldn't have any toolbars, or Object, which properties are the desired toolbars.
         *
         * @method _validateToolbars
         * @protected
         * @param {Any} value The value which should be validated.
         * @return {Boolean} True if the value was accepted, false otherwise.
         */
        _validateToolbars: function(value) {
            return (value === '' || Lang.isObject(value) || Lang.isNull(value));
        }
    }, {
        ATTRS: {
            /**
             * Configures the allowed content for the current instance of AlloyEditor.
             * Look on the [official CKEditor API](http://docs.ckeditor.com/#!/api/CKEDITOR.config-cfg-allowedContent)
             * for more information about the valid values.
             *
             * @attribute allowedContent
             * @default true
             * @writeOnce
             * @type {Boolean, String, Object}
             */
            allowedContent: {
                validator: '_validateAllowedContent',
                value: true,
                writeOnce: true
            },

            /**
             * The delay (timeout), in ms, after which events such like key or mouse events will be processed.
             *
             * @attribute eventsDelay
             * @type {Number}
             */
            eventsDelay: {
                validator: Lang.isNumber,
                value: 100
            },

            /**
             * Specifies the extra plugins which have to be loaded to the current CKEditor instance in order to
             * make AlloyEditor to work properly.
             *
             * @attribute extraPlugins
             * @default 'uicore,selectionregion,dropimages,placeholder,linktooltip,uiloader'
             * @writeOnce
             * @type {String}
             */
            extraPlugins: {
                validator: Lang.isString,
                value: 'uicore,selectionregion,dropimages,placeholder,linktooltip,uiloader',
                writeOnce: true
            },

            /**
             * Retrieves the native CKEditor instance. Having this, the developer may use the full API of CKEditor.
             *
             * @attribute nativeEditor
             * @readOnly
             * @type {Object}
             */
            nativeEditor: {
                getter: '_getNativeEditor',
                readOnly: true
            },

            /**
             * Specifies the class, which should be added by Placeholder plugin
             * {{#crossLink "CKEDITOR.plugins.placeholder}}{{/crossLink}}
             * when editor is not focused.
             *
             * @attribute placeholderClass
             * @default 'alloy-editor-placeholder'
             * @writeOnce
             * @type {String}
             */
            placeholderClass: {
                validator: Lang.isString,
                value: 'alloy-editor-placeholder',
                writeOnce: true
            },

            /**
             * Specifies the plugins, which come by default with CKEditor, but which are not needed by AlloyEditor.
             * These plugins add the default UI for CKeditor, which is no more needed. Please note that AlloyEdtor
             * comes with its own highly optimized copy of CKEditor (just customized via their official download page).
             * This version does not come with the unneeded plugins, so the value of this property won't be needed.
             * However, if you decide to go with the OOTB version of CKEditor, you will have to remove some of the
             * plugins if you decide to use AlloyEditor. Keep in mind that removing these plugins doesn't remove them
             * entirely from CKEditor. It just removes them from its current instance, in which you will use different
             * UI - those of AlloyEditor. You will be fully able to use both OOTB CKEditor and AlloyEditor on the same
             * page!
             *
             * @attribute removePlugins
             * @default 'contextmenu,toolbar,elementspath,resize,liststyle,tabletools,link'
             * @writeOnce
             * @type {String}
             */
            removePlugins: {
                validator: Lang.isString,
                value: 'contextmenu,toolbar,elementspath,resize,liststyle,tabletools,link',
                writeOnce: true
            },

            /**
             * The Node ID or HTMl node, which should be turned to an instance of AlloyEditor.
             *
             * @attribute srcNode
             * @type String | Node
             * @writeOnce
             */
            srcNode: {
                setter: Y.one,
                writeOnce: true
            },

            /**
             * Specifies the Toolbars of the current editor instance. The value should be an object
             * with one or more properties. Each of these will represent a toolbar. The value of these properties
             * can be string or Object. If String, the value of the string should represent the buttons. If object,
             * one of these properties should be 'buttons', which will represent the buttons of this Toolbar and
             * all the other properties will be different configuration parameters of the Toolbar. Example:
             * <pre><code>
             *     toolbars: {
             *         table: { // this would be a toolbar configuration, which specifies both Toolbar attributes and its buttons
             *             buttons: ['button1', button2],
             *             width: 25
             *         },
             *         add: ['image', 'code'], // here we specify only the buttons of this toolbar and leave the other options unmodified.
             *         image: ['left', 'right'],
             *         styles: ['strong', 'em', 'u', 'h1', 'h2', 'a', 'twitter']
             *     }
             * </pre></code>
             *
             * @default
             *     toolbars {
             *         add: ['image'],
             *         image: ['left', 'right'],
             *         styles: ['strong', 'em', 'u', 'h1', 'h2', 'a', 'twitter']
             *     }
             * @attribute toolbars
             * @type Object
             */
            toolbars: {
                validator: '_validateToolbars',
                value: {
                    add: ['image'],
                    image: ['left', 'right'],
                    styles: ['strong', 'em', 'u', 'h1', 'h2', 'a', 'twitter']
                }
            }
        }
    });

    Y.AlloyEditor = AlloyEditor;
}, '', {
    requires: ['base-build', 'node-base']
});
(function() {
    'use strict';

    var isIE = CKEDITOR.env.ie;

    if (CKEDITOR.plugins.get('dropimages')) {
        return;
    }

    /**
     * CKEditor plugin which allows Drag&Drop of images directly into the edit area. The image will be encoded
     * as Data URI.
     *
     * @class CKEDITOR.plugins.dropimages
     */
    CKEDITOR.plugins.add(
        'dropimages', {
            /**
             * Initialization of the plugin, part of CKEditor plugin lifecycle.
             * The function registers a 'dragenter', 'dragover' and 'drop' events on the editing area.
             *
             * @method init
             * @param {Object} editor The current editor instance
             */
            init: function(editor) {
                var editable;

                editable = new CKEDITOR.editable(editor, editor.element.$);

                editable.attachListener(editable, 'dragenter', this._onDragEnter, this, {
                    editor: editor
                });

                editable.attachListener(editable, 'dragover', this._onDragOver, this, {
                    editor: editor
                });

                editable.attachListener(editable, 'drop', this._onDragDrop, this, {
                    editor: editor
                });
            },

            /**
             * Accepts an array of dropped files to the editor. Then, it filters the images and sends them for further
             * processing to {{#crossLink "CKEDITOR.plugins.dropimages/_processFile:method"}}{{/crossLink}}
             *
             * @method _handleFiles
             * @protected
             * @param {Array} files Array of dropped files. Only the images from this list will be processed.
             * @param {Object} editor The current editor instance
             */
            _handleFiles: function(files, editor) {
                var i,
                    imageType,
                    file;

                for (i = 0; i < files.length; i++) {
                    file = files[i];
                    imageType = /image.*/;

                    if (file.type.match(imageType)) {
                        this._processFile(file, editor);
                    }
                }

                return false;
            },

            /**
             * Handles drag enter event. In case of IE, this function will prevent the event.
             *
             * @method _onDragEnter
             * @protected
             * @param {DOM event} event dragenter event, as received natively from CKEditor
             */
            _onDragEnter: function(event) {
                if (isIE) {
                    this._preventEvent(event);
                }
            },

            /**
             * Handles drag over event. In case of IE, this function will prevent the event.
             *
             * @method _onDragOver
             * @protected
             * @param {DOM event} event dragover event, as received natively from CKEditor
             */
            _onDragOver: function(event) {
                if (isIE) {
                    this._preventEvent(event);
                }
            },

            /**
             * Handles drag drop event. The function will create selection from the current points and
             * will send a list of files to be processed to
             * {{#crossLink "CKEDITOR.plugins.dropimages/_handleFiles:method"}}{{/crossLink}}
             *
             * @method _onDragDrop
             * @protected
             * @param {CKEDITOR.dom.event} event dragdrop event, as received natively from CKEditor
             */
            _onDragDrop: function(event) {
                var editor,
                    nativeEvent;

                nativeEvent = event.data.$;

                new CKEDITOR.dom.event(nativeEvent).preventDefault();

                editor = event.listenerData.editor;

                event.listenerData.editor.createSelectionFromPoint(nativeEvent.clientX, nativeEvent.clientY);

                this._handleFiles(nativeEvent.dataTransfer.files, editor);
            },

            /**
             * Prevents a native event.
             *
             * @method _preventEvent
             * @protected
             * @param {DOM event} event The event to be prevented.
             */
            _preventEvent: function(event) {
                event = new CKEDITOR.dom.event(event.data.$);

                event.preventDefault();
                event.stopPropagation();
            },

            /**
             * Processes an image file. The function creates an element and sets a source
             * a Data URI, then fires an event 'imagedrop' via CKEditor event system.
             *
             * @method _preventEvent
             * @protected
             * @param {DOM event} event The event to be prevented.
             */
            _processFile: function(file, editor) {
                var reader = new FileReader();

                reader.addEventListener('loadend', function() {
                    var bin,
                        el;

                    bin = reader.result;

                    el = CKEDITOR.dom.element.createFromHtml('<img src="' + bin + '">');

                    editor.insertElement(el);

                    editor.fire('imagedrop', el);
                });

                reader.readAsDataURL(file);
            }

            /**
             * Fired when an image is being added to the editor successfully.
             *
             * @event imagedrop
             * @param {CKEDITOR.dom.element} el The created image with src, created as Data URI
             */
        }
    );
}());
(function() {
    'use strict';

    if (CKEDITOR.plugins.get('placeholder')) {
        return;
    }

    /**
     * CKEditor plugin which allows adding a placeholder to the editor. In this case, if there
     * is no content to the editor, there will be hint to the user.
     *
     * @class CKEDITOR.plugins.placeholder
     */

    /**
     * Specifies the placeholder class which have to be aded to editor when editor is not focuced.
     *
     * @attribute placeholderClass
     * @default alloy-editor-placeholder
     * @type String
     */

    CKEDITOR.plugins.add(
        'placeholder', {

            /**
             * Initialization of the plugin, part of CKEditor plugin lifecycle.
             * The function registers a 'blur' listener to CKEditor's blur event.
             *
             * @method init
             * @param {Object} editor The current editor instance
             */
            init: function(editor) {
                editor.on('blur', this._onBlur, this);
            },

            /**
             * Handles the fired blur event. The function removes any data from CKEditor, because an
             * empty paragraph may still exist despite for the user the editor looks empty and
             * adds a class, specified via "placeholderClass" config attribute.
             *
             * @method init
             * @protected
             * @param {CKEDITOR.dom.event} editor Blur event, fired from CKEditor
             */
            _onBlur: function(event) {
                var editor,
                    editorNode;

                editor = event.editor;

                if (editor.getData() === '') {
                    editorNode = new CKEDITOR.dom.element(editor.element.$);

                    // Despite getData() returns empty string, the content still may have
                    // content - an empty paragrapgh. This prevents :empty selector in
                    // placeholder's CSS and placeholder does not appear.
                    // For that reason we will intentionally remove any content from editorNode.
                    editorNode.setHtml('');

                    editorNode.addClass(editor.config.placeholderClass);
                }
            }
        }
    );
}());
;(function() {
    'use strict';

    var modules = {
    'alloy-editor': {
        path: 'adapter/yui.js',
        requires: ['base-build', 'node-base']
    },

    'button-base': {
        group: 'AlloyEditor',
        path: 'buttons/button-base.js',
        requires: ['base-build', 'plugin', 'button']
    },

    'button-strong': {
        group: 'AlloyEditor',
        path: 'buttons/button-strong.js',
        requires: ['button-base']
    },

    'button-em': {
        group: 'AlloyEditor',
        path: 'buttons/button-em.js',
        requires: ['button-base']
    },

    'button-a': {
        group: 'AlloyEditor',
        path: 'buttons/button-a.js',
        requires: ['button-base', 'event-valuechange', 'node-focusmanager']
    },

    'button-h1': {
        group: 'AlloyEditor',
        path: 'buttons/button-h1.js',
        requires: ['button-base']
    },

    'button-h2': {
        group: 'AlloyEditor',
        path: 'buttons/button-h2.js',
        requires: ['button-base']
    },

    'button-u': {
        group: 'AlloyEditor',
        path: 'buttons/button-underline.js',
        requires: ['button-base']
    },

    'button-twitterquote': {
        group: 'AlloyEditor',
        path: 'buttons/button-twitterquote.js',
        requires: ['button-base']
    },

    'button-hline': {
        group: 'AlloyEditor',
        path: 'buttons/button-hline.js',
        requires: ['button-base']
    },

    'button-image': {
        group: 'AlloyEditor',
        path: 'buttons/button-image.js',
        requires: ['button-base', 'node-event-simulate']
    },

    'button-media': {
        group: 'AlloyEditor',
        path: 'buttons/button-media.js',
        requires: ['button-base']
    },

    'button-quote': {
        group: 'AlloyEditor',
        path: 'buttons/button-quote.js',
        requires: ['button-base']
    },

    'button-code': {
        group: 'AlloyEditor',
        path: 'buttons/button-code.js',
        requires: ['button-base']
    },

    'button-twitter': {
        group: 'AlloyEditor',
        path: 'buttons/button-twitter.js',
        requires: ['button-base']
    },

    'button-left': {
        group: 'AlloyEditor',
        path: 'buttons/button-left.js',
        requires: ['button-base']
    },

    'button-right': {
        group: 'AlloyEditor',
        path: 'buttons/button-right.js',
        requires: ['button-base']
    },

    'button-rotate': {
        group: 'AlloyEditor',
        path: 'buttons/button-rotate.js',
        requires: ['button-base']
    },

    'button-filter': {
        group: 'AlloyEditor',
        path: 'buttons/button-filter.js',
        requires: ['button-base']
    },

    'toolbar-base': {
        group: 'AlloyEditor',
        path: 'toolbars/toolbar-base.js',
        requires: ['plugin', 'node-base', 'transition']
    },

    'toolbar-position': {
        group: 'AlloyEditor',
        path: 'toolbars/toolbar-position.js',
        requires: ['node-base']
    },

    'toolbar-add': {
        group: 'AlloyEditor',
        path: 'toolbars/toolbar-add.js',
        requires: ['widget-base', 'widget-position', 'widget-position-constrain', 'widget-position-align', 'toolbar-base']
    },

    'toolbar-styles': {
        group: 'AlloyEditor',
        path: 'toolbars/toolbar-styles.js',
        requires: ['toolbar-base', 'widget-base', 'widget-position', 'widget-position-constrain']
    },

    'toolbar-image': {
        group: 'AlloyEditor',
        path: 'toolbars/toolbar-image.js',
        requires: ['dom-screen', 'widget-base', 'widget-position', 'widget-position-constrain', 'toolbar-base']
    },

    'selector-patch': {
        condition: {
            trigger: 'selector-native'
        },
        group: 'AlloyEditor',
        path: 'plugins/selector-patch.js'
    }
};

    function applyConfigGroup() {
        YUI.applyConfig({
            groups: {
                AlloyEditor: {
                    base: 'alloy-editor/',
                    combine: false,
                    comboBase: '',
                    modules: modules,
                    root: '/alloy-editor/'
                }
            }
        });
    }

    function applyConfigModules() {
        YUI.applyConfig({
            modules: modules
        });
    }

    if (YUI && YUI.GlobalConfig) {
        var groups = YUI.GlobalConfig.groups;

        if (groups && groups.AlloyEditor) {
            applyConfigModules();
        }
        else {
            applyConfigGroup();
        }
    }
    else {
        applyConfigGroup();
    }
}());
(function() {
    'use strict';

    if (CKEDITOR.plugins.get('linktooltip')) {
        return;
    }

    YUI.add('linktooltip', function(Y) {
        var Lang = Y.Lang,

            /**
             * The LinkTooltip class provides functionality for showing tooltip over link elements in editor.
             * The class will be also registered as CKEDITOR plugin -
             * {{#crossLink "CKEDITOR.plugins.linktooltip"}}{{/crossLink}}
             *
             * @class LinkTooltip
             */
            LinkTooltip = Y.Base.create('linktooltip', Y.Widget, [Y.WidgetPosition, Y.WidgetPositionConstrain,
                Y.WidgetAutohide], {
                /**
                 * Initializer lifecycle implementation for the LinkTooltip class.
                 *
                 * @method initializer
                 * @protected
                 * @param config {Object} Configuration object literal for the editor
                 */
                initializer: function() {
                    this._eventHandles = [];
                },

                /**
                 * Destructor lifecycle implementation for the LinkTooltip class. Destroys the iattached event
                 * listeners.
                 *
                 * @method destructor
                 * @protected
                 */
                destructor: function() {
                    (new Y.EventHandle(this._eventHandles)).detach();
                },

                /**
                 * Renders the link tooltip node on contentBox.
                 *
                 * @method renderUI
                 * @protected
                 */
                renderUI: function() {
                    var content;

                    content = Y.Node.create(this.TPL_CONTENT);

                    this.get('contentBox').appendChild(content);

                    this._linkPreview = content.one('.link-preview');
                },

                /**
                 * Attaches event listeners such as mouseenter on link elements. Links, which have
                 * "data-cke-default-link" attribute will be ignored. These links are considered as
                 * internal; they are being created by automatically when user triggers link creation.
                 * See {{#crossLink "ButtonA/_onClick:method"}}{{/crossLink}} for more information.
                 *
                 * @method bindUI
                 * @protected
                 */
                bindUI: function() {
                    var editor;

                    this._bindBBMouseEnter();

                    editor = this.get('editor');

                    this._eventHandles.push(
                        Y.one(editor.element.$).delegate('mouseenter', this._onLinkMouseEnter,
                            'a[href]:not([data-cke-default-link])', this, editor)
                    );

                    this.get('boundingBox').on('clickoutside', this._onClickOutside, this);
                },

                /**
                 * Adds mouseleave listener to the boundingBox.
                 *
                 * @method _bindBBMouseLeave
                 * @protected
                 */
                _bindBBMouseLeave: function() {
                    var boundingBox;

                    boundingBox = this.get('boundingBox');

                    this._bbMouseLeaveHandle = boundingBox.once('mouseleave', this._onBBMouseLeave, this);
                },

                /**
                 * Adds mouseenter listener to the boundingBox.
                 *
                 * @method _bindBBMouseEnter
                 * @protected
                 */
                _bindBBMouseEnter: function() {
                    var boundingBox;

                    boundingBox = this.get('boundingBox');

                    this._bbMouseEnterHandle = boundingBox.on('mouseenter', this._onBBMouseEnter, this);
                },

                /**
                 * Hides the linktooltip container after some timeout, specified by
                 * {{#crossLink "LinkTooltip/hideTimeout:attribute"}}{{/crossLink}} attribute.
                 *
                 * @method _attachHiddenHandle
                 * @protected
                 */
                _attachHiddenHandle: function() {
                    var instance = this;

                    this._hideHandle = setTimeout(
                        function() {
                            instance.hide();
                        },
                        this.get('hideTimeout')
                    );
                },

                /**
                 * Calculates and returns the most appropriate position where link tooltip should appear.
                 * The position depends on the specified {{#crossLink "LinkTooltip/gutter:attribute"}}{{/crossLink}},
                 * and on the fact if the link occupies more than one line in the editor.
                 *
                 * @method _getXY
                 * @protected
                 * @param {Number} x Point X in page coordinates.
                 * @param {Number} y Point Y in page coordinates.
                 * @param {Node} y The link over which the tooltip should be shown.
                 * returns {Array} An Array with the most appropriate x and y points in page coordinates.
                 */
                _getXY: function(x, y, link) {
                    var gutter,
                        i,
                        line,
                        lineHeight,
                        lines,
                        region;

                    lineHeight = parseInt(link.getComputedStyle('lineHeight'), 10);

                    gutter = this.get('gutter');

                    region = link.get('region');

                    gutter = gutter.top;

                    if (Lang.isNumber(lineHeight)) {
                        line = 1;

                        lines = Math.ceil((region.bottom - region.top) / lineHeight);

                        for (i = 1; i <= lines; i++) {
                            if (y < region.top + lineHeight * i) {
                                break;
                            }

                            ++line;
                        }

                        y = region.top + line * lineHeight + gutter;
                    } else {
                        y = region.bottom + gutter;
                    }

                    return [x, y];
                },

                /**
                 * Handles mouse enter event on the boundingBox.
                 * Clears any already started hide handle and attaches mouse leave listener to the boundingBox.
                 *
                 * @method _onBBMouseEnter
                 * @protected
                 */
                _onBBMouseEnter: function() {
                    clearTimeout(this._hideHandle);

                    this._bindBBMouseLeave();
                },

                /**
                 * Handles mouse leave event on the boundingBox.
                 * Clears any already started hide handle and attaches it again.
                 *
                 * @method _onBBMouseEnter
                 * @protected
                 */
                _onBBMouseLeave: function() {
                    clearTimeout(this._hideHandle);

                    this._attachHiddenHandle();
                },

                /**
                 * Hides the tooltip on clicking outside of the boundingBox.
                 *
                 * @method _onClickOutside
                 * @protected
                 */
                _onClickOutside: function() {
                    this.hide();
                },

                /**
                 * Reads the link href, updates tooltip content with the read value,
                 * shows the tooltip and attaches mouse leave listener on the boundingBox.
                 *
                 * @method _onLinkMouseEnter
                 * @protected
                 * @param {EventFacade} event Event that triggered when user positioned the mouse over the link.
                 */
                _onLinkMouseEnter: function(event) {
                    var instance = this,
                        link,
                        linkText,
                        xy;

                    if (this._editMode) {
                        return;
                    }

                    clearTimeout(instance._hideHandle);

                    link = event.currentTarget;

                    linkText = link.getAttribute('href');

                    this._linkPreview.setAttribute('href', linkText);

                    this._linkPreview.set('innerHTML', Y.Escape.html(linkText));

                    instance.show();

                    xy = instance._getXY(event.pageX, event.pageY, link);

                    instance.set('xy', xy);

                    link.once('mouseleave', function() {
                        clearTimeout(instance._hideHandle);

                        instance._attachHiddenHandle();
                    });
                },

                BOUNDING_TEMPLATE: '<div class="alloy-editor-tooltip-link"></div>',

                TPL_CONTENT: '<div class="link-container">' +
                    '<span class="icon-link-container">' +
                    '<i class="alloy-editor-icon-link"></i>' +
                    '</span>' +
                    '<a class="link-preview" target="_blank"></a>' +
                    '</div>'
            }, {
                ATTRS: {
                    /**
                     * Specifies whether the toolbar show be constrained to some node or to the viewport.
                     *
                     * @attribute constrain
                     * @default true (will be constrained to the viewport)
                     * @type Boolean
                     */
                    constrain: {
                        validator: Lang.isBoolean,
                        value: true
                    },

                    /**
                     * Contains the native editor implementation.
                     *
                     * @attribute editor
                     * @default true
                     * @type Object
                     */
                    editor: {
                        validator: Y.Lang.isObject
                    },

                    /**
                     * Specifies the gutter of the tooltip. The gutter object contains the top and left
                     * offsets from the point, where the tooltip is supposed to appear.
                     *
                     * @attribute gutter
                     * @default {
                     *   left: 0,
                     *   top: 0
                     * }
                     * @type Object
                     */
                    gutter: {
                        validator: Lang.isObject,
                        value: {
                            left: 0,
                            top: 0
                        }
                    },

                    /**
                     * Specifies the timeout after which the link tooltip will be hidden.
                     *
                     * @attribute hideTimeout
                     * @default 2000 (sec)
                     * @type Number
                     */
                    hideTimeout: {
                        validator: Lang.isNumber,
                        value: 2000
                    }
                }
            });

        Y.LinkTooltip = LinkTooltip;

    }, '', {
        requires: ['dom-screen', 'escape', 'event-outside', 'node-event-delegate', 'event-mouseenter', 'widget-base',
            'widget-position', 'widget-position-constrain', 'widget-autohide']
    });

    /**
     * CKEDITOR plugin which allows displaying tooltip over links in the editor.
     * Internally it uses {{#crossLink "LinkTooltip"}}{{/crossLink}}. You may specify all
     * properties which {{#crossLink "LinkTooltip"}}{{/crossLink}} accepts via editor.config.linktooltip property.
     *
     * @class CKEDITOR.plugins.linktooltip
     */
    CKEDITOR.plugins.add(
        'linktooltip', {
            init: function(editor) {
                YUI().use('linktooltip', function(Y) {
                    var config,
                        tooltip;

                    config = Y.merge({
                        editor: editor,
                        visible: false
                    }, editor.config.linktooltip);

                    tooltip = new Y.LinkTooltip(config).render();

                    editor.on('destroy', function() {
                        tooltip.destroy();
                    });
                });
            }
        }
    );
}());
(function() {
    'use strict';

    var hasOwnProperty = Object.prototype.hasOwnProperty;

    if (CKEDITOR.plugins.get('uiloader')) {
        return;
    }

    /**
     * The CKEDITOR.plugins.uiloader plugin loads the editor UI on demand, depending on the
     * configuration of the Toolbars and Buttons.
     *
     * @class CKEDITOR.plugins.uiloader
     */
    CKEDITOR.plugins.add(
        'uiloader', {
            /**
             * Initializer lifecycle implementation for the UILoader plugin.
             *
             * @method init
             * @protected
             */
            init: function(editor) {
                var instance = this,
                    modules;

                modules = ['node-base'].concat(this._getModules(editor));

                YUI().use(
                    modules,
                    function(Y) {
                        instance._createToolbars(Y, editor);

                        editor.fire('toolbarsReady', {
                            toolbars: editor.config.toolbars
                        });
                    }
                );
            },

            /**
             * Creates instances of toolbars as specified by the editor configuration.
             * A simple editor toolbar configuration may look like this:
             * <pre><code>
             *   toolbars: {
             *       add: ['image', 'code']
             *   }
             * </code></pre>
             * In this case we have very simple configuration - the editor will have
             * only one toolbar, with two buttons - for adding images and code into the
             * editor. These buttons will also not have any specific configuration.
             * In order to pass configuration attributes to the toolbars, the configuration
             * may be specified like this:
             * <pre><code>
             *   toolbars: {
             *      add: {
             *           buttons: ['image', 'code'],
             *           zIndex: 1024
             *       }
             *   }
             * </code></pre>
             * In this case, toolbar "add" receives two attributes - the first one is the
             * list of buttons (each button also can be specified via an configuration object)
             * and another attribute, which specifies its zIndex.
             *
             * @method _createToolbars
             * @protected
             */
            _createToolbars: function(Y, editor) {
                var defaultConfig,
                    i,
                    toolbarsConfig;

                defaultConfig = {
                    editor: editor,
                    render: true,
                    visible: false
                };

                toolbarsConfig = editor.config.toolbars;

                for (i in toolbarsConfig) {
                    if (hasOwnProperty.call(toolbarsConfig, i)) {
                        if (CKEDITOR.tools.isArray(toolbarsConfig[i])) {
                            editor.config.toolbars[i] = new Y[this._getToolbarName(i)](
                                Y.merge(defaultConfig, {
                                    buttons: toolbarsConfig[i]
                                })
                            );
                        } else if (toolbarsConfig[i]) {
                            editor.config.toolbars[i] = new Y[this._getToolbarName(i)](
                                Y.merge(defaultConfig, toolbarsConfig[i])
                            );
                        }
                    }
                }
            },

            /**
             * Resolves the name of a button module passed through configuration.
             *
             * @method  _getButtonName
             * @protected
             * @param  {String|Object} button A string representing the button or an object
             * with a name attribute.
             * @return {String} The name of the button.
             */
            _getButtonName: function(button) {
                var buttonName = button;

                if (typeof button !== 'string') {
                    buttonName = button.name;
                }

                return buttonName
            },

            /**
             * Retrieves a list of modules for all registered buttons and toolbars in the current
             * editor configuration.
             * The module will be automatically discovered if it follows this specification:
             * - if this is a Toolbar, the module should start with the word "module", followed by "-"
             * and then the name of the toolbar. Example: 'toolbar-add'.
             * - if the module is an button, then the module should start with the word "button",
             * followed by "-" and then the name of the button. Example: "button-image".
             * - In order to be instantiated successfully, the toolbar should expose itself as an object,
             * attached to the current YUI/AlloyUI instance. The name should start with the name Toolbar,
             * followed by the name of the toolbar, as specified in the configuration. Example: Y.ToolbarAdd.
             * - In order to be instantiated successfully, the button should expose itself as an object,
             * attached to the current YUI/AlloyUI instance. The name should start with the name Button,
             * followed by the name of the button, as specified in the configuration. Example: Y.ButtonImage.
             *
             * @method _getModules
             * @protected
             * @return {Array} An array of all discovered modules of toolbars and buttons, as specified by
             * the current editor configuration.
             */
            _getModules: function(editor) {
                var i,
                    j,
                    modules,
                    toolbarsConfig;

                modules = [];

                toolbarsConfig = editor.config.toolbars;

                for (i in toolbarsConfig) {
                    if (hasOwnProperty.call(toolbarsConfig, i)) {
                        modules.push('toolbar-' + i); // put toolbar module

                        if (CKEDITOR.tools.isArray(toolbarsConfig[i])) {
                            for (j = toolbarsConfig[i].length - 1; j >= 0; j--) { // put button modules
                                modules.push('button-' + this._getButtonName(toolbarsConfig[i][j]));
                            }
                        } else if (toolbarsConfig[i]) {
                            for (j = toolbarsConfig[i].buttons.length - 1; j >= 0; j--) { // put button modules
                                modules.push('button-' + this._getButtonName(toolbarsConfig[i].buttons[j]));
                            }
                        }
                    }
                }

                return modules;
            },

            /**
             * Resolves the name of the Toolbar from the current editor configuration.
             * See {{#crossLink "CKEDITOR.plugins.uiloader/_getModules:method"}}{{/crossLink}}
             * for more information about the rules for constructing toolbar names.
             *
             * @method _getToolbarName
             * @protected
             * @return {String} The constructed name of the Toolbar.
             */
            _getToolbarName: function(name) {
                return 'Toolbar' + name.substring(0, 1).toUpperCase() + name.substring(1);
            }
        }
    );
}());
YUI.add('selector-patch', function(Y) {
    'use strict';

    Y.mix(Y.Selector, {
        test: function(node, selector, root) {
            var defaultId,
                ret = false,
                useFrag = false,
                groups,
                parent,
                item,
                items,
                frag,
                id,
                i, j, group;

            if (node && node.tagName) { // only test HTMLElements

                if (typeof selector == 'function') { // test with function
                    ret = selector.call(node, node);
                } else { // test with query
                    // we need a root if off-doc
                    groups = selector.split(',');
                    if (!root && !Y.DOM.inDoc(node)) {
                        parent = node.parentNode;
                        if (parent) {
                            root = parent;
                        } else { // only use frag when no parent to query
                            frag = node.ownerDocument.createDocumentFragment();
                            frag.appendChild(node);
                            root = frag;
                            useFrag = true;
                        }
                    }
                    root = root || node.ownerDocument;

                    id = Y.Selector._escapeId(Y.DOM.getId(node));
                    if (!id) {
                        defaultId = true;
                        id = Y.guid();
                        Y.DOM.setId(node, id);
                    }

                    for (i = 0; (group = groups[i++]);) { // TODO: off-dom test
                        group += '[id="' + id + '"]';
                        items = Y.Selector.query(group, root);

                        for (j = 0; (item = items[j++]);) {
                            if (item === node) {
                                ret = true;
                                break;
                            }
                        }
                        if (ret) {
                            break;
                        }
                    }

                    if (useFrag) { // cleanup
                        frag.removeChild(node);
                    }

                    if (defaultId) { // cleanup, remove auto added ID
                        node.removeAttribute('id');
                    }
                }
            }

            return ret;
        }
    }, true);
}, '', {
    requires: ['selector-native']
});
YUI.add('button-a', function(Y) {
    'use strict';

    var Lang = Y.Lang,
        YNode = Y.Node,

        KEY_ARROW_LEFT = 37,
        KEY_ARROW_RIGHT = 39,
        KEY_ENTER = 13,
        KEY_ESC = 27,
        KEY_TAB = 9,

        /**
         * The ButtonA class provides functionality for creating a link button.
         *
         * @class ButtonA
         */
        A = Y.Base.create('a', Y.Plugin.Base, [Y.ButtonBase], {
            /**
             * Initializer lifecycle implementation for the ButtonA class.
             *
             * @method initializer
             * @protected
             * @param  config {Object} Configuration object literal for the editor
             */
            initializer: function() {
                this._ckLink = new CKEDITOR.Link(this.get('host').get('editor'));
            },

            /**
             * Renders the button which handles the link creation on the current selection and
             * the UI, which provides input element where the user will be able to specify the
             * href of the link.
             *
             * @method renderUI
             * @protected
             */
            renderUI: function() {
                this._renderButtonUI();

                this._renderLinkUI();
            },

            /**
             * Binds event subscriptions from the UI and the source (if assigned).
             * Registers a few events, like handling key press, or mouse events on
             * the button for clearing the link.
             *
             * @method bindUI
             * @protected
             */
            bindUI: function() {
                this.onHostEvent('visibleChange', this._onVisibleChange, this);
                this.onHostEvent('positionChange', this._switchView, this);

                this._linkInput.on('keydown', this._onLinkInputKeyDown, this);
                this._linkInput.on('valuechange', this._onValueChange, this);

                this._switchToTextButton.on('click', this._onSwitchButtonClick, this);

                this._closeLink.on('click', this._onCloseLinkClick, this);
                this._clearInput.on('click', this._onClearInputClick, this);

                this._linkContainer.delegate('keydown', this._onLinkContainerKeyDown, 'button', this);
            },

            /**
             * Overwrites the default implementation from {{#crossLink "ButtonBase/updateUI:method"}}{{/crossLink}}.
             * The button updates its "pressed" attribute and changes the UI accordingly to the presence or lack of
             * link style of the selection.
             *
             * @method updateUI
             */
            updateUI: function() {
                var editor,
                    elementPath,
                    iconLinkNode,
                    result;

                editor = this.get('host').get('editor');

                elementPath = editor.elementPath();

                if (this._style) {
                    result = this._style.checkActive(elementPath, editor);

                    this._button.set('pressed', !!result);
                }

                iconLinkNode = this._button.get('boundingBox').one('i');

                if (this._button.get('pressed')) {
                    iconLinkNode.replaceClass('alloy-editor-icon-link', 'alloy-editor-icon-unlink');
                } else {
                    iconLinkNode.replaceClass('alloy-editor-icon-unlink', 'alloy-editor-icon-link');
                }
            },

            /**
             * Changes position of the Toolbar, and adjusts it according to the selection,
             * since the width of the UI for adding/edtiting of link href  might be shorter
             * or larger than the default Toolbar UI.
             *
             * @method _adjustHostPosition
             * @protected
             * @param {Number} oldHostWidth The previous width of the host (Toolbar).
             */
            _adjustHostPosition: function(oldHostWidth) {
                var curHostWidth,
                    curXY,
                    diff,
                    host,
                    x;

                host = this.get('host');

                if (host.get('visible')) {
                    curHostWidth = host.get('boundingBox').get('offsetWidth');

                    diff = Math.abs((oldHostWidth - curHostWidth) / 2);

                    curXY = host.get('xy');

                    if (curHostWidth < oldHostWidth) {
                        x = curXY[0] + diff;
                    } else {
                        x = curXY[0] - diff;
                    }

                    host.set('xy', [x, curXY[1]]);
                }
            },

            /**
             * Attaches a visibleChange listener on the Toolbar so the UI will commit or discard the link
             * if the button hides.
             *
             * @method _attachHideHandler
             * @protected
             */
            _attachHideHandler: function() {
                this._hideHandle = this.onceHostEvent('visibleChange', function(event) {
                    if (!event.newVal) {
                        this._updateLink();
                    }
                }, this);
            },

            /**
             * Attaches a hook to Toolbar activation.
             *
             * @method _attachToolbarActiveHook
             */
            _attachToolbarActiveHook: function() {
                this._toolbarActiveHandler = Y.Do.before(this._onToolbarActive, this.get('host'), 'focus', this);
            },

            /**
             * Handles the situation when user cancels committing the changes in the link.
             *
             * @method _cancelLinkChanges
             * @protected
             */
            _cancelLinkChanges: function() {
                // Detach hide handler, so link processing will be done here and not on toolbar hide.
                this._detachHideHandler();

                // If there is default link, it should be removed.
                // Otherwise, we just skip updating the href of the link.
                if (this._defaultLink) {
                    this._removeLink(this._defaultLink);
                }

                // In both cases we have to set empty value to the link input.
                this._linkInput.set('value', '');
            },

            /**
             * Detaches the hook to Toolbar focus method.
             *
             * @method _detachFocusHandler
             */
            _detachFocusHandler: function() {
                if (this._toolbarActiveHandler) {
                    Y.Do.detach(this._toolbarActiveHandler);

                    this._toolbarActiveHandler = null;
                }
            },

            /**
             * Detaches the attached visibleChange handler on the Toolbar which
             * handles the commit or discard process of the link.
             * See {{#crossLink "ButtonA/_attachHideHandler:method"}}{{/crossLink}} for more information.
             *
             * @method _detachHideHandler
             * @protected
             */
            _detachHideHandler: function() {
                if (this._hideHandle) {
                    this._hideHandle.detach();

                    this._hideHandle = null;
                }
            },

            /**
             * Handles pressing Enter key on link input.
             *
             * @method _handleLinkInputEnter
             * @protected
             * @param {EventFacade} event Event that triggered when user pressed Enter on link input
             */
            _handleLinkInputEnter: function(event) {
                var editor,
                    host,
                    ranges,
                    selection;

                // Editor has listener for click and keydown in order to detect
                // when user will stop interact with the editor. On each click and keydown the target is being checked
                // and if it is not part of the editor node or part of any Toolbar, editor assumes
                // the user navigated to other part of the page. In this case it hides the toolbars.
                // In order to prevent that, we have to stop propagating key ENTER to editor because in
                // this case the target will be body and the editor will assume the user stopped
                // to interact with the editor and it will hide the toolbars.
                event.stopPropagation();

                host = this.get('host');

                editor = host.get('editor');

                selection = editor.getSelection();

                ranges = selection.getRanges();

                host.hide();

                setTimeout(function() {
                    var range;

                    range = editor.createRange();

                    range.moveToPosition(ranges[0].endContainer, CKEDITOR.POSITION_AFTER_END);

                    selection.selectRanges([range]);
                }, 0);
            },

            /**
             * Handles pressing Esc key on link input.
             *
             * @method _handleLinkInputEsc
             * @protected
             * @param {EventFacade} event Event that triggered when user pressed Esc on link input
             */
            _handleLinkInputEsc: function(event) {
                this._cancelLinkChanges();

                this.get('host').get('editor').fire('toolbarKey', event);
            },

            /**
             * Handles pressing Tab key on link input.
             *
             * @method _handleLinkInputTab
             * @protected
             * @param {EventFacade} event Event that triggered when user pressed Tab on link input
             */
            _handleLinkInputTab: function() {
                event.preventDefault();

                if (!this._closeLink.get('disabled')) {
                    // focus this._switchToTextButton
                    this._linkContainer.focusManager.focus(0);
                }
                else {
                    // focus this._closeLink
                    this._linkContainer.focusManager.focus(1);
                }
            },

            /**
             * Attaches a visibleChange listener so the UI will commit or discard the link
             * when the button hides.
             *
             * @method _onClearInputClick
             * @protected
             */
            _onClearInputClick: function() {
                this._linkInput.set('value', '');

                this._linkInput.focus();

                this._clearInput.hide();
                this._closeLink.disable();
            },

            /**
             * Hides the Toolbar on clicking the close link button.
             *
             * @method _onCloseLinkClick
             * @protected
             */
            _onCloseLinkClick: function() {
                this.get('host').hide();
            },

            /**
             * Handles the click event from the user. If button status is "pressed", activates the UI for
             * creating the link. Otherwise, removes the link from the current selection.
             * On activating the UI for link creation, a default link with href= "/" will be created and it
             * will be kept in button instance as _defaultLink property. This link will also have an attribute,
             * called "data-cke-default-link", so these links will be easily distinguished from the others.
             * An implementation of Link Tooltip for example may ignore these links.
             *
             * @method _onClick
             * @protected
             * @param {EventFacade} event Event that triggered when user clicked on the button.
             */
            _onClick: function(event) {
                var instance = this,
                    btnInst,
                    editor,
                    linkInput,
                    oldHostWidth,
                    selection;

                btnInst = event.target;

                editor = instance.get('host').get('editor');

                if (btnInst.get('pressed')) {
                    selection = editor.getSelection();

                    oldHostWidth = this.get('host').get('boundingBox').get('offsetWidth');

                    instance._buttonsContainer.addClass('hide');
                    instance._linkContainer.removeClass('hide');

                    this._adjustHostPosition(oldHostWidth);

                    linkInput = instance._linkInput;

                    linkInput.focus();

                    this._ckLink.create('/', {
                        'data-cke-default-link': true
                    });

                    this._defaultLink = instance._link = this._ckLink.getFromSelection();

                    this._attachToolbarActiveHook();
                    this._attachHideHandler();
                } else {
                    this._ckLink.remove();
                }
            },

            /**
             * Handles keydown events attached to link UI.
             *
             * @method _onLinkContainerKeyDown
             * @protected
             * @param {EventFacade} event Event that triggered when user pressed a key.
             */
            _onLinkContainerKeyDown: function(event) {
                if (event.charCode === KEY_TAB) {
                    event.preventDefault();
                }

                this.get('host').get('editor').fire('toolbarKey', event);
            },

            /**
             * Handles pressing key on link input.
             * - on Esc it reverts any changes.
             * - on Enter it commits any changes made to the link.
             * - on Tab it navigates to the next button on the UI for link creation.
             *
             * @method _onLinkInputKeyDown
             * @protected
             * @param {EventFacade} event Event that triggered when user pressed a key.
             */
            _onLinkInputKeyDown: function(event) {
                if (event.keyCode === KEY_ESC) {
                    this._handleLinkInputEsc(event);

                } else if (event.keyCode === KEY_ENTER) {
                    this._handleLinkInputEnter(event);

                } else if (event.keyCode === KEY_TAB) {
                    this._handleLinkInputTab(event);
                }
            },

            /**
             * Handles clicking on switch to text view button.
             *
             * @method _onSwitchButtonClick
             * @protected
             * @param {EventFacade} event An Event Facade object
             */
            _onSwitchButtonClick: function(event) {
                this._switchToTextView();

                // call again focus on the toolbar so that the some of styles buttons will be focused
                this.get('host').focus();
            },

            /**
             * Handles focus event when link container is visible. In this case input element is the element
             * which should be focused.
             *
             * @method _onToolbarActive
             * @protected
             */
            _onToolbarActive: function() {
                var result = false;

                if (!this._linkContainer.hasClass('hide')) {
                    this._linkInput.focus();

                    result = true;
                }

                return new Y.Do.Halt(null, result);
            },

            /**
             * Shows or hides the close link button if link input contains some value.
             *
             * @method _onValueChange
             * @protected
             * @param {EventFacade} event An Event Facade object with the new and old value
             * of the input container.
             */
            _onValueChange: function(event) {
                if (event.newVal) {
                    this._clearInput.show();

                    this._closeLink.enable();
                } else {
                    this._clearInput.hide();

                    this._closeLink.disable();
                }
            },

            /**
             * On button hide, restore the default UI for creating link.
             * On button show, checks if the current selection has link style or not.
             * If it has, activates the UI for editing link, otherwise, activates the UI
             * for creating a link.
             *
             * @method _onVisibleChange
             * @protected
             * @param {EventFacade} event An Event Facade object with the new and old value
             * of visible property.
             */
            _onVisibleChange: function(event) {
                if (!event.newVal) {
                    this._linkContainer.addClass('hide');
                    this.get('host').get('buttonsContainer').removeClass('hide');

                    this._clearInput.hide();
                    this._closeLink.disable();

                    this._defaultLink = null;

                    this._detachFocusHandler();
                }
            },

            /**
             * Removes link and restores the editor selection.
             *
             * @method _removeLink
             * @param {CKEDITOR.dom.element} link optional The link which should be removed.
             */
            _removeLink: function(link) {
                var bookmarks,
                    editor,
                    selection;

                link = link || this._link;

                editor = this.get('host').get('editor');

                selection = editor.getSelection();

                bookmarks = selection.createBookmarks();

                this._linkInput.set('value', '');

                this._ckLink.remove(link);

                selection.selectBookmarks(bookmarks);
            },

            /**
             * Creates the UI for adding a link.
             *
             * @method _renderLinkUI
             * @protected
             */
            _renderLinkUI: function() {
                var contentBox,
                    linkContainer,
                    strings;

                strings = this.get('strings');

                linkContainer = YNode.create(
                    Lang.sub(
                        this.TPL_LINK_CONTAINER, {
                            back: strings.back,
                            clear: strings.clear,
                            confirm: strings.confirm,
                            placeholder: strings.placeholder
                        }
                    )
                );

                contentBox = this.get('host').get('contentBox');

                contentBox.appendChild(linkContainer);

                this._buttonsContainer = this.get('host').get('buttonsContainer');

                this._linkContainer = linkContainer;

                this._linkInput = linkContainer.one('input');

                this._clearInput = linkContainer.one('.input-clear i');

                this._clearInput.hide();

                this._closeLink = new Y.Button({
                    disabled: true,
                    render: linkContainer.one('.input-close-container'),
                    srcNode: linkContainer.one('.close-link')
                });

                this._switchToTextButton = new Y.Button({
                    render: linkContainer.one('.show-buttons-container'),
                    srcNode: linkContainer.one('.switch-to-edit')
                });

                linkContainer.plug(Y.Plugin.NodeFocusManager, {
                    activeDescendant: 0,
                    circular: true,
                    descendants: 'button',
                    focusClass: 'focus',
                    keys: {
                        next: 'down:' + KEY_ARROW_RIGHT,
                        previous: 'down:' + KEY_ARROW_LEFT
                    }
                });
            },

            /**
             * Changes the UI of the Toolbar so the user will be able to change the styles
             * of the selection instead to create a link.
             *
             * @method _switchToTextView
             * @protected
             */
            _switchToTextView: function() {
                var linkText,
                    oldHostWidth;

                this._detachFocusHandler();
                this._detachHideHandler();

                if (this._defaultLink) {
                    // We were in text mode and default link has been created.
                    // If there is link text, we have to update the link with the new value.
                    // Otherwise, we have to remove the link and restore the selection.
                    linkText = this._linkInput.get('value');

                    if (!linkText) {
                        this._removeLink();
                    } else {
                        this._updateLink();
                    }

                    this._defaultLink = null;

                    this.fire('actionPerformed');
                }

                oldHostWidth = this.get('host').get('boundingBox').get('offsetWidth');

                this._linkContainer.addClass('hide');
                this._buttonsContainer.removeClass('hide');

                this._adjustHostPosition(oldHostWidth);
            },

            /**
             * Changes the UI of the Toolbar so the user will be able to to create a link to
             * change the styles of the selection.
             *
             * @method _switchToLinkView
             * @protected
             * @param {CKEDITOR.dom.element} link The currently selected link from editor selection.
             */
            _switchToLinkView: function(link) {
                var editor,
                    linkInput;

                editor = this.get('host').get('editor');

                link = link || this._ckLink.getFromSelection();

                this._clearInput.show();
                this._closeLink.disable();

                this._buttonsContainer.addClass('hide');
                this._linkContainer.removeClass('hide');

                linkInput = this._linkInput;

                linkInput.set('value', link.$.href);

                setTimeout(function() {
                    linkInput.select();
                    linkInput.focus();
                }, 0);

                this._link = link;

                this._attachToolbarActiveHook();
                this._attachHideHandler();
            },

            /**
             * Checks if the current selection is a link, and changes the UI of the toolbar to
             * link view if so. Otherwise, switches to text view.
             *
             * @method  _switchView
             * @protected
             */
            _switchView: function() {
                var editor,
                    link;

                editor = this.get('host').get('editor');

                link = this._ckLink.getFromSelection();

                if (link) {
                    this._switchToLinkView(link);
                } else {
                    this._switchToTextView();
                }
            },

            /**
             * Updates the default link with the real href, if any, or removes the
             * default link from the current selection.
             * See {{#crossLink "ButtonA/_onClick:method"}}{{/crossLink}} for more information
             * about the default link.
             *
             * @method _updateLink
             * @protected
             */
            _updateLink: function() {
                var editor,
                    href;

                href = this._linkInput.get('value');

                editor = this.get('host').get('editor');

                if (href) {
                    this._ckLink.update(href, this._link);

                    this._link.removeAttribute('data-cke-default-link');
                } else {
                    this._ckLink.remove(this._link);
                }

                this._linkInput.set('value', '');

                this._link = null;
            },

            TPL_CONTENT: '<i class="alloy-editor-icon-link"></i>',

            TPL_LINK_CONTAINER: '<div class="link-wrapper hide">' +
                '<div class="pull-left btn-group input-wrapper">' +
                '<span class="input-container">' +
                '<input class="input-large" type="text" placeholder="{placeholder}"></input>' +
                '<span aria-label="{clear}" class="input-clear">' +
                '<i class="alloy-editor-icon-remove"></i>' +
                '</span>' +
                '</span>' +
                '</div>' +
                '<div class="pull-left btn-group input-close-container">' +
                '<button aria-label="{confirm}" class="alloy-editor-button btn btn-default close-link">' +
                '<i class="alloy-editor-icon-ok"></i></button>' +
                '</div>' +
                '<div class="pull-right btn-group show-buttons-container">' +
                '<button aria-label="{back}" class="alloy-editor-button btn btn-default switch-to-edit">' +
                '<i class="alloy-editor-icon-remove"></i></button>' +
                '</div>' +
                '</div>'
        }, {
            NAME: 'a',

            NS: 'a',

            ATTRS: {
                /**
                 * Specifies the element (style) which this button handles.
                 *
                 * @attribute element
                 * @default 'a'
                 * @type String
                 */
                element: {
                    validator: Lang.isString,
                    value: 'a'
                },

                /**
                 * Collection of strings used to label elements of the button's UI.
                 * ButtonA provides string properties to specify the messages for:
                 *  - Link input placeholder
                 *  - Button label
                 *  - Button actions (back, clear and confirm)
                 *
                 * @attribute strings
                 * @default {back: 'Back', clear: 'Clear', confirm: 'Confirm', label: 'Link', placeholder: 
                 *     'Type or paste link here'}
                 * @type Object
                 */
                strings: {
                    value: {
                        back: 'Back',
                        clear: 'Clear',
                        confirm: 'Confirm',
                        label: 'Link',
                        placeholder: 'Type or paste link here'
                    }
                }
            }
        });

    Y.ButtonA = A;

}, '', {
    requires: ['button-base', 'event-valuechange', 'node-focusmanager']
});

YUI.add('button-base', function(Y) {
    'use strict';

    var Lang = Y.Lang,
        YNode = Y.Node;

    function ButtonBase() {}

    /**
     * The ButtonBase class provides common functionality for a button like
     * reacting on click event, rendering and updating the UI.
     * A button implementation may be as simple as changing the style of selection
     * to bold, italic, underline, etc. or to be very complex - for example, to change
     * the UI of the host (toolbar). <br />
     * ToolbarBase and ButtonBase will provide everything you need to implement whatever you need.
     * Toolbars, which mix ToolbarBase extension will provide a container, where the button
     * should render. This container is accessible via "buttonsContainer" attribute.
     * If your button just changes the style of the selection, then everything you have to do
     * in order to implement it is: <br />
     * - extend Y.Plugin.Base and mix Y.ButtonBase extension
     * - specify the element to which you want to style the selection. This should be done via
     * "element" attribute. Here is the code: <br />
     * <pre><code>
     *    YUI.add('button-em', function (Y) {
     *        'use strict';
     *
     *         var Lang = Y.Lang;
     *
     *         var Em = Y.Base.create('em', Y.Plugin.Base, [Y.ButtonBase], {
     *             TPL_CONTENT: '&lt;i class=&quot;alloy-editor-icon-italic&quot;&gt;&lt;/i&gt;'
     *         }, {
     *             NAME: 'em',
     *
     *             NS: 'em',
     *
     *             ATTRS: {
     *                 element: {
     *                     validator: Lang.isString,
     *                     value: 'em'
     *                 }
     *             }
     *         });
     *
     *         Y.ButtonEm = Em;
     *
     *     },'', {
     *         requires: ['button-base']
     *     });
     * </code></pre>
     *
     * The code above creates a button, which will allow user to make selection italic.
     *
     * A more complex button may change the UI of the host (Toolbar) too. If the Toolbar mix
     * ToolbarBase extension, then it will export an attribute, called "buttonContainer". By
     * default, the buttons will be rendered in this container, so one button will be able to
     * hide the others and provide a different UI for the host (container).
     *
     * @class ButtonBase
     */

    /**
     * Fired once after user clicks on the button. ButtonBase will listen to this event and
     * call {{#crossLink "ButtonBase/updateUI:method"}}{{/crossLink}}, so the buttons
     * will have chance to update their UI accordingly. For example, if user clicks on
     * H2 button, and then clicks on H1 button, H2 button should remove its
     * {{#crossLink "ButtonBase/pressed:attribute"}}{{/crossLink}}, since these two styles
     * are mutually exclusive.
     *
     * @event actionPerformed
     */
    ButtonBase.prototype = {
        /**
         * Initializer lifecycle implementation for the ButtonBase class.
         *
         * @method initializer
         * @protected
         * @param config {Object} Configuration object literal for the editor
         */
        initializer: function() {
            var element;

            element = this.get('element');

            if (element) {
                this._style = new CKEDITOR.style({
                    element: this.get('element')
                });
            }

            this.afterHostMethod('renderUI', this.renderUI, this);
            this.afterHostMethod('bindUI', this.bindUI, this);
            this.afterHostEvent(['positionChange', 'actionPerformed'], this.updateUI, this);
        },

        /**
         * Destructor lifecycle implementation for the ButtonBase class. Destroys the internal
         * button instance.
         *
         * @method destructor
         * @protected
         */
        destructor: function() {
            this._button.destroy();
        },

        /**
         * Renders the button UI on the host which is typically a toolbar. The protected
         * {{#crossLink "ButtonBase/_renderButtonUI:method"}}{{/crossLink}} will be called,
         * so the buttons which mix this extension will be able to overwrite the default behaviour.
         *
         * @method renderUI
         * @protected
         */
        renderUI: function() {
            this._renderButtonUI();
        },

        /**
         * ButtonBase does not provide implementation, the buttons which mix this extension
         * may provide one.
         *
         * @method bindUI
         * @protected
         */
        bindUI: function() {
            // NOP, buttons should override it
        },

        /**
         * Updates the toggle status of the button. If the selection has the style, specified by
         * the button, its status will be made active and "pressed" attribute of the button will be
         * set to true, otherwise, it will be set to false. ButtonStrong for example is toggleable button.
         * Once "updateUI" function is called, the implementation will check if style "strong" is active on
         * the current selection. If so, "pressed" attribute of the button will be set to true and removed
         * otherwise.
         *
         * @method updateUI
         */
        updateUI: function() {
            var editor,
                elementPath,
                result;

            editor = this.get('host').get('editor');

            elementPath = editor.elementPath();

            if (this._style) {
                result = this._style.checkActive(elementPath, editor);

                this._button.set('pressed', !!result);
            }
        },

        /**
         * Applies the style for this button if its current status is pressed
         * and removes it if button is not pressed. For example, ButtonStrong will
         * apply style "strong" to the selection, when pressed.
         *
         * @method _onClick
         * protected
         */
        _onClick: function() {
            var editor;

            if (this._style) {
                editor = this.get('host').get('editor');

                if (this._button.get('pressed')) {
                    editor.applyStyle(this._style);
                } else {
                    editor.removeStyle(this._style);
                }
            }
        },

        /**
         * Fires {{#crossLink "ButtonBase/actionPerformed:event"}}{{/crossLink}}. ButtonBase listens
         * to this event and it will call {{#crossLink "ButtonBase/updateUI:method"}}{{/crossLink}}
         * function, so the buttons which are mutually exclusive, like H1 and H2 will be able to
         * update their UI accordingly.
         *
         * @method _afterClick
         * @protected
         */
        _afterClick: function() {
            this.fire('actionPerformed', {
                style: this._style
            });
        },

        /**
         * A Toolbar should provide a container (DOM Node) where the buttons will be rendered.
         * By default Toolbars, which extend ToolbarBase extension will expose an attribute,
         * called "buttonsContainer". The value of this attribute is the container where buttons will
         * be rendered, so they will share common container and one button may hide the others
         * temporally and provide custom UI for the Toolbar.
         *
         * @method _renderButtonUI
         * @protected
         */
        _renderButtonUI: function() {
            var btnInst,
                btnSrcNode,
                buttonsContainer;

            buttonsContainer = this.get('host').get('buttonsContainer');

            btnSrcNode = YNode.create(
                Lang.sub(this.TPL_BUTTON, {
                    content: this.TPL_CONTENT,
                    label: this.get('strings').label
                })
            );

            btnInst = this.get('toggle') ? 'ToggleButton' : 'Button';

            this._button = new Y[btnInst]({
                after: {
                    click: Y.bind(this._afterClick, this)
                },
                on: {
                    click: Y.bind(this._onClick, this)
                },
                render: buttonsContainer,
                srcNode: btnSrcNode
            });
        },

        TPL_BUTTON: '<button aria-label="{label}" class="alloy-editor-button btn btn-default">{content}</button>'
    };

    ButtonBase.ATTRS = {
        /**
         * Collection of strings used to label elements of the button's UI.
         * ButtonBase provides string properties to specify the label of the button.
         *
         * @attribute strings
         * @default {label: 'Button'}
         * @type Object
         */
        strings: {
            validator: Lang.isObject,
            value: {
                label: 'Button'
            }
        },

        /**
         * Specifies if the button is toggleable, or not.
         * Buttons may be "toggleable" or "push" buttons.
         *
         * @attribute toggle
         * @default true
         * @type Boolean
         * @writeOnce 'initOnly'
         */
        toggle: {
            validator: Lang.isBoolean,
            value: true,
            writeOnce: 'initOnly'
        }
    };

    Y.ButtonBase = ButtonBase;

}, '', {
    requires: ['base-build', 'plugin', 'button']
});
YUI.add('button-code', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    var BtnCode = Y.Base.create('code', Y.Plugin.Base, [Y.ButtonBase], {
        _handleCode: function(event) {

        },

        TPL_CONTENT: '<i class="alloy-editor-icon-code-sign"></i>'
    }, {
        NAME: 'code',

        NS: 'code'
    });

    Y.ButtonCode = BtnCode;

}, '', {
    requires: ['button-base']
});
YUI.add('button-em', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    /**
     * The ButtonEm class provides functionality for applying "em" (emphasize, italic) style
     * to the selection.
     *
     * @class ButtonEm
     */
    var Em = Y.Base.create('em', Y.Plugin.Base, [Y.ButtonBase], {
        TPL_CONTENT: '<i class="alloy-editor-icon-italic"></i>'
    }, {
        NAME: 'em',

        NS: 'em',

        ATTRS: {
            /**
             * Specifies the element (style) which this button handles.
             *
             * @attribute element
             * @default 'em'
             * @type String
             */
            element: {
                validator: Lang.isString,
                value: 'em'
            },

            /**
             * Collection of strings used to label elements of the button's UI.
             * ButtonEm provides string properties to specify the label of the button.
             *
             * @attribute strings
             * @default {label: 'Italic'}
             * @type Object
             */
            strings: {
                validator: Lang.isObject,
                value: {
                    label: 'Italic'
                }
            }
        }
    });

    Y.ButtonEm = Em;

}, '', {
    requires: ['button-base']
});
YUI.add('button-filter', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    var filters = [
    	{
    		name: 'X-PRO 2',
    		filter: 'contrast(1.3) brightness(0.8) sepia(0.3) saturate(1.5) hue-rotate(-20deg)'
    	},
    	{
    		name: 'Willow',
    		filter: 'saturate(0.02) contrast(0.85) brightness(1.2) sepia(0.02)'
    	},
    	{
    		name: 'Walden',
    		filter: 'sepia(0.35) contrast(0.9) brightness(1.1) hue-rotate(-10deg) saturate(1.5)'
    	},
    	{
    		name: 'Valencia',
    		filter: 'sepia(0.15) saturate(1.5) contrast(0.9)'
    	},
    	{
    		name: 'Toaster',
    		filter: 'sepia(0.4) saturate(2.5) hue-rotate(-30deg) contrast(0.67)'
    	},
    	{
    		name: 'Sutro',
    		filter: 'brightness(0.75) contrast(1.3) sepia(0.5) hue-rotate(-25deg)'
    	},
    	{
    		name: 'Sierra',
    		filter: 'contrast(0.8) saturate(1.2) sepia(0.15)'
    	},
    	{
    		name: 'Rise',
    		filter: 'saturate(1.4) sepia(0.25) hue-rotate(-15deg) contrast(0.8) brightness(1.1)'
    	},
    	{
    		name: 'Nashville',
    		filter: 'sepia(0.4) saturate(1.5) contrast(0.9) brightness(1.1) hue-rotate(-15deg)'
    	},
    	{
    		name: 'Kelvin',
    		filter: 'sepia(0.4) saturate(2.4) brightness(1.3) contrast(1)'
    	},
    	{
    		name: 'Inkwell',
    		filter: 'grayscale(1) brightness(1.2) contrast(1.05)'
    	},
    	{
    		name: 'Earlybird',
    		filter: 'sepia(0.4) saturate(1.6) contrast(1.1) brightness(0.9) hue-rotate(-10deg)'
    	},
    	{
    		name: 'Brannan',
    		filter: 'sepia(0.5) contrast(1.4)'
    	},
    	{
    		name: '1977',
    		filter: 'sepia(0.5) hue-rotate(-30deg) saturate(1.2) contrast(0.8)'
    	}
    ];

    /**
     * The ButtonRight class provides functionality for changing the alignment of an image.
     *
     * @class ButtonRight
     */
    var Filter = Y.Base.create('filter', Y.Plugin.Base, [Y.ButtonBase], {
        /**
         * Handles the click event. If the current status of button is "pressed",
         * applies "float: right" style to the image and removes "float" style otherwise.
         *
         * @method _onClick
         * @protected
         * @param {EventFacade} event Event that triggered when user clicked on the button.
         */
        _onClick: function(event) {
            var instance = this,
                btnInst,
                editor,
                element;

            btnInst = event.target;

            editor = instance.get('host').get('editor');

            element = editor.getSelection().getSelectedElement();

            var currentFilter = element.getAttribute('data-filterid') || 0;

            element.setStyle('filter', filters[currentFilter].filter);
            element.setStyle('-webkit-filter', filters[currentFilter].filter);

            element.setAttribute('data-filterid', ((currentFilter + 1) % filters.length));
        },

        TPL_CONTENT: '<i class="glyphicon_ glyphicon-filter_">F</i>'
    }, {
        NAME: 'filter',

        NS: 'filter',

        ATTRS: {
            strings: {
                validator: Lang.isObject,
                value: {
                    label: 'Filter'
                }
            }
        }
    });

    Y.ButtonFilter = Filter;

}, '', {
    requires: ['button-base']
});
YUI.add('button-h1', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    /**
     * The ButtonH1 class provides functionality for applying HTML heading, level 1
     * to the selection.
     *
     * @class ButtonH1
     */
    var H1 = Y.Base.create('h1', Y.Plugin.Base, [Y.ButtonBase], {
        TPL_CONTENT: '<i class="alloy-editor-icon-h1"></i>'
    }, {
        NAME: 'h1',

        NS: 'h1',

        ATTRS: {
            /**
             * Specifies the element (style) which this button handles.
             *
             * @attribute element
             * @default 'h1'
             * @type String
             */
            element: {
                validator: Lang.isString,
                value: 'h1'
            },

            /**
             * Collection of strings used to label elements of the button's UI.
             * ButtonH1 provides string properties to specify the label of the button.
             *
             * @attribute strings
             * @default {label: 'Heading level 1'}
             * @type Object
             */
            strings: {
                validator: Lang.isObject,
                value: {
                    label: 'Heading level 1'
                }
            }
        }
    });

    Y.ButtonH1 = H1;

}, '', {
    requires: ['button-base']
});
YUI.add('button-h2', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    /**
     * The ButtonH2 class provides functionality for applying HTML heading, level 2
     * to the selection.
     *
     * @class ButtonH2
     */
    var H2 = Y.Base.create('h2', Y.Plugin.Base, [Y.ButtonBase], {
        TPL_CONTENT: '<i class="alloy-editor-icon-h2"></i>'
    }, {
        NAME: 'h2',

        NS: 'h2',

        ATTRS: {
            /**
             * Specifies the element (style) which this button handles.
             *
             * @attribute element
             * @default 'h2'
             * @type String
             */
            element: {
                validator: Lang.isString,
                value: 'h2'
            },

            /**
             * Collection of strings used to label elements of the button's UI.
             * ButtonH2 provides string properties to specify the label of the button.
             *
             * @attribute strings
             * @default {label: 'Heading level 2'}
             * @type Object
             */
            strings: {
                validator: Lang.isObject,
                value: {
                    label: 'Heading level 2'
                }
            }
        }
    });

    Y.ButtonH2 = H2;

}, '', {
    requires: ['button-base']
});
YUI.add('button-hline', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    var BtnHline = Y.Base.create('hline', Y.Plugin.Base, [Y.ButtonBase], {
        _handleMedia: function(event) {

        },

        TPL_CONTENT: '<i class="alloy-editor-icon-hline-sign"></i>'
    }, {
        NAME: 'hline',

        NS: 'hline'
    });

    Y.ButtonHline = BtnHline;

}, '', {
    requires: ['button-base']
});
YUI.add('button-image', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    /**
     * The ButtonImage class provides functionality for adding an image to the editor.
     *
     * @class ButtonImage
     */

    /**
     * Fired when an image file is added as an element in the editor.
     *
     * @event imageadd
     * @param {CKEDITOR.dom.element} el The created img element in editor.
     */
    var BtnImage = Y.Base.create('image', Y.Plugin.Base, [Y.ButtonBase], {
        /**
         * Creates an input element of type "file" if not already created and registers
         * an event on input value change.
         *
         * @method _getInputFile
         * @protected
         */
        _getInputFile: function() {
            var id,
                inputFile;

            inputFile = this._inputFile;

            if (!inputFile) {
                id = Y.guid();

                Y.one('body').prepend('<input type="file" id="' + id + '"  style="display: none;"></input>');

                inputFile = Y.one('#' + id);

                inputFile.on('change', this._onInputChange, this);

                this._inputFile = inputFile;
            }

            return inputFile;
        },

        /**
         * Simulates "click" event on the input field when user presses the button. This
         * triggers the native open file dialog from the browser. This method works on IE9+ only.
         *
         * @method _onClick
         * @protected
         * @param {EventFacade} event Event that triggered when user clicked on the button.
         */
        _onClick: function() {
            var inputFile = this._getInputFile();

            inputFile.simulate('click');
        },

        /**
         * On input change, reads the chosen file and creates an img element with src as Data URI.
         * Then, fires an {{#crossLink "ButtonImage/imageadd:event"}}{{/crossLink}} via CKEditor
         * message system.
         *
         * @method _onInputChange
         * @protected
         */
        _onInputChange: function() {
            var instance = this,
                editor,
                inputFile,
                el,
                reader;

            reader = new FileReader();

            reader.onload = function(event) {
                editor = instance.get('host').get('editor');

                el = CKEDITOR.dom.element.createFromHtml('<img src="' + event.target.result + '">');

                editor.insertElement(el);

                editor.fire('imageadd', el);
            };

            inputFile = this._inputFile;

            reader.readAsDataURL(inputFile.getDOMNode().files[0]);

            inputFile.set('value', '');
        },

        TPL_CONTENT: '<i class="alloy-editor-icon-image-sign"></i>'
    }, {
        NAME: 'image',

        NS: 'image',

        ATTRS: {
            /**
             * Collection of strings used to label elements of the button's UI.
             * ButtonImage provides string properties to specify the label of the button.
             *
             * @attribute strings
             * @default {label: 'Image'}
             * @type Object
             */
            strings: {
                validator: Lang.isObject,
                value: {
                    label: 'Image'
                }
            },

            /**
             * Specifies if this button will be toggleable, or not.
             * ButtonImage will be not toggleable by default.
             *
             * @attribute toggle
             * @default false
             * @type Boolean
             * @writeOnce 'initOnly'
             */
            toggle: {
                validator: Lang.isBoolean,
                value: false,
                writeOnce: 'initOnly'
            }
        }
    });

    Y.ButtonImage = BtnImage;

}, '', {
    requires: ['button-base', 'node-event-simulate']
});
YUI.add('button-left', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    /**
     * The ButtonLeft class provides functionality for changing the alignment of an image.
     *
     * @class ButtonLeft
     */
    var Left = Y.Base.create('left', Y.Plugin.Base, [Y.ButtonBase], {
        /**
         * Updates "pressed" attribute of the button. If the currently selected element
         * is an image and this image is explicitly left aligned,
         * "pressed" attribute will be set to true, otherwise - to false.
         *
         * @method updateUI
         */
        updateUI: function() {
            var editor,
                element,
                styleFloat;

            editor = this.get('host').get('editor');

            element = editor.getSelection().getSelectedElement();

            if (element && element.getName() === 'img') {
                styleFloat = element.getStyle('float');

                this._button.set('pressed', styleFloat === 'left');
            }
        },

        /**
         * Handles the click event. If the current status of button is "pressed",
         * applies "float: left" style to the image and removes "float" style otherwise.
         *
         * @method _onClick
         * @protected
         * @param {EventFacade} event Event that triggered when user clicked on the button.
         */
        _onClick: function(event) {
            var instance = this,
                btnInst,
                editor,
                element;

            btnInst = event.target;

            editor = instance.get('host').get('editor');

            element = editor.getSelection().getSelectedElement();

            if (btnInst.get('pressed')) {
                element.setStyle('float', 'left');
            } else {
                element.removeStyle('float');
            }
        },

        TPL_CONTENT: '<i class="alloy-editor-icon-align-left"></i>'
    }, {
        NAME: 'left',

        NS: 'left',

        ATTRS: {
            /**
             * Specifies the element (style) which this button handles.
             *
             * @attribute element
             * @default 'left'
             * @type String
             */
            element: {
                validator: Lang.isString,
                value: 'left'
            },

            /**
             * Collection of strings used to label elements of the button's UI.
             * ButtonLeft provides string properties to specify the label of the button.
             *
             * @attribute strings
             * @default {label: 'Align left'}
             * @type Object
             */
            strings: {
                validator: Lang.isObject,
                value: {
                    label: 'Align left'
                }
            }
        }
    });

    Y.ButtonLeft = Left;

}, '', {
    requires: ['button-base']
});
YUI.add('button-media', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    var BtnMedia = Y.Base.create('media', Y.Plugin.Base, [Y.ButtonBase], {
        _handleMedia: function(event) {

        },

        TPL_CONTENT: '<i class="alloy-editor-icon-media-sign"></i>'
    }, {
        NAME: 'media',

        NS: 'media'
    });

    Y.ButtonMedia = BtnMedia;

}, '', {
    requires: ['button-base']
});
YUI.add('button-quote', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    var BtnQuote = Y.Base.create('quote', Y.Plugin.Base, [Y.ButtonBase], {
        _handleQuote: function(event) {

        },

        TPL_CONTENT: '<i class="alloy-editor-icon-quote-sign"></i>'
    }, {
        NAME: 'quote',

        NS: 'quote'
    });

    Y.ButtonQuote = BtnQuote;

}, '', {
    requires: ['button-base']
});
YUI.add('button-right', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    /**
     * The ButtonRight class provides functionality for changing the alignment of an image.
     *
     * @class ButtonRight
     */
    var Right = Y.Base.create('right', Y.Plugin.Base, [Y.ButtonBase], {
        /**
         * Updates "pressed" attribute of the button. If the currently selected element
         * is an image and this image is explicitly right aligned,
         * "pressed" attribute will be set to true, otherwise - to false.
         *
         * @method updateUI
         */
        updateUI: function() {
            var editor,
                element,
                styleFloat;

            editor = this.get('host').get('editor');

            element = editor.getSelection().getSelectedElement();

            if (element && element.getName() === 'img') {
                styleFloat = element.getStyle('float');

                this._button.set('pressed', styleFloat === 'right');
            }
        },

        /**
         * Handles the click event. If the current status of button is "pressed",
         * applies "float: right" style to the image and removes "float" style otherwise.
         *
         * @method _onClick
         * @protected
         * @param {EventFacade} event Event that triggered when user clicked on the button.
         */
        _onClick: function(event) {
            var instance = this,
                btnInst,
                editor,
                element;

            btnInst = event.target;

            editor = instance.get('host').get('editor');

            element = editor.getSelection().getSelectedElement();

            if (btnInst.get('pressed')) {
                element.setStyle('float', 'right');
            } else {
                element.removeStyle('float');
            }
        },

        TPL_CONTENT: '<i class="alloy-editor-icon-align-right"></i>'
    }, {
        NAME: 'right',

        NS: 'right',

        ATTRS: {
            /**
             * Specifies the element (style) which this button handles.
             *
             * @attribute element
             * @default 'right'
             * @type String
             */
            element: {
                validator: Lang.isString,
                value: 'right'
            },

            /**
             * Collection of strings used to label elements of the button's UI.
             * ButtonRight provides string properties to specify the label of the button.
             *
             * @attribute strings
             * @default {label: 'Align right'}
             * @type Object
             */
            strings: {
                validator: Lang.isObject,
                value: {
                    label: 'Align right'
                }
            }
        }
    });

    Y.ButtonRight = Right;

}, '', {
    requires: ['button-base']
});
YUI.add('button-rotate', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    var ROTATE_REGEX = /rotate\((\d+)deg\)/;

    /**
     * The ButtonRight class provides functionality for changing the alignment of an image.
     *
     * @class ButtonRight
     */
    var Rotate = Y.Base.create('rotate', Y.Plugin.Base, [Y.ButtonBase], {
        /**
         * Handles the click event. If the current status of button is "pressed",
         * applies "float: right" style to the image and removes "float" style otherwise.
         *
         * @method _onClick
         * @protected
         * @param {EventFacade} event Event that triggered when user clicked on the button.
         */
        _onClick: function(event) {
            var instance = this,
                btnInst,
                editor,
                element;

            btnInst = event.target;

            editor = instance.get('host').get('editor');

            element = editor.getSelection().getSelectedElement();

            var transform = element.getStyle('transform');

            var angle = 90;

            var hasRotation = ROTATE_REGEX.test(transform);

            if (hasRotation) {
            	angle += Number(ROTATE_REGEX.exec(transform)[1]);
            }

            element.setStyle('transform', 'rotate(' + angle + 'deg)');
        },

        TPL_CONTENT: '<i class="glyphicon_ glyphicon-rotate_">R</i>'
    }, {
        NAME: 'rotate',

        NS: 'rotate',

        ATTRS: {
            strings: {
                validator: Lang.isObject,
                value: {
                    label: 'Rotate'
                }
            }
        }
    });

    Y.ButtonRotate = Rotate;

}, '', {
    requires: ['button-base']
});
YUI.add('button-strong', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    /**
     * The ButtonStrong class provides functionality for applying "strong" (bold) style to a text selection.
     *
     * @class ButtonStrong
     */
    var Strong = Y.Base.create('strong', Y.Plugin.Base, [Y.ButtonBase], {
        TPL_CONTENT: '<i class="alloy-editor-icon-bold"></i>'
    }, {
        NAME: 'strong',

        NS: 'strong',

        ATTRS: {
            /**
             * Specifies the element (style) which this button handles.
             *
             * @attribute element
             * @default 'strong'
             * @type String
             */
            element: {
                validator: Lang.isString,
                value: 'strong'
            },

            /**
             * Collection of strings used to label elements of the button's UI.
             * ButtonStrong provides string properties to specify the label of the button.
             *
             * @attribute strings
             * @default {label: 'Bold'}
             * @type Object
             */
            strings: {
                validator: Lang.isObject,
                value: {
                    label: 'Bold'
                }
            }
        }
    });

    Y.ButtonStrong = Strong;

}, '', {
    requires: ['button-base']
});
YUI.add('button-twitter', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    /**
     * The ButtonTwitter class provides functionality for sending tweets based on the selected text.
     *
     * @class ButtonTwitter
     */
    var Tweet = Y.Base.create('tweet', Y.Plugin.Base, [Y.ButtonBase], {
        /**
         * Overwrites the default behaviour of ButtonBase's
         * {{#crossLink "ButtonBase/updateUI:method"}}{{/crossLink}} method since
         * this button does is not toggleable.
         *
         * @method updateUI
         */
        updateUI: function() {
            // NOP
        },

        /**
         * Reads the selected text from the editor and opens a browser window so the
         * user will be able to tweet directly the text.
         *
         * @method _onClick
         * @protected
         */
        _onClick: function() {
            var editor,
                tweetURL;

            tweetURL = this.get('tweetURL');

            editor = this.get('host').get('editor');

            tweetURL = Lang.sub(tweetURL, {
                text: encodeURIComponent(editor.getSelection().getSelectedText()),
                url: encodeURIComponent(Y.config.win.location)
            });

            window.open(
                tweetURL,
                this.get('windowTitle'),
                this.get('windowProperties')
            );
        },

        TPL_CONTENT: '<i class="alloy-editor-icon-twitter"></i>'
    }, {
        NAME: 'tweet',

        NS: 'tweet',

        ATTRS: {
            /**
             * Collection of strings used to label elements of the button's UI.
             * ButtonTwitter provides string properties to specify the label of the button.
             *
             * @attribute strings
             * @default {label: 'Tweet'}
             * @type Object
             */
            strings: {
                validator: Lang.isObject,
                value: {
                    label: 'Tweet'
                }
            },

            /**
             * Specifies if the button is toggleable, or not. ButtonTwitter will be not toggleable by default.
             *
             * @attribute toggle
             * @default false
             * @type Boolean
             * @writeOnce 'initOnly'
             */
            toggle: {
                validator: Lang.isBoolean,
                value: false,
                writeOnce: 'initOnly'
            },

            /**
             * Specifies the URL where user can tweet the selected text.
             *
             * @attribute tweetURL
             * @default 'https://twitter.com/intent/tweet?text={text}&url={url}'
             * @type String
             */
            tweetURL: {
                validator: Lang.isString,
                value: 'https://twitter.com/intent/tweet?text={text}&url={url}'
            },

            /**
             * Specifies the properties of the browser window where the selected text
             * will appear.
             *
             * @attribute windowProperties
             * @default 'resizable,status,width=400,height=250'
             * @type String
             */
            windowProperties: {
                validator: Lang.isString,
                value: 'resizable,status,width=400,height=250'
            },

            /**
             * Specifies the title of the browser window where the selected text
             * will appear.
             *
             * @attribute windowTitle
             * @default ''
             * @type String
             */
            windowTitle: {
                validator: Lang.isString,
                value: ''
            }
        }
    });

    Y.ButtonTwitter = Tweet;

}, '', {
    requires: ['button-base']
});
YUI.add('button-twitterquote', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    var BtnTwitterquote = Y.Base.create('twitterquote', Y.Plugin.Base, [Y.ButtonBase], {
        _handleMedia: function(event) {

        },

        TPL_CONTENT: '<i class="alloy-editor-icon-twitter-sign"></i>'
    }, {
        NAME: 'twitterquote',

        NS: 'twitterquote'
    });

    Y.ButtonTwitterquote = BtnTwitterquote;

}, '', {
    requires: ['button-base']
});
YUI.add('button-u', function(Y) {
    'use strict';

    var Lang = Y.Lang;

    /**
     * Button Underline. A standard AlloyUI/YUI class which allows to apply underline style to
     * editor selection. Extends Y.Plugin.Base and mixes Y.ButtonBase extension.
     *
     * @class ButtonU
     * @constructor
     */
    var Underline = Y.Base.create('underline', Y.Plugin.Base, [Y.ButtonBase], {
        TPL_CONTENT: '<i class="alloy-editor-icon-underline"></i>'
    }, {
        NAME: 'underline',

        NS: 'underline',

        ATTRS: {

            /**
             * @description Specifies the style, which should be applied to the current selection in editor.
             *
             * @attribute element
             * @default 'u'
             * @type String
             */
            element: {
                validator: Lang.isString,
                value: 'u'
            },

            /**
             * Collection of strings used to label elements of the button's UI.
             * ButtonU provides string properties to specify the label of the button.
             *
             * @attribute strings
             * @default {label: 'Underline'}
             * @type Object
             */
            strings: {
                validator: Lang.isObject,
                value: {
                    label: 'Underline'
                }
            }
        }
    });

    Y.ButtonU = Underline;

}, '', {
    requires: ['button-base']
});
YUI.add('toolbar-add', function(Y) {
    'use strict';

    var Lang = Y.Lang,
        YNode = Y.Node,

        ARROW_BOX_CLASSES = [
            'alloy-editor-arrow-box-top',
            'alloy-editor-arrow-box-bottom',
            'alloy-editor-arrow-box-left',
            'alloy-editor-arrow-box-right'
        ],

        ToolbarAddTrigger,

        /**
         * The ToolbarAdd class provides functionality for adding content to the editor.
         *
         * @class ToolbarAdd
         */
        ToolbarAdd = Y.Base.create('toolbaradd', Y.Widget, [Y.ToolbarBase, Y.ToolbarPosition, Y.WidgetPosition,
            Y.WidgetPositionConstrain], {
            /**
             * Initializer lifecycle implementation for the ToolbarAdd class.
             *
             * @method initializer
             * @protected
             * @param config {Object} Configuration object literal for the toolbar
             */
            initializer: function() {
                var editorNode;

                editorNode = Y.one(this.get('editor').element.$);

                this._editorDOMNode = editorNode.getDOMNode();

                this._toolbars = {};
            },

            /**
             * Attaches events to the add button which will help to handle the appearance of the
             * menu with the buttons.
             *
             * @method bindUI
             * @protected
             */
            bindUI: function() {
                var editor;

                editor = this.get('editor');

                this._triggerButton.on('click', this._showToolbarAddContent, this);

                this.on('visibleChange', this._onVisibleChange, this);
                editor.on('toolbarsReady', this._onToolbarsReady, this);
                editor.on('toolbarsHide', this._onToolbarsHide, this);
            },

            /**
             * Destroys the add trigger and the trigger button.
             *
             * @method destructor
             * @protected
             */
            destructor: function() {
                this._triggerButton.destroy();

                this._trigger.destroy();
            },

            /**
             * Returns the focus to the editor and shows again the trigger.
             *
             * @method blur
             */
            blur: function() {
                this.get('editor').focus();

                this._showTriggerAtPoint(this._triggerButtonPosition.left, this._triggerButtonPosition.top);
            },

            /**
             * Focus the toolbar. If it is visible, focus the first button, otherwise focus the trigger button.
             *
             * @method focus
             * @return {Boolean} True if toolbar has been focused, false otherwise.
             */
            focus: function() {
                var buttonsContainer = this.get('buttonsContainer');

                if (this.get('visible')) {
                    buttonsContainer.focusManager.focus(0);
                } else {
                    this._triggerButton.focus();
                }

                return true;
            },

            /**
             * Returns true if the passed node is a child node of the toolbar, false otherwise.
             *
             * @method ownsNode
             * @param  {Node|HTMLElement} node The node which should be checked if it is child node of the current
             * toolbar.
             * @return {Boolean} True if the passed node is child node of the current toolbar.
             */
            ownsNode: function(node) {
                return this.get('boundingBox').contains(node) || this._trigger.get('boundingBox').contains(node);
            },

            /**
             * Renders the two containers - for button add and the toolbar.
             *
             * @method renderUI
             * @protected
             */
            renderUI: function() {
                this._renderToolbarAddContent();

                this._renderTrigger();
            },

            /**
             * Calculates and sets the position of the toolbar.
             *
             * @method showAtPoint
             * @param {Number} left The left offset in page coordinates where Toolbar should be shown.
             * @param {Number} top The top offset in page coordinates where Toolbar should be shown.
             * @param {Number} direction The direction of the selection. May be one of the following:
             * CKEDITOR.SELECTION_BOTTOM_TO_TOP or CKEDITOR.SELECTION_TOP_TO_BOTTOM
             */
            showAtPoint: function(left, top, direction) {
                var boundingBox,
                    visible,
                    xy;

                boundingBox = this.get('boundingBox');

                if (this._isCurrentLineEmpty()) {
                    direction = CKEDITOR.SELECTION_LEFT_TO_RIGHT;
                }

                Y.Array.each(ARROW_BOX_CLASSES, function(item) {
                    boundingBox.removeClass(item);
                });

                boundingBox.addClass(ARROW_BOX_CLASSES[direction || 0]);

                visible = this.get('visible');

                if (!visible) {
                    this.show();
                }

                xy = this._getToolbarXYPoint(left, top, direction);

                this._moveToPoint(this.getConstrainedXY(xy), direction, {
                    visible: visible
                });
            },

            /**
             * Hides all present toolbars other than this one.
             *
             * @method _hideEditorToolbars
             * @protected
             */
            _hideEditorToolbars: function() {
                var editorToolbars;

                editorToolbars = this._toolbars;

                Y.Object.each(editorToolbars, function(item) {
                    if (this !== item) {
                        item.hide();
                    }
                });
            },

            /**
             * Displays or hides the toolbar when user interacts with the editor
             * (via mouse, keyboard or touch device).
             * ToolbarAdd displays itself always - regardless of the fact the selection
             * is empty or not. It might be hidden only if there is no any selection region.
             *
             * @method _onEditorInteraction
             * @protected
             * @param {EventFacade} event Event that triggered when user interacted with the editor.
             */
            _onEditorInteraction: function(event) {
                var nativeEvent,
                    selectionData,
                    startRect;

                selectionData = event.data.selectionData;

                nativeEvent = event.data.nativeEvent;

                this.hide();

                if (selectionData.region) {
                    startRect = selectionData.region.startRect || selectionData.region;

                    this._toolbarPosition = this._calculatePosition(selectionData, {
                        x: nativeEvent.pageX,
                        y: nativeEvent.pageY
                    });

                    this._triggerButtonPosition = {
                        left: this._editorNode.getX(),
                        top: selectionData.region.top + startRect.height / 2
                    };

                    this._showTriggerAtPoint(this._triggerButtonPosition.left, this._triggerButtonPosition.top);
                }
            },

            /**
             * Hides the toolbar and the trigger in case of <code>toolbarsHide</code> event.
             *
             * @method _onToolbarsHide
             */
            _onToolbarsHide: function() {
                this.hide();

                this._trigger.hide();
            },

            /**
             * Stores the editor initialized toolbars.
             *
             * @method _onToolbarsReady
             * @protected
             * @param {EventFacade} event Event that triggered when all editor toolbars are initialized.
             */
            _onToolbarsReady: function(event) {
                this._toolbars = event.data.toolbars;
            },

            /**
             * Adds a marker-class on editorNode to indicate the add toolbar is visible.
             *
             * @method _onVisibleChange
             * @protected
             * @param {EventFacade} event Event that triggered when toolbar visibility changes.
             */
            _onVisibleChange: function(event) {
                this._editorNode.toggleClass('alloyeditor-add-toolbar', event.newVal);
            },

            /**
             * Creates the container where buttons, attached to the instance of Toolbar should render.
             *
             * @method _renderButtons
             * @protected
             */
            _renderToolbarAddContent: function() {
                var instance = this,
                    buttonsContainer,
                    contentBox;

                buttonsContainer = YNode.create(instance.TPL_BUTTONS_CONTAINER);

                contentBox = this.get('contentBox');

                contentBox.appendChild(buttonsContainer);

                instance._buttonsContainer = buttonsContainer;
            },

            /**
             * Renders the toolbar trigger.
             *
             * @method _renderTrigger
             * @protected
             */
            _renderTrigger: function() {
                var triggerButton,
                    triggerButtonContainer;

                triggerButtonContainer = YNode.create(Lang.sub(
                    this.TPL_TRIGGER, {
                        addContent: this.get('strings').addContent,
                        content: this.TPL_TRIGGER_CONTENT
                    }));

                this._trigger = new ToolbarAddTrigger({
                    render: true,
                    visible: false,
                    zIndex: 1
                });

                triggerButton = new Y.Button({
                    srcNode: triggerButtonContainer.one('.btn-add')
                }).render(triggerButtonContainer);

                this._trigger.get('contentBox').appendChild(triggerButtonContainer);

                this._triggerButton = triggerButton;

                this._triggerButtonContainer = triggerButtonContainer;

                this._triggerButtonContainer.on('keydown', this._onKeyDown, this);
            },

            /**
             * Shows the toolbar and hides the toolbar trigger on the margin.
             *
             * @method _showToolbarAddContent
             * @protected
             */
            _showToolbarAddContent: function() {
                this._hideEditorToolbars();

                this.showAtPoint(this._toolbarPosition.x, this._toolbarPosition.y, this._toolbarPosition.direction);

                this._trigger.hide();

                this._editorNode.focus();

                this.focus();

                this.get('editor').fire('toolbarActive', this);
            },

            /**
             * Calculates and sets the position of the add toolbar trigger.
             *
             * @method _showTriggerAtPoint
             * @protected
             * @param {Number} left The left offset in page coordinates where Trigger should be shown.
             * @param {Number} top The top offset in page coordinates where Trigger should be shown.
             */
            _showTriggerAtPoint: function(left, top) {
                var strings,
                    triggerButtonContainer,
                    triggerGutter;

                if (!this._trigger.get('visible')) {
                    this._trigger.show();

                    strings = this.get('strings');

                    this.get('editor').fire('ariaUpdate', {
                        message: Lang.sub(strings.state, {
                            focus: strings.focus,
                            name: this.name,
                            state: strings.visible
                        })
                    });
                }

                triggerButtonContainer = this._triggerButtonContainer.getDOMNode();

                triggerGutter = this.get('triggerGutter');

                this._trigger.set('xy', this.getConstrainedXY([left - triggerButtonContainer.offsetWidth -
                    triggerGutter.left, top - triggerGutter.top - triggerButtonContainer.offsetHeight / 2]));
            },

            BOUNDING_TEMPLATE: '<div class="alloy-editor-toolbar alloy-editor-toolbar-add alloy-editor-arrow-box">' +
                '</div>',

            CONTENT_TEMPLATE: '<div class="alloy-editor-toolbar-content btn-toolbar"></div>',

            TPL_BUTTONS_CONTAINER: '<div class="alloy-editor-toolbar-buttons btn-group"></div>',

            TPL_TRIGGER: '<div class="alloy-editor-toolbar-buttons btn-group">' +
                '<button aria-label="{addContent}" class="alloy-editor-button btn btn-add" type="button">{content}' +
                '</button>' +
                '</div>',

            TPL_TRIGGER_CONTENT: '<i class="alloy-editor-icon-add"></i>'

        }, {
            ATTRS: {
                /**
                 * Specifies the buttons, which will be attached to the current instance of the toolbar.
                 * A button configuration can be simple string with the name of the button, or an object
                 * with properties, like this:
                 * <pre><code>
                 *     buttons: ['image']
                 * </pre></code>
                 *     or:
                 * <pre><code>
                 *     buttons: [
                 *         {
                 *             name: 'image',
                 *             cfg: {
                 *                 zIndex: 1024,
                 *                 property2: 1024
                 *             }
                 *         }
                 *     ]
                 * </pre></code>
                 *
                 * @attribute buttons
                 * @default ['image']
                 * @type Array
                 */
                buttons: {
                    validator: Lang.isArray,
                    value: ['image']
                },

                /**
                 * Specifies whether the toolbar show be constrained to some node or to the viewport.
                 *
                 * @attribute constrain
                 * @default true (will be constrained to the viewport)
                 * @type Boolean
                 */
                constrain: {
                    validator: Lang.isBoolean,
                    value: true
                },

                /**
                 * Collection of strings used to label elements of the toolbar's UI.
                 * ToolbarBase provides string properties to specify the messages for:
                 *  - How to focus on the toolbar
                 *  - Possible toolbar states (hidden and visible)
                 *  - Current toolbar state. This works as a template. It's possible to
                 *  use the placeholders {name}, {state} and {focus} to inject messages
                 *  into the generated string.
                 *
                 * @attribute strings
                 * @default {addContent: 'Add content', focus: 'Press Alt + F10 to focus on the toolbar.',
                 *     hidden: 'hidden', state: 'Toolbar {name} is now {state}. {focus}', visible: 'visible'}
                 * @type Object
                 */
                strings: {
                    validator: Lang.isObject,
                    value: {
                        addContent: 'Add content',
                        focus: 'Press Alt + F10 to focus on the toolbar.',
                        hidden: 'hidden',
                        state: 'Toolbar {name} is now {state}. {focus}',
                        visible: 'visible'
                    }
                },

                /**
                 * Specifies the gutter of the trigger button. The gutter object contains the top
                 * and left offsets from the point, where the trigger is supposed to appear.
                 *
                 * @attribute gutter
                 * @default {
                 *   left: 15,
                 *   top: 0
                 * }
                 * @type Object
                 */
                triggerGutter: {
                    validator: Lang.isObject,
                    value: {
                        left: 15,
                        top: 0
                    }
                }
            }
        });

    Y.ToolbarAdd = ToolbarAdd;

    /**
     * The ToolbarAddTrigger class hosts controls for showing the toolbar with the add controls. This class is intended
     * to be used internally by {{#crossLink "ToolbarAdd"}}{{/crossLink}} class.
     *
     * @class ToolbarAddTrigger
     */
    ToolbarAddTrigger = Y.Base.create('toolbaraddtrigger', Y.Widget, [Y.WidgetPosition, Y.WidgetPositionAlign], {
        BOUNDING_TEMPLATE: '<div class="alloy-editor-toolbar alloy-editor-toolbar-add-trigger"></div>',

        CONTENT_TEMPLATE: '<div class="alloy-editor-toolbar-content btn-toolbar"></div>'
    }, {

    });
}, '0.1', {
    requires: ['widget-base', 'widget-position', 'widget-position-constrain', 'widget-position-align', 'toolbar-base',
        'toolbar-position']
});
YUI.add('toolbar-base', function(Y) {
    'use strict';

    var Lang = Y.Lang,
        YArray = Y.Array,

        KEY_ARROW_LEFT = 37,
        KEY_ARROW_RIGHT = 39,

        EMPTY_LINE_REGEX = /\r?\n/;

    function ToolbarBase() {}

    /**
     * The ToolbarBase extension is a common base for all AlloyEditor's Toolbars.
     *
     * @class ToolbarBase
     */
    ToolbarBase.prototype = {
        /**
         * Initializer lifecycle implementation for the ToolbarBase class.
         *
         * @method initializer
         * @protected
         * @param config {Object} Configuration object literal for the toolbar
         */
        initializer: function() {
            var instance = this,
                editor;

            editor = instance.get('editor');

            instance._editorNode = Y.one(editor.element.$);

            YArray.each(
                instance.get('buttons'),
                function(item) {
                    var buttonName,
                        cfg,
                        instanceName;

                    buttonName = Lang.isObject(item) ? item.name : item;

                    instanceName = instance._getButtonInstanceName(buttonName);

                    cfg = Lang.isObject(item) ? item.cfg : null;

                    instance.plug(Y[instanceName], cfg);

                    // Each button will fire actionPerformed when user interacts with it. Here we will
                    // re-fire this event to the other buttons so they will be able to update their UI too.
                    instance[Y[instanceName].NS].after('actionPerformed', instance._afterActionPerformed, instance);
                }
            );

            instance.after('render', instance._afterRender, instance);
            instance.after('visibleChange', instance._afterVisibleChange, instance);

            editor.on('editorInteraction', instance._onEditorInteraction, instance);
        },

        /**
         * Returns focus to editor.
         *
         * @method blur
         */
        blur: function() {
            this.get('editor').focus();
        },

        /**
         * If toolbar is visible, focuses the first button.
         *
         * @method focus
         * @return {Boolean} True if toolbar has been focused, false otherwise.
         */
        focus: function() {
            var buttonsContainer,
                visible;

            buttonsContainer = this.get('buttonsContainer');

            visible = this.get('visible');

            if (visible) {
                buttonsContainer.focusManager.focus(0);
            }

            return visible;
        },

        /**
         * Returns true if the passed node is a child node of the toolbar, false otherwise.
         *
         * @method ownsNode
         * @param  {Node|HTMLElement} node The node which should be checked if it is child node of the current toolbar.
         * @return {Boolean} True if the passed node is child node of the current toolbar.
         */
        ownsNode: function(node) {
            return this.get('boundingBox').contains(node);
        },

        /**
         * When toolbar has been rendered, initialize the focus manager and attach
         * listener for keyboard events
         *
         * @method _afterRender
         * @protected
         */
        _afterRender: function() {
            var buttonsContainer = this.get('buttonsContainer');

            buttonsContainer.plug(Y.Plugin.NodeFocusManager, {
                activeDescendant: 0,
                circular: true,
                descendants: 'button',
                focusClass: 'focus',
                keys: {
                    next: 'down:' + KEY_ARROW_RIGHT,
                    previous: 'down:' + KEY_ARROW_LEFT
                }
            });

            buttonsContainer.on('keydown', this._onKeyDown, this);
        },

        /**
         * Handles showing or hiding of the toolbar.
         * Fires {{#crossLink "CKEDITOR.plugins.uicore/ariaUpdate:event"}}{{/crossLink}} event with the status changes
         * of the toolbar.
         *
         * @method _afterVisibleChange
         * @protected
         * @param {EventFacade} event Event that triggered the toolbar has been made visible or hidden.
         */
        _afterVisibleChange: function(event) {
            var strings = this.get('strings');

            this.get('editor').fire('ariaUpdate', {
                message: Lang.sub(strings.state, {
                    focus: (event.newVal ? strings.focus : ''),
                    name: this.name,
                    state: (event.newVal ? strings.visible : strings.hidden)
                })
            });
        },

        /**
         * Applies transition specified via {{#crossLink "ToolbarBase/transition:attribute"}}{{/crossLink}} attribute.
         *
         * @method _applyTransition
         * @param {Array} xy The point in page coordinates where Toolbar should move.
         * @param {Number} direction The direction of the selection. Can be one of these:
         *   1. CKEDITOR.SELECTION_TOP_TO_BOTTOM
         *   2. CKEDITOR.SELECTION_BOTTOM_TO_TOP
         * @protected
         */
        _applyTransition: function(xy, direction) {
            var boundingBox,
                boundingBoxNode,
                height,
                transition,
                x,
                width,
                y;

            transition = this.get('transition');

            boundingBox = this.get('boundingBox');

            boundingBox.setStyle('visibility', 'hidden');
            boundingBoxNode = boundingBox.getDOMNode();

            height = boundingBoxNode.offsetHeight;
            width = boundingBoxNode.offsetWidth;

            // Change the original points where the Toolbar should be positioned.
            // The X will be the same, but we will extract or add the height of the
            // Toolbar to the Y point.
            if (direction === CKEDITOR.SELECTION_TOP_TO_BOTTOM || direction === CKEDITOR.SELECTION_BOTTOM_TO_TOP) {

                x = xy[0];
                y = (direction === CKEDITOR.SELECTION_TOP_TO_BOTTOM) ? (xy[1] - height) : (xy[1] + height);

            } else if (direction === CKEDITOR.SELECTION_LEFT_TO_RIGHT ||
                direction === CKEDITOR.SELECTION_RIGHT_TO_LEFT) {

                x = (direction === CKEDITOR.SELECTION_LEFT_TO_RIGHT) ? (xy[0] - width) : (xy[0] + width);
                y = xy[1];
            }

            this.set('xy', [x, y]);

            transition.left = xy[0] + 'px';
            transition.top = xy[1] + 'px';

            boundingBox.setStyle('visibility', 'visible');

            boundingBox.transition(transition);

            // Restore the original points where the Toorbad had to move.
            // Adding UI_SRC as the source of the event will prevent toolbar to move,
            // it will just set update XY attribute.
            this.set('xy', xy, {
                src: Y.Widget.UI_SRC
            });
        },

        /**
         * Re-fires {{#crossLink "ButtonBase/actionPerformed:event"}}{{/crossLink}} so the buttons
         * attached to Toolbar, which mixes this extension will be notified that user performed
         * an action.
         *
         * @method _afterActionPerformed
         * @protected
         * @param {EventFacade} event The {{#crossLink "ButtonBase/actionPerformed:event"}}{{/crossLink}} event.
         */
        _afterActionPerformed: function(event) {
            this.fire('actionPerformed', event);
        },

        /**
         * Returns the container in which all buttons are being rendered.
         *
         * @method _getButtonsContainer
         * @protected
         * @return {Node} The container of all buttons attached to the current instance of Toolbar.
         */
        _getButtonsContainer: function() {
            return this._buttonsContainer;
        },

        /**
         * Resolves and returns the name of the Button from the current editor configuration.
         *
         * @method _getButtonInstanceName
         * @protected
         * @param {String} buttonName The name of the button as specified in Toolbar configuration.
         * @return {String} The constructed name of Button.
         * See {{#crossLink "CKEDITOR.plugins.uiloader/_getModules:method"}}{{/crossLink}}
         * for more information about the rules for constructing button names.
         */
        _getButtonInstanceName: function(buttonName) {
            return 'Button' + buttonName.substring(0, 1).toUpperCase() + buttonName.substring(1);
        },

        /**
         * Detects if the current line is empty
         *
         * @method _isCurrentLineEmpty
         * @protected
         * @return {Boolean} True if the current line is empty.
         */
        _isCurrentLineEmpty: function() {
            var currentLine;

            currentLine = this.get('editor').getSelection().getRanges()[0].getCommonAncestor();

            return EMPTY_LINE_REGEX.test(currentLine.getText());
        },

        /**
         * Moves the Toolbar to a point in page coordinates. If transition was specified via the
         * {{#crossLink "ToolbarBase/transition:attribute"}}{{/crossLink}}, the movement will be
         * delegated to the transition, except if Toolbar is already visible. In the last case
         * transition will be ignored.
         *
         * @method _moveToPoint
         * @param {Array} xy The point in page coordinates where Toolbar should move.
         * @param {Number} direction The direction of the selection. Can be one of these:
         *   1. CKEDITOR.SELECTION_TOP_TO_BOTTOM
         *   2. CKEDITOR.SELECTION_BOTTOM_TO_TOP
         * @param {Object} config Provides additional configuration attributes to the function.
         * This parameter is optional. If not provided, the transition will be applied (if any).
         * Supported parameters are:
         * - visible: true or false. If toolbar is visible, the transition will be applied (if any).
         * If not, it will be suppressed and only the new position will be set.
         * @protected
         */
        _moveToPoint: function(xy, direction, config) {
            var transition;

            transition = this.get('transition');

            if (transition && (!config || !config.visible)) {
                this._applyTransition(xy, direction);
            } else {
                this.set('xy', xy);
            }
        },

        /**
         * Fires <code>toolbarKey</code> event. Editor should listen this event
         * and perform the associated action.
         *
         * @method _onKeyDown
         * @param {EventFacade} event Event that triggered when user pressed a key inside the toolbar.
         * @protected
         */
        _onKeyDown: function(event) {
            this.get('editor').fire('toolbarKey', event);
        }
    };

    ToolbarBase.ATTRS = {
        /**
         * Returns the container in Toolbar's contentBox, where all buttons are rendered.
         *
         * @attribute buttonsContainer
         * @type Node
         * @readOnly
         */
        buttonsContainer: {
            getter: '_getButtonsContainer',
            readOnly: true
        },

        /**
         * Contains the native editor implementation.
         *
         * @attribute editor
         * @default true
         * @type Object
         */
        editor: {
            validator: Lang.isObject
        },

        /**
         * Collection of strings used to label elements of the toolbar's UI.
         * ToolbarBase provides string properties to specify the messages for:
         *  - How to focus on the toolbar
         *  - Possible toolbar states (hidden and visible)
         *  - Current toolbar state. This works as a template. It's possible to
         *  use the placeholders {name}, {state} and {focus} to inject messages
         *  into the generated string.
         *
         * @attribute strings
         * @default {focus: 'Press Alt + F10 to focus on the toolbar.', hidden: 'hidden', state: 'Toolbar {name} is now {state}. {focus}', visible: 'visible'}
         * @type Object
         */
        strings: {
            validator: Lang.isObject,
            value: {
                focus: 'Press Alt + F10 to focus on the toolbar.',
                hidden: 'hidden',
                state: 'Toolbar {name} is now {state}. {focus}',
                visible: 'visible'
            }
        },

        /**
         * Specifies the transition which should be applied when Toolbar moves to given position.
         *
         * @attribute transition
         * @default {
         *    easing: 'ease-out',
         *    duration: 0.1
         *  }
         * @type Object
         */
        transition: {
            value: {
                easing: 'ease-out',
                duration: 0.1
            }
        }
    };

    Y.ToolbarBase = ToolbarBase;

}, '', {
    requires: ['node-focusmanager', 'node-base', 'plugin']
});

YUI.add('toolbar-image', function(Y) {
    'use strict';

    var Lang = Y.Lang,
        YNode = Y.Node,

        /**
         * The ToolbarImage class hosts the buttons for aligning and manipulating an image.
         *
         * @class ToolbarImage
         */
        ToolbarImage = Y.Base.create('toolbarimage', Y.Widget, [Y.WidgetPosition, Y.WidgetPositionConstrain, Y.ToolbarBase, Y.ToolbarPosition], {
            /**
             * Creates the container where buttons, attached to the instance of Toolbar should render.
             *
             * @method renderUI
             * @protected
             */
            renderUI: function() {
                var instance = this,
                    buttonsContainer,
                    contentBox;

                buttonsContainer = YNode.create(instance.TPL_BUTTONS_CONTAINER);

                this.get('boundingBox').addClass('arrow-box arrow-box-bottom');

                contentBox = this.get('contentBox');

                contentBox.addClass('btn-toolbar');

                contentBox.appendChild(buttonsContainer);

                instance._buttonsContainer = buttonsContainer;
            },

            /**
             * Attaches listeners to <code>actionPerformed</code> and <code>toolbarsHide</code> events.
             *
             * @method bindUI
             * @protected
             */
            bindUI: function() {
                this.on('actionPerformed', this._onActionPerformed, this);

                this.get('editor').on('toolbarsHide', this._onToolbarsHide, this);
            },

            /**
             * Calculates and sets the position of the toolbar.
             *
             * @method showAtPoint
             * @param {Number} left The left offset in page coordinates.
             * @param {Number} top The top offset in page coordinates.
             * @param {Number} direction The direction of the selection. Can be one of these:
             *   1. CKEDITOR.SELECTION_TOP_TO_BOTTOM
             *   2. CKEDITOR.SELECTION_BOTTOM_TO_TOP
             */
            showAtPoint: function(left, top, direction) {
                var xy,
                    visible;

                visible = this.get('visible');

                if (!visible) {
                    this.show();
                }

                xy = this._getToolbarXYPoint(left, top, direction);

                this._moveToPoint(this.getConstrainedXY(xy), direction, {
                    visible: visible
                });
            },

            /**
             * After changing the attributes of the image, updates the position of the Toolbar.
             *
             * @method _onActionPerformed
             * @protected
             */
            _onActionPerformed: function() {
                var editor,
                    element;

                editor = this.get('editor');

                element = editor.getSelection().getSelectedElement();

                this._updateUI(element);
            },

            /**
             * Once after user interacts with the editor, shows or hides the Toolbar.
             * The Toolbar will be hidden if the currently selected element is not an image.
             *
             * @method _onEditorInteraction
             * @protected
             * @param {EventFacade} event Event that triggered when user interacted with the editor.
             */
            _onEditorInteraction: function(event) {
                var element,
                    name,
                    selectionData;

                selectionData = event.data.selectionData;

                element = selectionData.element;

                name = element ? element.getName() : null;

                if (name === 'img') {
                    this._updateUI(element);
                } else {
                    this.hide();
                }
            },

            /**
             * Hides the toolbar in case of <code>toolbarsHide</code> event.
             *
             * @method _onToolbarsHide
             */
            _onToolbarsHide: function() {
                this.hide();
            },

            /**
             * Moves the Toolbar to specified position.
             *
             * @method _updateUI
             * @protected
             * @param {CKEDITOR.dom.element} element The selected image element from the editor.
             */
            _updateUI: function(element) {
                var region;

                if (element) {
                    region = Y.DOM.region(element.$);

                    this.showAtPoint(region.left + (region.right - region.left) / 2, region.top,
                        CKEDITOR.SELECTION_BOTTOM_TO_TOP);

                    this.fire('positionChange', this);

                    this.get('editor').fire('toolbarActive', this);
                }
            },

            BOUNDING_TEMPLATE: '<div class="alloy-editor-toolbar alloy-editor-toolbar-image alloy-editor-arrow-box ' +
                'alloy-editor-arrow-box-bottom"></div>',

            CONTENT_TEMPLATE: '<div class="alloy-editor-toolbar-content btn-toolbar"></div>',

            TPL_BUTTONS_CONTAINER: '<div class="alloy-editor-toolbar-buttons btn-group"></div>'
        }, {
            ATTRS: {
                /**
                 * Specifies the buttons, which will be attached to the current instance of the toolbar.
                 * A button configuration can be simple string with the name of the button, or an object
                 * with properties, like this:
                 * <pre><code>
                 *     buttons: ['left']
                 * </pre></code>
                 *     or:
                 * <pre><code>
                 *     buttons: [
                 *         {
                 *             name: 'left',
                 *             cfg: {
                 *                 zIndex: 1024,
                 *                 property2: 1024
                 *             }
                 *         }
                 *     ]
                 * </pre></code>
                 *
                 * @attribute buttons
                 * @default ['left', 'right']
                 * @type Array
                 */
                buttons: {
                    validator: Lang.isArray,
                    value: ['left', 'right']
                },

                /**
                 * Specifies whether the toolbar show be constrained to some node or to the viewport.
                 *
                 * @attribute constrain
                 * @default true (will be constrained to the viewport)
                 * @type Boolean
                 */
                constrain: {
                    validator: Lang.isBoolean,
                    value: true
                }
            }
        });

    Y.ToolbarImage = ToolbarImage;
}, '', {
    requires: ['dom-screen', 'widget-base', 'widget-position', 'widget-position-constrain', 'toolbar-base', 'toolbar-position']
});

YUI.add('toolbar-position', function(Y) {
    'use strict';

    var Lang = Y.Lang,
        YArray = Y.Array;

    function ToolbarPosition() {}

    /**
     * The ToolbarPosition extension provides functionality to position a toolbar
     * based on the current selection and the toolbar contents.
     *
     * @class ToolbarPosition
     */
    ToolbarPosition.prototype = {
        /**
         * Calculates the position of the toolbar. Depending on the direction of the
         * selection, ToolbarStyles may appear above on or on bottom of the selection.
         *
         * @method _calculatePosition
         * @protected
         * @param {Object} selectionData The data about the selection in the editor as
         * returned from {{#crossLink "CKEDITOR.plugins.selectionregion/getSelectionData:method"}}{{/crossLink}}
         * @param {Number} pos Contains the coordinates of the position, considered as most appropriate.
         * This may be the point where the user released the mouse, or just the beginning or the end of
         * the selection.
         * @return {Object} An Object which contains the following properties:
         * direction, x, y, where x and y are in page coordinates and direction can be one of these:
         * CKEDITOR.SELECTION_BOTTOM_TO_TOP or CKEDITOR.SELECTION_TOP_TO_BOTTOM
         */
        _calculatePosition: function(selectionData, pos) {
            var direction,
                endRect,
                startRect,
                x,
                y;

            direction = selectionData.region.direction;

            endRect = selectionData.region.endRect;
            startRect = selectionData.region.startRect;

            if (endRect && startRect && startRect.top === endRect.top) {
                direction = CKEDITOR.SELECTION_BOTTOM_TO_TOP;
            }

            // If we have the point where user released the mouse, show Toolbar at this point
            // otherwise show it on the middle of the selection.
            if (pos.x && pos.y) {
                x = this._getXPoint(selectionData, pos.x);

                if (direction === CKEDITOR.SELECTION_BOTTOM_TO_TOP) {
                    y = Math.min(pos.y, selectionData.region.top);
                } else {
                    y = Math.max(pos.y, selectionData.region.bottom);
                }
            } else {
                x = selectionData.region.left + selectionData.region.width / 2;

                if (direction === CKEDITOR.SELECTION_TOP_TO_BOTTOM) {
                    y = selectionData.region.bottom;
                } else {
                    y = selectionData.region.top;
                }
            }

            return {
                direction: direction,
                x: x,
                y: y
            };
        },

        /**
         * Returns the position of the Toolbar taking in consideration the
         * {{#crossLink "ToolbarStyles/gutter:attribute"}}{{/crossLink}} attribute.
         *
         * @method _getToolbarXYPoint
         * @protected
         * @param {Number} left The left offset in page coordinates where Toolbar should be shown.
         * @param {Number} right The right offset in page coordinates where Toolbar should be shown.
         * @param {Number} direction The direction of the selection. May be one of the following:
         * CKEDITOR.SELECTION_BOTTOM_TO_TOP or CKEDITOR.SELECTION_TOP_TO_BOTTOM
         * @return {Array} An Array with left and top offsets in page coordinates.
         */
        _getToolbarXYPoint: function(left, top, direction) {
            var bbDOMNode,
                gutter;

            bbDOMNode = this.get('boundingBox').getDOMNode();

            gutter = this.get('gutter');

            if (direction === CKEDITOR.SELECTION_TOP_TO_BOTTOM || direction === CKEDITOR.SELECTION_BOTTOM_TO_TOP) {

                left = left - gutter.left - (bbDOMNode.offsetWidth / 2);
                top = (direction === CKEDITOR.SELECTION_TOP_TO_BOTTOM) ? (top + gutter.top) : (top - bbDOMNode.offsetHeight - gutter.top);

            } else if (direction === CKEDITOR.SELECTION_LEFT_TO_RIGHT || direction === CKEDITOR.SELECTION_RIGHT_TO_LEFT) {

                left = (direction === CKEDITOR.SELECTION_LEFT_TO_RIGHT) ? (left + gutter.left + bbDOMNode.offsetHeight / 2) : (left - 3 * bbDOMNode.offsetHeight / 2 - gutter.left);
                top = top - gutter.top - (bbDOMNode.offsetHeight / 2);

            }

            return [left, top];
        },

        /**
         * Returns the position of the Toolbar taking in consideration the
         * {{#crossLink "ToolbarStyles/gutter:attribute"}}{{/crossLink}} attribute.
         *
         * @method _getXPoint
         * @protected
         * @param {Object} selectionData The data about the selection in the editor as
         * returned from {{#crossLink "CKEDITOR.plugins.selectionregion/getSelectionData:method"}}{{/crossLink}}
         * @param {Object} eventX The X coordinate received from the native event (mouseup).
         * @return {Number} The calculated X point in page coordinates.
         */
        _getXPoint: function(selectionData, eventX) {
            var left,
                leftDist,
                region,
                right,
                rightDist,
                x;

            region = selectionData.region;

            left = region.startRect ? region.startRect.left : region.left;
            right = region.endRect ? region.endRect.right : region.right;

            if (left < eventX && right > eventX) {
                x = eventX;
            } else {
                leftDist = Math.abs(left - eventX);
                rightDist = Math.abs(right - eventX);

                if (leftDist < rightDist) { // user raised the mouse on left on the selection
                    x = left;
                } else {
                    x = right;
                }
            }

            return x;
        }
    };

    ToolbarPosition.ATTRS = {
        /**
         * Specifies the gutter of the toolbar. The gutter object contains the top and left
         * offsets from the point, where the toolbar is supposed to appear.
         *
         * @attribute gutter
         * @default {
         *   left: 0,
         *   top: 10
         * }
         * @type Object
         */
        gutter: {
            validator: Lang.isObject,
            value: {
                left: 0,
                top: 10
            }
        }
    };

    Y.ToolbarPosition = ToolbarPosition;

}, '', {
    requires: ['node-base']
});
YUI.add('toolbar-styles', function(Y) {
    'use strict';

    var Lang = Y.Lang,
        YNode = Y.Node,

        /**
         * The ToolbarStyles class hosts the buttons for styling text selection.
         *
         * @class ToolbarStyles
         */
        ToolbarStyles = Y.Base.create('toolbarstyles', Y.Widget, [Y.WidgetPosition, Y.WidgetPositionConstrain, Y.ToolbarBase, Y.ToolbarPosition], {
            /**
             * Creates the container where buttons, attached to the instance of Toolbar should render.
             *
             * @method renderUI
             * @protected
             */
            renderUI: function() {
                var instance = this,
                    buttonsContainer,
                    contentBox;

                buttonsContainer = YNode.create(instance.TPL_BUTTONS_CONTAINER);

                contentBox = this.get('contentBox');

                contentBox.appendChild(buttonsContainer);

                instance._buttonsContainer = buttonsContainer;
            },

            /**
             * Attaches listener to <code>toolbarsHide</code> event.
             *
             * @method bindUI
             * @protected
             */
            bindUI: function() {
                this.get('editor').on('toolbarsHide', this._onToolbarsHide, this);
            },

            /**
             * Calculates and sets the position of the toolbar.
             *
             * @method showAtPoint
             * @param {Number} left The left offset in page coordinates where Toolbar should be shown.
             * @param {Number} top The right offset in page coordinates where Toolbar should be shown.
             * @param {Number} direction The direction of the selection. May be one of the following:
             * CKEDITOR.SELECTION_BOTTOM_TO_TOP or CKEDITOR.SELECTION_TOP_TO_BOTTOM
             */
            showAtPoint: function(left, top, direction) {
                var boundingBox,
                    xy,
                    visible;

                boundingBox = this.get('boundingBox');

                if (direction === CKEDITOR.SELECTION_TOP_TO_BOTTOM) {
                    boundingBox.replaceClass('alloy-editor-arrow-box-bottom', 'alloy-editor-arrow-box-top');
                } else {
                    boundingBox.replaceClass('alloy-editor-arrow-box-top', 'alloy-editor-arrow-box-bottom');
                }

                visible = this.get('visible');

                if (!visible) {
                    this.show();
                }

                xy = this._getToolbarXYPoint(left, top, direction);

                this._moveToPoint(this.getConstrainedXY(xy), direction, {
                    visible: visible
                });
            },

            /**
             * Calculates the most appropriate position where the Toolbar should be displayed and shows it.
             *
             * @method _onEditorInteraction
             * @protected
             * @param {Object} event The editorInteraction event payload.
             * See {{#crossLink "CKEDITOR.plugins.uicore/editorInteraction:event"}}{{/crossLink}} event for more
             * information.
             */
            _onEditorInteraction: function(event) {
                var editor,
                    position,
                    selectionData,
                    selectionEmpty,
                    nativeEvent;

                editor = this.get('editor');

                selectionEmpty = editor.isSelectionEmpty();

                selectionData = event.data.selectionData;

                nativeEvent = event.data.nativeEvent;

                if (!selectionData.element && selectionData.region && !selectionEmpty) {
                    position = this._calculatePosition(selectionData, {
                        x: nativeEvent.pageX,
                        y: nativeEvent.pageY
                    });

                    this.showAtPoint(position.x, position.y, position.direction);

                    this.fire('positionChange', this);

                    editor.fire('toolbarActive', this);
                } else {
                    this.hide();
                }
            },

            /**
             * Hides the toolbar in case of <code>toolbarsHide</code> event.
             *
             * @method _onToolbarsHide
             */
            _onToolbarsHide: function() {
                this.hide();
            },

            BOUNDING_TEMPLATE: '<div class="alloy-editor-toolbar alloy-editor-toolbar-styles alloy-editor-arrow-box">' +
                '</div>',

            CONTENT_TEMPLATE: '<div class="alloy-editor-toolbar-content btn-toolbar"></div>',

            TPL_BUTTONS_CONTAINER: '<div class="btn-group alloy-editor-toolbar-buttons"></div>'
        }, {
            ATTRS: {
                /**
                 * Specifies the buttons, which will be attached to the current instance of the toolbar.
                 * A button configuration can be simple string with the name of the button, or an object
                 * with properties, like this:
                 * <pre><code>
                 *     buttons: ['strong']
                 * </pre></code>
                 *     or:
                 * <pre><code>
                 *     buttons: [
                 *         {
                 *             name: 'strong',
                 *             cfg: {
                 *                 zIndex: 1024,
                 *                 property2: 1024
                 *             }
                 *         }
                 *     ]
                 * </pre></code>
                 *
                 * @attribute buttons
                 * @default ['strong', 'em', 'u', 'h1', 'h2', 'a', 'twitter']
                 * @type Array
                 */
                buttons: {
                    validator: Lang.isArray,
                    value: ['strong', 'em', 'u', 'h1', 'h2', 'a', 'twitter']
                },

                /**
                 * Specifies whether the toolbar show be constrained to some node or to the viewport.
                 *
                 * @attribute constrain
                 * @default true (will be constrained to the viewport)
                 * @type Boolean
                 */
                constrain: {
                    validator: Lang.isBoolean,
                    value: true
                }
            }
        });

    Y.ToolbarStyles = ToolbarStyles;
}, '', {
    requires: ['toolbar-base', 'toolbar-position', 'widget-base', 'widget-position', 'widget-position-constrain']
});
